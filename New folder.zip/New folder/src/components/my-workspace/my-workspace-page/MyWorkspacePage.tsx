import Link from 'next/link';
import { BarChart3, BriefcaseBusiness, Megaphone, UserRoundSearch } from 'lucide-react';

import { ActivitiesCard } from '@/components/my-workspace/activities-card/ActivitiesCard';
import { BrandWaves } from '@/components/brand/BrandWaves';
import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import type { ActivityItem } from '@/types/domain';

import styles from './MyWorkspacePage.module.css';

interface MyWorkspacePageProps {
  locale: Locale;
  loadError?: boolean;
  activities: {
    items: ActivityItem[];
    page: number;
    totalPages: number;
    total: number;
  };
}

type SuggestionTone = 'campaign' | 'dashboard' | 'candidates' | 'employers';

interface SuggestionItem {
  title: string;
  description: string;
  cta: string;
  href: string;
  icon: typeof Megaphone;
  tone: SuggestionTone;
}

export function MyWorkspacePage({ locale, activities, loadError = false }: MyWorkspacePageProps): JSX.Element {
  const suggestions: SuggestionItem[] = [
    {
      title: messages.myWorkspaceStartCampaignTitle[locale],
      description: messages.myWorkspaceStartCampaignDesc[locale],
      cta: messages.myWorkspaceStartCampaignCta[locale],
      href: '/outreach/targeting',
      icon: Megaphone,
      tone: 'campaign',
    },
    {
      title: messages.myWorkspaceCheckNumbersTitle[locale],
      description: messages.myWorkspaceCheckNumbersDesc[locale],
      cta: messages.myWorkspaceCheckNumbersCta[locale],
      href: '/dashboard',
      icon: BarChart3,
      tone: 'dashboard',
    },
    {
      title: messages.myWorkspaceBrowseCandidatesTitle[locale],
      description: messages.myWorkspaceBrowseCandidatesDesc[locale],
      cta: messages.myWorkspaceBrowseCandidatesCta[locale],
      href: '/candidates',
      icon: UserRoundSearch,
      tone: 'candidates',
    },
    {
      title: messages.myWorkspaceBrowseEmployersTitle[locale],
      description: messages.myWorkspaceBrowseEmployersDesc[locale],
      cta: messages.myWorkspaceBrowseEmployersCta[locale],
      href: '/employers',
      icon: BriefcaseBusiness,
      tone: 'employers',
    },
  ];

  return (
    <>
      <div className={styles.ambient} aria-hidden="true">
        <div className={`${styles.blob} ${styles.blobBrand}`} />
        <div className={`${styles.blob} ${styles.blobTeal}`} />
      </div>

      <div className={styles.layout}>
        <div className={styles.card}>
          <div className={styles.shimmer} aria-hidden="true" />
          <div className={`${styles.cardGlow} ${styles.cardGlowBrand}`} aria-hidden="true" />

          <div className={styles.heroBanner}>
            <BrandWaves intensity="punchy" idPrefix="workspace-suggest-wave" className={styles.bannerWaves} />
            <div className={styles.heroBannerCopy}>
              <h2 className={styles.heroBannerTitle}>{messages.myWorkspaceSuggestedTitle[locale]}</h2>
            </div>
          </div>

          <div className={styles.suggestionList}>
            {suggestions.map((item, index) => {
              const Icon = item.icon;
              return (
                <article
                  key={item.title}
                  className={`${styles.suggestionRow}${index > 0 ? ` ${styles.suggestionRowBorder}` : ''}`}
                >
                  <span
                    className={`${styles.rowIconBadge} ${styles[`tone_${item.tone as SuggestionTone}`]}`}
                    aria-hidden="true"
                  >
                    <Icon size={16} strokeWidth={2.1} />
                  </span>

                  <div className={styles.rowCopy}>
                    <h3 className={styles.rowTitle}>{item.title}</h3>
                    <p className={styles.rowDesc}>{item.description}</p>
                  </div>

                  <Link href={item.href} className={`${styles.rowButton} ${styles[`rowButton_${item.tone as SuggestionTone}`]}`}>
                    {item.cta}
                  </Link>
                </article>
              );
            })}
          </div>
        </div>

        <div className={styles.card}>
          <div className={styles.shimmer} aria-hidden="true" />
          <div className={`${styles.cardGlow} ${styles.cardGlowTeal}`} aria-hidden="true" />

          <div className={`${styles.heroBanner} ${styles.heroBannerTeal}`}>
            <BrandWaves intensity="punchy" idPrefix="workspace-history-wave" className={styles.bannerWaves} />
            <div className={styles.heroBannerCopy}>
              <h2 className={styles.heroBannerTitle}>{messages.myWorkspaceHistoryTitle[locale]}</h2>
            </div>
          </div>

          <ActivitiesCard
            items={activities.items}
            page={activities.page}
            totalPages={activities.totalPages}
            locale={locale}
            loadError={loadError}
          />
        </div>
      </div>
    </>
  );
}

import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['selector', '[data-theme="dark"]'],
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    // Mirrors --font-sans in base.css so Tailwind utilities and plain CSS
    // resolve to the same local typeface.
    fontFamily: {
      sans: ['var(--font-sst)', 'sans-serif'],
    },
    extend: {
      boxShadow: {
        soft: '0 14px 44px rgba(35, 45, 30, 0.13)',
      },
      colors: {
        canvas: 'var(--paper)',
        ink: 'var(--ink)',
        ink2: 'var(--ink2)',
        ink3: 'var(--ink3)',
        // green uses the RGB-channel var so Tailwind opacity modifiers work (e.g. ring-green/15)
        green: 'rgb(var(--green-ch) / <alpha-value>)',
        greenDark: 'var(--green-dark)',
        ochre: 'var(--ochre)',
        clay: 'var(--clay)',
        blue: 'var(--teal)',
      },
      backgroundImage: {
        'ambient-light':
          'radial-gradient(620px 520px at 92% -8%, rgba(19, 133, 95, 0.18), transparent 60%), radial-gradient(560px 480px at -6% 10%, rgba(189, 126, 37, 0.13), transparent 58%), radial-gradient(720px 700px at 50% 122%, rgba(15, 111, 77, 0.12), transparent 60%)',
        'ambient-dark':
          'radial-gradient(620px 520px at 92% -8%, rgba(31, 174, 126, 0.18), transparent 60%), radial-gradient(560px 480px at -6% 10%, rgba(217, 154, 63, 0.12), transparent 58%), radial-gradient(720px 700px at 50% 122%, rgba(31, 174, 126, 0.10), transparent 60%)',
      },
    },
  },
  plugins: [],
};

export default config;
/**
 * Security headers applied to every response. Kept to the set that cannot break
 * the app: a CSP is deliberately left out because it needs to be derived from
 * the real deployment's script/style origins rather than guessed here.
 */
const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'X-DNS-Prefetch-Control', value: 'on' },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=()',
  },
];

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Removes the `X-Powered-By: Next.js` response header.
  poweredByHeader: false,

  // Barrel-file imports from these packages are rewritten to deep imports, so a
  // page that uses three icons or one chart no longer pulls the whole library.
  experimental: {
    optimizePackageImports: ['lucide-react', 'recharts'],
  },

  async headers() {
    return [{ source: '/:path*', headers: securityHeaders }];
  },
};

export default nextConfig;

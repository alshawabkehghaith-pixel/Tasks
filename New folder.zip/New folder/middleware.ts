import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

import {
  LOCALE_COOKIE,
  THEME_COOKIE,
  LOGIN_RETURN_TO_COOKIE,
  DASHBOARD_PERIOD_COOKIE,
  sanitizeReturnTo,
} from '@/lib/auth-state';
import { SESSION_COOKIE } from '@/lib/server/auth';

const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

function isProtectedPath(pathname: string): boolean {
  if (pathname === '/') return false;
  if (pathname === '/login') return false;
  if (pathname.startsWith('/api/')) return false;
  if (pathname.startsWith('/saml/')) return false;
  return true;
}

function applyCookies(response: NextResponse, request: NextRequest, updates: Record<string, string | null>): void {
  const secure = request.nextUrl.protocol === 'https:';

  for (const [name, value] of Object.entries(updates)) {
    if (value === null) {
      response.cookies.set(name, '', { path: '/', maxAge: 0, sameSite: 'lax', secure });
      continue;
    }

    response.cookies.set(name, value, {
      path: '/',
      sameSite: 'lax',
      secure,
      maxAge: COOKIE_MAX_AGE_SECONDS,
    });
  }
}

export function middleware(request: NextRequest): NextResponse {
  const { nextUrl } = request;
  const pathname = nextUrl.pathname;
  const url = nextUrl.clone();
  const updates: Record<string, string | null> = {};
  let shouldRedirect = false;

  const lang = url.searchParams.get('lang');
  if (lang === 'ar' || lang === 'en') {
    updates[LOCALE_COOKIE] = lang;
    url.searchParams.delete('lang');
    shouldRedirect = true;
  }

  const theme = url.searchParams.get('theme');
  if (theme === 'light' || theme === 'dark') {
    updates[THEME_COOKIE] = theme;
    url.searchParams.delete('theme');
    shouldRedirect = true;
  }

  const next = url.searchParams.get('next');
  if (next) {
    updates[LOGIN_RETURN_TO_COOKIE] = sanitizeReturnTo(next);
    url.searchParams.delete('next');
    shouldRedirect = true;
  }

  const days = url.searchParams.get('days');
  if (days === '7' || days === '30' || days === '90') {
    updates[DASHBOARD_PERIOD_COOKIE] = days;
    url.searchParams.delete('days');
    shouldRedirect = true;
  }

  if (shouldRedirect) {
    const response = NextResponse.redirect(url, 307);
    applyCookies(response, request, updates);
    return response;
  }

  if (isProtectedPath(pathname) && !request.cookies.get(SESSION_COOKIE)?.value) {
    const response = NextResponse.redirect(new URL('/login', request.url), 307);
    applyCookies(response, request, {
      [LOGIN_RETURN_TO_COOKIE]: sanitizeReturnTo(`${pathname}${nextUrl.search}`),
    });
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)'],
};
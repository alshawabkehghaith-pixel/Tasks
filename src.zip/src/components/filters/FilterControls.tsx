'use client';

import { useMemo, useState } from 'react';
import { Check, Search, X } from 'lucide-react';

import { Badge } from '@/components/ui/Badge';
import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import { cn } from '@/lib/utils';

export interface FilterOption {
  value: string;
  label: string;
}

const SEARCH_THRESHOLD = 8;
const CHIP_VISIBLE = 3;
const OPTION_RENDER_CAP = 80;

export function FilterMultiSelectSection({
  label,
  hint,
  options,
  selected,
  onToggle,
  locale,
  searchPlaceholder,
  emptyLabel,
}: {
  label: string;
  hint?: string;
  options: FilterOption[];
  selected: string[];
  onToggle: (value: string) => void;
  locale: Locale;
  searchPlaceholder?: string;
  emptyLabel?: string;
}): JSX.Element {
  const [query, setQuery] = useState('');
  const searchable = options.length >= SEARCH_THRESHOLD;

  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase(locale === 'ar' ? 'ar' : 'en');
    if (!q) return options;
    return options.filter((option) => option.label.toLocaleLowerCase(locale === 'ar' ? 'ar' : 'en').includes(q));
  }, [options, query, locale]);

  const ordered = useMemo(() => {
    if (!query.trim()) {
      const selectedSet = new Set(selected);
      return [
        ...filtered.filter((option) => selectedSet.has(option.value)),
        ...filtered.filter((option) => !selectedSet.has(option.value)),
      ];
    }
    return filtered;
  }, [filtered, selected, query]);

  const visibleOptions = useMemo(
    () => ordered.slice(0, OPTION_RENDER_CAP),
    [ordered],
  );

  return (
    <section className="filter-drawer-section space-y-1 rounded-[18px] border border-black/6 bg-white/45 p-3 shadow-[0_12px_32px_rgba(15,23,42,0.06)] backdrop-blur-sm dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-3 pb-1">
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-ink dark:text-white">{label}</h3>
          {hint ? <p className="mt-0.5 text-[11px] leading-snug text-ink3">{hint}</p> : null}
        </div>
        {selected.length > 0 ? <span className="shrink-0 text-xs font-medium text-ink3">{selected.length}</span> : null}
      </div>

      {searchable ? (
        <label className="relative mb-1 block">
          <Search className="pointer-events-none absolute inset-y-0 left-3 my-auto h-3.5 w-3.5 text-ink3 rtl:left-auto rtl:right-3" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={searchPlaceholder ?? messages.filtersSearchOptions[locale]}
            aria-label={searchPlaceholder ?? messages.filtersSearchOptions[locale]}
            className="h-9 w-full rounded-xl border border-black/8 bg-white/70 pe-3 ps-9 text-xs text-ink outline-none placeholder:text-ink3 focus:border-green focus:ring-2 focus:ring-green/15 dark:border-white/10 dark:bg-white/[0.06] dark:text-ink"
          />
        </label>
      ) : null}

      <div className={cn('space-y-0.5', searchable && 'max-h-52 overflow-y-auto overscroll-contain pe-0.5')}>
        {visibleOptions.length > 0 ? (
          visibleOptions.map((option) => {
            const active = selected.includes(option.value);
            return (
              <button
                key={option.value}
                type="button"
                aria-pressed={active}
                onClick={() => onToggle(option.value)}
                className={cn(
                  'filter-drawer-option flex w-full items-center gap-3 rounded-xl px-3 py-2 text-start text-sm text-ink transition hover:bg-black/5 dark:text-ink dark:hover:bg-white/[0.07]',
                  active && 'bg-[color:rgb(var(--green-ch)/0.10)] text-greenDark dark:text-[#B9F3D5]',
                )}
              >
                <span className={cn('filter-drawer-check flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-black/10 bg-white/80 dark:border-white/10 dark:bg-white/[0.08]', active && 'border-green/30 bg-[color:rgb(var(--green-ch)/0.12)] dark:bg-[color:rgb(var(--green-ch)/0.20)]')}>
                  {active ? <Check size={12} strokeWidth={3} /> : null}
                </span>
                <span className="min-w-0 break-words">{option.label}</span>
              </button>
            );
          })
        ) : (
          <p className="px-1 py-2 text-xs text-ink3">{emptyLabel ?? messages.filtersNoOptionMatches[locale]}</p>
        )}
        {ordered.length > OPTION_RENDER_CAP && !query.trim() ? (
          <p className="px-1 pt-1 text-[11px] text-ink3">+{ordered.length - OPTION_RENDER_CAP}</p>
        ) : null}
      </div>
    </section>
  );
}

export function FilterActiveChipRow<TKey extends string>({
  chips,
  locale,
  onClearOne,
  onClearAll,
  onShowMore,
}: {
  chips: Array<{ key: TKey; value: string; label: string }>;
  locale: Locale;
  onClearOne: (key: TKey, value: string) => void;
  onClearAll: () => void;
  onShowMore?: () => void;
}): JSX.Element | null {
  if (chips.length === 0) return null;

  const visible = chips.slice(0, CHIP_VISIBLE);
  const hiddenCount = chips.length - visible.length;

  return (
    <div className="flex flex-wrap items-center gap-2" aria-label={messages.filtersActive[locale]}>
      {visible.map((chip) => (
        <Badge key={`${chip.key}-${chip.value}`} tone="active">
          <span className="max-w-[14rem] truncate">{chip.label}</span>
          <button
            type="button"
            className="rounded-full p-0.5 hover:bg-black/5 dark:hover:bg-white/10"
            onClick={() => onClearOne(chip.key, chip.value)}
            aria-label={messages.filtersRemoveOne[locale].replace('{label}', chip.label)}
          >
            <X size={12} strokeWidth={2.6} />
          </button>
        </Badge>
      ))}
      {hiddenCount > 0 ? (
        <button
          type="button"
          className="rounded-full border border-black/8 bg-white/70 px-2.5 py-1 text-xs font-semibold text-ink2 transition hover:bg-white dark:border-white/10 dark:bg-white/5 dark:text-ink3"
          onClick={onShowMore}
        >
          {messages.filtersMoreChips[locale].replace('{n}', String(hiddenCount))}
        </button>
      ) : null}
      <button type="button" className="text-sm font-medium text-ink2 underline decoration-dotted underline-offset-4 dark:text-ink3" onClick={onClearAll}>
        {messages.filtersClearAll[locale]}
      </button>
    </div>
  );
}

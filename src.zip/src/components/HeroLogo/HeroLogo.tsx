import Image from 'next/image';

import styles from './HeroLogo.module.css';

interface HeroLogoProps {
  src?: string;
  alt?: string;
  className?: string;
  priority?: boolean;
}

export function HeroLogo({
  src = '/Hero-Logo.png',
  alt = 'HRDF',
  className,
  priority = false,
}: HeroLogoProps): JSX.Element {
  return (
    <div className={`${styles.heroLogo}${className ? ` ${className}` : ''}`}>
      <span className={styles.rays} aria-hidden="true" />
      <span className={styles.beam} aria-hidden="true" />
      <span className={styles.glow} aria-hidden="true" />

      <div className={styles.logoWrap}>
        <Image
          src={src}
          alt={alt}
          fill
          sizes="(max-width: 720px) 80vw, (max-width: 1100px) 65vw, 55vw"
          className={styles.logo}
          priority={priority}
          quality={100}
          unoptimized={src.endsWith('.svg')}
        />
      </div>
    </div>
  );
}

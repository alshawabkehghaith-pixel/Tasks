'use client';

import { useState } from 'react';
import Image from 'next/image';

import { BrandWaves } from '@/components/brand/BrandWaves';
import { messages } from '@/i18n/catalog';
import { cn } from '@/lib/utils';
import type { Locale } from '@/types/jadarat';
import { ThemeToggle } from './ThemeToggle';
import styles from './LoginForm.module.css';

export interface LoginFormProps {
  initialLocale: Locale;
  theme: 'light' | 'dark';
  ssoLoginHrefAr: string;
  ssoLoginHrefEn: string;
  devLoginEnabled?: boolean;
  devLoginHrefAr?: string;
  devLoginHrefEn?: string;
}

const MOON = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" strokeLinejoin="round" />
  </svg>
);

const SUN = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true">
    <circle cx="12" cy="12" r="4.4" />
    <path d="M12 2.4v2.2M12 19.4v2.2M2.4 12h2.2M19.4 12h2.2M5.1 5.1l1.6 1.6M17.3 17.3l1.6 1.6M18.9 5.1l-1.6 1.6M6.7 17.3l-1.6 1.6" strokeLinecap="round" />
  </svg>
);

const LANG = (
  <svg width="14" height="14" viewBox="0 -960 960 960" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="m582.3-164.78-28.95 73.13q-4.13 11.39-14.18 18.59-10.04 7.19-22.43 7.19-21.09 0-32.91-16.67-11.83-16.68-4.7-36.76l154.35-412.18q5.13-14.95 18.02-24.28 12.89-9.33 28.98-9.33h38.04q15.52 0 28.7 9.33 13.17 9.33 18.3 24.28L919.3-120.43q7.7 20.65-4.41 37.6-12.11 16.96-33.76 16.96-12.83 0-23.43-7.48-10.61-7.48-14.74-19.3l-28.39-72.13H582.3ZM352.83-380.09 183-210.7q-12.39 11.4-28.07 11.61-15.67.22-27.5-12.17-12.39-11.83-12.39-27.78 0-15.96 12.39-27.79l170.39-170.39q-54.95-57.52-90.58-112.58-35.63-55.07-51.94-105.11h89.31q12.61 36.21 39.82 75.95 27.22 39.74 70.53 84.61 44.87-48 82.17-114.39 37.3-66.39 52.61-126.17H62.65q-16.95 0-28.28-11.33-11.33-11.33-11.33-28.28 0-16.96 11.33-28.57t28.28-11.61h250.39v-39.82q0-16.96 11.33-28.57t28.28-11.61q16.96 0 28.57 11.61t11.61 28.57v39.82h249.82q16.96 0 28.57 11.61t11.61 28.57q0 16.95-11.61 28.28-11.61 11.33-28.57 11.33h-67.17q-17.57 75.74-62.91 156.95-45.35 81.22-102.61 141.18l81.65 83.08-31.35 85.05-107.43-111.44Zm256.69 140.53h177.83l-88.92-236.7-88.91 236.7Z" fill="currentColor" />
  </svg>
);

const ARROW = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
    <path d="M5.5 12h12.2M12.4 6.4l5.6 5.6-5.6 5.6" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const LOCALE_COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

export function LoginForm({
  initialLocale,
  theme,
  ssoLoginHrefAr,
  ssoLoginHrefEn,
  devLoginEnabled = false,
  devLoginHrefAr,
  devLoginHrefEn,
}: LoginFormProps): JSX.Element {
  const [locale, setLocale] = useState<Locale>(initialLocale);
  const currentYear = new Date().getFullYear();

  function handleLangClick(): void {
    const next: Locale = locale === 'ar' ? 'en' : 'ar';
    setLocale(next);

    const root = document.documentElement;
    root.setAttribute('lang', next);
    root.setAttribute('dir', next === 'ar' ? 'rtl' : 'ltr');

    try {
      localStorage.setItem('locale', next);
    } catch {
    }

    const secure = window.location.protocol === 'https:' ? '; secure' : '';
    document.cookie = `locale=${next}; path=/; max-age=${LOCALE_COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;
  }

  const ssoLoginHref = locale === 'ar' ? ssoLoginHrefAr : ssoLoginHrefEn;
  const devLoginHref = locale === 'ar' ? devLoginHrefAr : devLoginHrefEn;

  return (
    <div className={styles.page} data-surface="login">
      <BrandWaves intensity="full" idPrefix="login-wave" className={styles.waves} />

      <span className={styles.grain} aria-hidden="true" />

      <div className={styles.topActions}>
        <ThemeToggle
          initialTheme={theme}
          labelToLight={locale === 'ar' ? 'الوضع النهاري' : 'Light mode'}
          labelToDark={locale === 'ar' ? 'الوضع الليلي' : 'Dark mode'}
          className={cn(styles.iconBtn)}
          sunIcon={SUN}
          moonIcon={MOON}
        />

        <button
          type="button"
          className={styles.langToggle}
          onClick={handleLangClick}
          aria-label={locale === 'ar' ? 'English' : 'العربية'}
        >
          {LANG}
        </button>
      </div>

      <div className={styles.slab}>
        <span className={styles.specular} aria-hidden="true" />

        <div className={styles.content}>
          <div className={styles.logoStage}>
            <div className={styles.partnerRow}>
              <Image
                src="/logo.svg"
                alt=""
                width={168}
                height={56}
                className={styles.partnerLogo}
                priority
                unoptimized
              />
              <span className={styles.logoRule} aria-hidden="true" />
              <Image
                src="/jadarat_transparent.png"
                alt=""
                width={168}
                height={56}
                className={styles.topBarLogo}
                priority
                unoptimized
              />
            </div>

            <Image
              src="/jme_nav_transparent.png"
              alt=""
              width={140}
              height={44}
              className={styles.platformLogo}
              priority
              unoptimized
            />
          </div>

          <a className={cn(styles.cta, 'no-underline')} href={ssoLoginHref}>
            <span className={styles.ctaLabel}>{messages.ssoLoginCta[locale]}</span>
            <span className={styles.ctaIsland} aria-hidden="true">{ARROW}</span>
          </a>

          <p className={styles.hint}>{messages.ssoLoginHint[locale]}</p>

          {devLoginEnabled && devLoginHref ? (
            <a className={styles.dev} href={devLoginHref}>
              {messages.devLoginCta[locale]}
            </a>
          ) : null}
        </div>
      </div>

      <footer className={styles.footer} role="contentinfo" suppressHydrationWarning>
        {locale === 'ar'
          ? `جميع الحقوق محفوظة لصندوق تنمية الموارد البشرية © ${currentYear}`
          : `All Rights Reserved Human Resources Development Fund © ${currentYear}`}
      </footer>
    </div>
  );
}

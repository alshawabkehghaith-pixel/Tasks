'use client';

import { useState } from 'react';
import type { ReactNode } from 'react';

const THEME_COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

export interface ThemeToggleProps {
  initialTheme: 'light' | 'dark';
  labelToLight: string;
  labelToDark: string;
  className: string;
  sunIcon: ReactNode;
  moonIcon: ReactNode;
}

export function ThemeToggle({
  initialTheme,
  labelToLight,
  labelToDark,
  className,
  sunIcon,
  moonIcon,
}: ThemeToggleProps): JSX.Element {
  const [theme, setTheme] = useState(initialTheme);

  function handleClick(): void {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);

    try {
      localStorage.setItem('theme', next);
    } catch {
      // ignore quota / private-mode failures
    }

    const secure = window.location.protocol === 'https:' ? '; secure' : '';
    document.cookie = `theme=${next}; path=/; max-age=${THEME_COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;
  }

  const label = theme === 'dark' ? labelToLight : labelToDark;

  return (
    <button type="button" className={className} onClick={handleClick} title={label} aria-label={label}>
      {theme === 'dark' ? sunIcon : moonIcon}
    </button>
  );
}

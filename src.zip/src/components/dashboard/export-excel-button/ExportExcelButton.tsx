'use client';

import { useState } from 'react';
import { FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

import type { CoverageLevel, DashboardSnapshot } from '@/types/domain';
import type { Locale } from '@/types/jadarat';
import { messages } from '@/i18n/catalog';

interface Props {
  data: DashboardSnapshot;
  locale: Locale;
  className?: string;
}

type MsgKey = keyof typeof messages;

function t(key: MsgKey, lc: Locale): string {
  return messages[key][lc];
}

const L = {
  exportBtn:     { en: 'Export Excel',       ar: 'تصدير إكسل'         },
  exporting:     { en: 'Exporting…',         ar: 'جارٍ التصدير…'      },
  metric:        { en: 'Metric',             ar: 'المقياس'             },
  value:         { en: 'Value',              ar: 'القيمة'              },
  count:         { en: 'Count',              ar: 'العدد'               },
  status:        { en: 'Status',             ar: 'الحالة'              },
  stage:         { en: 'Stage',              ar: 'المرحلة'             },
  fieldCol:      { en: 'Missing Field',      ar: 'الحقل الناقص'        },
  candidates:    { en: 'Candidates',         ar: 'المرشّحون'            },
  category:      { en: 'Job Category',       ar: 'الفئة الوظيفية'      },
  demand:        { en: 'Demand',             ar: 'الطلب'               },
  supply:        { en: 'Supply',             ar: 'العرض'               },
  coverage:      { en: 'Coverage',           ar: 'التغطية'             },
  range:         { en: 'Score Range',        ar: 'نطاق الدرجة'         },
  matchesCol:    { en: 'Matches',            ar: 'مطابقات'             },
  salBand:       { en: 'Salary Band',        ar: 'فئة الراتب'          },
  jobs:          { en: 'Jobs',               ar: 'وظائف'               },
  date:          { en: 'Date',               ar: 'التاريخ'             },
  reviews:       { en: 'Reviews',            ar: 'مراجعات'             },
  approvals:     { en: 'Approvals',          ar: 'اعتمادات'            },
  notifs:        { en: 'Notifications',      ar: 'إشعارات'             },
  sheetKPIs:     { en: 'KPIs',               ar: 'المؤشرات'            },
  sheetReady:    { en: 'Readiness',          ar: 'جاهزية الملفات'      },
  sheetFollowUp: { en: 'Follow-Up Gaps',     ar: 'الحقول الناقصة'      },
  sheetPipeline: { en: 'Talent Pipeline',    ar: 'مسار المواهب'        },
  sheetSupply:   { en: 'Supply & Demand',    ar: 'العرض والطلب'        },
  sheetScore:    { en: 'Score Distribution', ar: 'توزيع الدرجات'       },
  sheetActivity: { en: 'Activity',           ar: 'النشاط'              },
  sheetSalary:   { en: 'Jobs by Salary',     ar: 'الوظائف بالراتب'     },
} as const;

const HEADER_BG  = 'FF0C6E4A';
const HEADER_FG  = 'FFFFFFFF';
const STRIPE     = 'FFF7F7F7';
const BORDER_CLR = 'FFD0D0D0';

const COVERAGE_LABEL: Record<CoverageLevel, Record<Locale, string>> = {
  good:     { en: 'Good',     ar: 'توافق' },
  moderate: { en: 'Moderate', ar: 'متوسط' },
  gap:      { en: 'Gap',      ar: 'فجوة'  },
  surplus:  { en: 'Surplus',  ar: 'فائض'  },
};

export function ExportExcelButton({ data, locale, className }: Props): JSX.Element {
  const [busy, setBusy] = useState(false);

  async function handleExport(): Promise<void> {
    if (busy) return;
    setBusy(true);
    try {

      const { Workbook } = await import('exceljs');
      const wb = new Workbook();
      wb.creator  = 'JME Dashboard';
      wb.created  = new Date();
      wb.modified = new Date();

      const lc = locale;

      const periodPrefix = lc === 'ar' ? 'الفترة: ' : 'Period: ';
      const today = new Date();
      const fmt = (d: Date) =>
        d.toLocaleDateString(lc === 'ar' ? 'ar-SA' : 'en-GB', {
          day: 'numeric', month: 'short', year: 'numeric',
        });
      const periodLabel = (() => {
        const daysBack = parseInt(data.period, 10);
        const from = new Date(today);
        from.setDate(from.getDate() - daysBack);
        return `${periodPrefix}${fmt(from)} – ${fmt(today)}`;
      })();

      type ColDef = { header: string; key: string; width: number };

      const borderSide = () => ({ style: 'thin' as const, color: { argb: BORDER_CLR } });
      const allBorders = () => {
        const s = borderSide();
        return { top: s, left: s, bottom: s, right: s };
      };

      function buildSheet(name: string, cols: ColDef[]) {
        const ws = wb.addWorksheet(name);
        ws.columns = cols.map((c) => ({ key: c.key, width: c.width, header: '' }));

        const numCols = cols.length;
        const pRow = ws.getRow(1);
        const pCell = pRow.getCell(1);
        pCell.value     = periodLabel;
        pCell.font      = { italic: true, color: { argb: 'FF3D5A4E' }, size: 10, name: 'Calibri' };
        pCell.fill      = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD6EDE3' } };
        pCell.alignment = { horizontal: lc === 'ar' ? 'right' : 'left', vertical: 'middle' };
        if (numCols > 1) ws.mergeCells(1, 1, 1, numCols);
        pRow.height = 18;
        pRow.commit();

        const hRow = ws.getRow(2);
        cols.forEach((col, i) => {
          const cell     = hRow.getCell(i + 1);
          cell.value     = col.header;
          cell.fill      = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_BG } };
          cell.font      = { bold: true, color: { argb: HEADER_FG }, size: 11, name: 'Calibri' };
          cell.alignment = { horizontal: 'left', vertical: 'middle' };
          cell.border    = allBorders();
        });
        hRow.height = 26;
        hRow.commit();
        return ws;
      }

      function addRow(
        ws: ReturnType<typeof buildSheet>,
        values: (string | number | null)[],
        rowIdx: number,
      ): void {
        const row = ws.addRow(values);
        row.eachCell({ includeEmpty: true }, (cell) => {
          cell.border    = allBorders();
          cell.alignment = { horizontal: 'left', vertical: 'middle' };
          if (rowIdx % 2 === 0) {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: STRIPE } };
          }
        });
        row.height = 20;
        row.commit();
      }

      const wsKPIs = buildSheet(L.sheetKPIs[lc], [
        { header: L.metric[lc], key: 'metric', width: 38 },
        { header: L.value[lc],  key: 'value',  width: 22 },
      ]);
      const kpiRows: [string, string | number][] = [
        [t('dashKpiCandidates', lc),    data.kpis.candidates],
        [t('dashKpiEmployers', lc),     data.kpis.employers],
        [t('dashKpiActiveJobs', lc),    data.kpis.activeJobs],
        [t('dashKpiOpenPositions', lc), data.kpis.openPositions],
        [t('dashKpiMatches', lc),       data.kpis.matchesCreated],
        [t('dashKpiStrong', lc),        data.kpis.strongMatches],
        [t('dashKpiAvgScore', lc),      `${data.kpis.avgMatchScore}%`],
        [t('dashKpiReadyPct', lc),      `${data.readiness.readyPct}%`],
      ];
      kpiRows.forEach(([metric, value], i) => addRow(wsKPIs, [metric, value], i));

      const wsReady = buildSheet(L.sheetReady[lc], [
        { header: L.status[lc], key: 'status', width: 32 },
        { header: L.count[lc],  key: 'count',  width: 22 },
      ]);
      const readyRows: [string, number][] = [
        [t('dashReadinessReady', lc),      data.readiness.ready],
        [t('dashReadinessPartial', lc),    data.readiness.partial],
        [t('dashReadinessIncomplete', lc), data.readiness.incomplete],
        [t('dashRecentGrads', lc),         data.readiness.recentGrads],
      ];
      readyRows.forEach(([status, count], i) => addRow(wsReady, [status, count], i));

      const wsFollowUp = buildSheet(L.sheetFollowUp[lc], [
        { header: L.fieldCol[lc],   key: 'field',      width: 38 },
        { header: L.candidates[lc], key: 'candidates', width: 22 },
      ]);
      data.followUp.forEach((item, i) => addRow(wsFollowUp, [item.field, item.count], i));

      const wsPipeline = buildSheet(L.sheetPipeline[lc], [
        { header: L.stage[lc], key: 'stage', width: 32 },
        { header: L.count[lc], key: 'count', width: 22 },
      ]);
      const pipelineRows: [string, number][] = [
        [t('dashPipelineStageMatched', lc),  data.talentPipeline.matched],
        [t('dashKpiStrong', lc),             data.talentPipeline.highMatch],
        [t('dashPipelineStageReviewed', lc), data.talentPipeline.reviewed],
        [t('dashPipelineStageApproved', lc), data.talentPipeline.approved],
        [t('dashPipelineStageNotified', lc), data.talentPipeline.notified],
      ];
      pipelineRows.forEach(([stage, count], i) => addRow(wsPipeline, [stage, count], i));

      const wsSupply = buildSheet(L.sheetSupply[lc], [
        { header: L.category[lc], key: 'category', width: 36 },
        { header: L.demand[lc],   key: 'demand',   width: 20 },
        { header: L.supply[lc],   key: 'supply',   width: 20 },
        { header: L.coverage[lc], key: 'coverage', width: 22 },
      ]);
      data.supplyDemand.forEach((row, i) => {
        addRow(wsSupply, [row.category, row.demand, row.supply, COVERAGE_LABEL[row.coverage][lc]], i);
      });

      const wsScore = buildSheet(L.sheetScore[lc], [
        { header: L.range[lc],      key: 'range',   width: 28 },
        { header: L.matchesCol[lc], key: 'matches', width: 22 },
      ]);
      data.scoreBands.forEach((band, i) => addRow(wsScore, [band.range, band.count], i));

      const wsActivity = buildSheet(L.sheetActivity[lc], [
        { header: L.date[lc],      key: 'date',      width: 20 },
        { header: L.reviews[lc],   key: 'reviews',   width: 20 },
        { header: L.approvals[lc], key: 'approvals', width: 20 },
        { header: L.notifs[lc],    key: 'notifs',    width: 22 },
      ]);
      data.timeline.forEach((pt, i) =>
        addRow(wsActivity, [pt.date, pt.reviews, pt.approvals, pt.notifications], i),
      );

      const wsSalary = buildSheet(L.sheetSalary[lc], [
        { header: L.salBand[lc], key: 'salBand', width: 30 },
        { header: L.jobs[lc],    key: 'jobs',    width: 22 },
      ]);
      data.jobsBySalary.forEach((row, i) => addRow(wsSalary, [row.label, row.value], i));

      const periodSlug = `${data.period}d`;
      const dateStamp  = new Date().toISOString().slice(0, 10);
      const filename   = `jme-dashboard-${periodSlug}-${dateStamp}.xlsx`;

      const buffer = await wb.xlsx.writeBuffer();
      const blob   = new Blob([buffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      const url = URL.createObjectURL(blob);
      const a   = document.createElement('a');
      a.href     = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(
        locale === 'ar' ? 'تم تصدير الملف بنجاح' : 'Export complete',
        { description: filename },
      );
    } catch {
      toast.error(
        locale === 'ar' ? 'فشل تصدير الملف' : 'Export failed',
        { description: locale === 'ar' ? 'يرجى المحاولة مرة أخرى' : 'Please try again' },
      );
    } finally {
      setBusy(false);
    }
  }

  const label = L[busy ? 'exporting' : 'exportBtn'][locale];

  return (
    <button
      type="button"
      onClick={handleExport}
      disabled={busy}
      aria-label={label}
      className={className}
    >
      <FileSpreadsheet size={14} aria-hidden="true" />
      {label}
    </button>
  );
}

'use client';

import type { LucideIcon } from 'lucide-react';

import { CountUpNumber } from '@/components/dashboard/count-up-number/CountUpNumber';
import styles from './KpiCard.module.css';

interface KpiCardProps {
  label: string;
  value: number;
  icon: LucideIcon;
  secondaryNote?: string;
  animateStart: boolean;
}

export function KpiCard({
  label,
  value,
  icon: Icon,
  secondaryNote,
  animateStart,
}: KpiCardProps): JSX.Element {
  return (
    <div className={styles.card}>
      <div className={styles.top}>
        <span className={styles.iconBadge} aria-hidden="true">
          <Icon size={18} strokeWidth={2} color="currentColor" />
        </span>
        <span className={styles.label}>{label}</span>
      </div>

      <div className={styles.middle}>
        <div className={styles.value}>
          {animateStart
            ? <CountUpNumber value={value} />
            : <span>{value.toLocaleString()}</span>}
        </div>
      </div>

      {secondaryNote ? (
        <div className={styles.bottom}>
          <span className={styles.secondary}>{secondaryNote}</span>
        </div>
      ) : null}
    </div>
  );
}
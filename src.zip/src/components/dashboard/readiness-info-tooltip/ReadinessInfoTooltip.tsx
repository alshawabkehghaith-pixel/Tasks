'use client';

import { useEffect, useId, useState } from 'react';

import styles from './ReadinessInfoTooltip.module.css';

interface ReadinessInfoTooltipProps {
  label: string;
  text: string;
}

export function ReadinessInfoTooltip({ label, text }: ReadinessInfoTooltipProps): JSX.Element {
  const [open, setOpen] = useState(false);
  const tooltipId = useId();

  useEffect(() => {
    if (!open) {
      return;
    }

    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        setOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open]);

  return (
    <span
      className={styles.info_tip}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) {
          setOpen(false);
        }
      }}
    >
      <button
        type="button"
        className={styles.btn}
        aria-label={label}
        aria-expanded={open}
        aria-describedby={open ? tooltipId : undefined}
        onFocus={() => setOpen(true)}
        onClick={() => setOpen((prev) => !prev)}
      >
        <span aria-hidden="true">i</span>
      </button>

      <span id={tooltipId} role="tooltip" className={`${styles.pop}${open ? ` ${styles.open}` : ''}`}>
        {text}
      </span>
    </span>
  );
}
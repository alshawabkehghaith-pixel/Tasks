'use client';

import { Bar, BarChart, CartesianGrid, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

import { messages } from '@/i18n/catalog';
import { formatChartLabel, formatSalaryBandLabel } from '@/lib/chart-format';
import type { JobDistributionRow } from '@/types/domain';
import type { Locale } from '@/types/jadarat';

import styles from './JobsBySalaryChart.module.css';

const CHART_HEIGHT_PX = 260;

interface TooltipProps {
  active?: boolean;
  payload?: { value?: number }[];
  label?: string;
  barColor: string;
}

function SalaryTooltip({ active, payload, label, barColor }: TooltipProps): JSX.Element | null {
  if (!active || !payload?.length) return null;
  const value = payload[0]?.value ?? 0;

  return (
    <div className={styles.tooltip}>
      <div className={styles.tooltipLabel} dir="ltr">
        {label ? formatSalaryBandLabel(label) : label}
      </div>
      <div className={styles.tooltipValueRow}>
        <span className={styles.tooltipDot} style={{ background: barColor }} aria-hidden="true" />
        <span className={styles.tooltipValue}>{value.toLocaleString()}</span>
      </div>
    </div>
  );
}

export interface JobsBySalaryChartProps {
  rows: JobDistributionRow[];
  barColor: string;
  locale: Locale;
}

export function JobsBySalaryChart({ rows, barColor, locale }: JobsBySalaryChartProps): JSX.Element {
  return (
    <div className={styles.chartFrame}>
      <ResponsiveContainer width="100%" height={CHART_HEIGHT_PX}>
        <BarChart data={rows} margin={{ top: 24, right: 6, left: 10, bottom: 36 }}>
          <CartesianGrid vertical={false} stroke="var(--line)" />
          <XAxis
            dataKey="label"
            axisLine={false}
            tickLine={false}
            tickFormatter={formatSalaryBandLabel}
            tick={{ fontSize: 11, fill: 'var(--text-faint)' }}
            label={{
              value: messages.dashJobsBySalaryXAxis[locale],
              position: 'insideBottom',
              offset: -20,
              fontSize: 12,
              fill: 'var(--text-soft)',
            }}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tick={{ fontSize: 12, fill: 'var(--text-faint)' }}
            width={52}
            label={{
              value: messages.dashJobsBySalaryYAxis[locale],
              angle: -90,
              position: 'insideLeft',
              offset: 10,
              fontSize: 12,
              fill: 'var(--text-soft)',
            }}
          />
          <Tooltip
            cursor={{ fill: 'color-mix(in srgb, var(--brand) 6%, transparent)' }}
            content={<SalaryTooltip barColor={barColor} />}
          />
          <Bar
            dataKey="value"
            fill={barColor}
            radius={[6, 6, 0, 0]}
            maxBarSize={48}
            isAnimationActive
            animationDuration={700}
            animationEasing="ease-out"
          >
            <LabelList
              dataKey="value"
              position="top"
              style={{ fontSize: 11, fill: 'var(--text-soft)', fontWeight: 600 }}
              formatter={formatChartLabel}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

'use client';

import type { JSX } from 'react';
import { ChartColumn } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { ReadinessInfoTooltip } from '@/components/dashboard/readiness-info-tooltip/ReadinessInfoTooltip';
import { useInViewOnce } from '@/hooks/useInViewOnce';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import { formatChartLabel } from '@/lib/chart-format';
import { ICON_STROKE } from '@/lib/icons';
import type { ScoreBand } from '@/types/domain';

import styles from './ScoreDistribution.module.css';

interface ScoreDistributionProps {
  bands: ScoreBand[];
  locale: Locale;
}

const CHART_HEIGHT_PX = 230;

interface TooltipPayloadRow {
  payload?: ScoreBand;
  value?: number;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadRow[];
  label?: string;
  locale: Locale;
}

function formatScoreRangeLabel(value: string): string {
  if (value.includes('-')) {
    const [start, end] = value.split('-');
    if (start && end) {
      return `${start}%-${end}%`;
    }
  }

  if (value.startsWith('<')) {
    return `${value}%`;
  }

  return value;
}

function CustomTooltip({ active, payload, label, locale }: CustomTooltipProps): JSX.Element | null {
  if (!active || !payload?.length) {
    return null;
  }

  const entry = payload[0] as TooltipPayloadRow | undefined;
  const count = entry?.payload?.count ?? entry?.value ?? 0;
  const matchesLabel = messages.dashScoreMatches[locale];

  return (
    <div className={styles.tooltip}>
      <div className={styles.tooltipLabel}>{label ? formatScoreRangeLabel(label) : label}</div>
      <div className={styles.tooltipValueRow}>
        <span className={styles.tooltipDot} aria-hidden="true" />
        <span className={styles.tooltipValue}>{count.toLocaleString()}</span>
        <span className={styles.tooltipValueSoft}>{matchesLabel}</span>
      </div>
    </div>
  );
}

export function ScoreDistribution({ bands, locale }: ScoreDistributionProps): JSX.Element {
  const { ref, visible } = useInViewOnce<HTMLDivElement>();
  const isArabic = locale === 'ar';
  const yAxisWidth = isArabic ? 78 : 56;
  const chartLeft = isArabic ? 36 : 22;

  return (
    <SurfaceCard className={`card ${styles.card}`}>
      <div className={styles.accent} aria-hidden="true" />
      <div className={styles.corner} aria-hidden="true" />

      <div className={styles.header}>
        <span className={styles.badge} aria-hidden="true">
          <ChartColumn size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <div className={styles.headingGroup}>
          <div className={styles.titleRow}>
            <h2 className={styles.title}>{messages.dashScoreTitle[locale]}</h2>
            <ReadinessInfoTooltip
              label={messages.dashScoreInfoLabel[locale]}
              text={messages.dashScoreInfoTooltip[locale]}
            />
          </div>
        </div>
      </div>

      <div ref={ref} className={styles.chartMount}>
        {!visible ? (
          <div className={styles.placeholder} />
        ) : (
          <div className={styles.chartFrame}>
            <ResponsiveContainer width="100%" height={CHART_HEIGHT_PX}>
              <BarChart data={bands} margin={{ top: 24, right: 8, left: chartLeft, bottom: 24 }}>
                <CartesianGrid vertical={false} stroke="var(--line)" />
                <XAxis
                  dataKey="range"
                  tickFormatter={(value: string) => formatScoreRangeLabel(value)}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'var(--text-faint)' }}
                  label={{ value: locale === 'ar' ? 'درجة المطابقة' : 'Match Score', position: 'insideBottom', offset: -10, fill: 'var(--text-faint)', fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'var(--text-faint)' }}
                  width={yAxisWidth}
                  tickMargin={isArabic ? 12 : 8}
                  label={{
                    value: locale === 'ar' ? 'عدد المرشحين' : 'Number of Candidates',
                    angle: -90,
                    position: 'insideLeft',
                    offset: isArabic ? 4 : 0,
                    fill: 'var(--text-faint)',
                    fontSize: 12,
                    dx: isArabic ? -10 : -8,
                    style: { textAnchor: 'middle' },
                  }}
                />
                <Tooltip
                  cursor={{ fill: 'transparent' }}
                  content={<CustomTooltip locale={locale} />}
                />
                <Bar
                  dataKey="count"
                  fill="var(--brand)"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={44}
                  className={styles.rechartsBar}
                  activeBar={{ fill: 'color-mix(in srgb, var(--brand) 82%, white)' }}
                  isAnimationActive
                  animationDuration={700}
                  animationEasing="ease-out"
                >
                  <LabelList dataKey="count" position="top" style={{ fontSize: 11, fill: 'var(--text-soft)', fontWeight: 600 }} formatter={formatChartLabel} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </SurfaceCard>
  );
}
'use client';

import { useEffect, useState } from 'react';
import { Waypoints } from 'lucide-react';

import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { useInViewOnce } from '@/hooks/useInViewOnce';
import { messages } from '@/i18n/catalog';
import { ICON_STROKE } from '@/lib/icons';
import type { TalentPipelineMetrics } from '@/types/domain';
import type { Locale } from '@/types/jadarat';
import styles from './TalentPipeline.module.css';

const NODE_LAYOUT = [
  { id: 'matched', x: 90, y: 145, stroke: 'var(--ink)', labelKey: 'dashPipelineMatched' },
  { id: 'highMatch', x: 600, y: 45, stroke: 'var(--brand)', labelKey: 'dashPipelineHighMatch' },
  { id: 'reviewed', x: 340, y: 245, stroke: 'var(--accent)', labelKey: 'dashPipelineLowMatch' },
  { id: 'approved', x: 860, y: 245, stroke: 'var(--accent)', labelKey: 'dashPipelineApproved' },
  { id: 'notified', x: 1110, y: 145, stroke: 'var(--ink)', labelKey: 'dashPipelineNotified' },
] as const satisfies readonly {
  id: keyof TalentPipelineMetrics;
  x: number;
  y: number;
  stroke: string;
  labelKey: keyof typeof messages;
}[];

const VIEWBOX_WIDTH = 1200;

const PATH_HIGH_MATCH =
  'M 90,145 C 345,145 345,45 600,45 C 855,45 855,145 1110,145';
const PATH_HIGH_MATCH_RTL =
  'M 1110,145 C 855,145 855,45 600,45 C 345,45 345,145 90,145';

const PATH_REVIEW =
  'M 90,145 C 215,145 215,245 340,245 C 600,245 600,245 860,245 C 985,245 985,145 1110,145';
const PATH_REVIEW_RTL =
  'M 1110,145 C 985,145 985,245 860,245 C 600,245 600,245 340,245 C 215,245 215,145 90,145';

interface TalentPipelineCardProps {
  data: TalentPipelineMetrics;
  locale: Locale;
}

export function TalentPipelineCard({ data, locale }: TalentPipelineCardProps): JSX.Element {
  const { ref, visible } = useInViewOnce<HTMLDivElement>();
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const isRtl = locale === 'ar';
  const m = (key: keyof typeof messages): string => messages[key][locale];
  const dashTo = isRtl ? '240' : '-240';
  const motionPathHigh = isRtl ? PATH_HIGH_MATCH_RTL : PATH_HIGH_MATCH;
  const motionPathReview = isRtl ? PATH_REVIEW_RTL : PATH_REVIEW;

  const nodes = NODE_LAYOUT.map((node) => ({
    ...node,
    x: isRtl ? VIEWBOX_WIDTH - node.x : node.x,
    value: data[node.id],
    label: m(node.labelKey),
  }));

  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const sync = (): void => setPrefersReducedMotion(media.matches);
    sync();
    media.addEventListener('change', sync);
    return () => media.removeEventListener('change', sync);
  }, []);

  return (
    <SurfaceCard className={`card ${styles.pipe_card}`}>
      <div className={styles.pipe_accent} aria-hidden="true" />

      {}
      <div className={styles.pipe_header}>
        <span className={styles.pipe_badge} aria-hidden="true">
          <Waypoints size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <h2 className={styles.pipe_title}>{m('dashPipelineTitle')}</h2>
      </div>

      {}
      <div className={styles.pipe_viz}>
        {}
        <div ref={ref} className={styles.pipe_plot}>

          {}
          <svg
            className={styles.pipe_svg}
            viewBox={`0 0 ${VIEWBOX_WIDTH} 300`}
            aria-hidden="true"
            preserveAspectRatio="none"
          >
            {}
            <path d={PATH_HIGH_MATCH} className={styles.pipe_basePath} />
            <path d={PATH_REVIEW}     className={styles.pipe_basePath} />

            {}
            <path d={PATH_HIGH_MATCH} className={styles.pipe_flowHigh}>
              {!prefersReducedMotion && (
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to={dashTo}
                  dur="7s"
                  repeatCount="indefinite"
                />
              )}
            </path>
            <path d={PATH_REVIEW} className={styles.pipe_flowReview}>
              {!prefersReducedMotion && (
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to={dashTo}
                  dur="9s"
                  repeatCount="indefinite"
                />
              )}
            </path>

            {}
            {!prefersReducedMotion && (
              <>
                <circle r="4.5" className={styles.pipe_dotHigh}>
                  <animateMotion dur="7s" repeatCount="indefinite" path={motionPathHigh} />
                </circle>
                <circle r="4.5" className={styles.pipe_dotReview}>
                  <animateMotion dur="9s" repeatCount="indefinite" path={motionPathReview} />
                </circle>
              </>
            )}

            {}
            {nodes.map((node, i) => (
              <circle
                key={node.id}
                cx={node.x}
                cy={node.y}
                r={6.5}
                stroke={node.stroke}
                className={`${styles.pipe_nodeCircle} ${visible ? styles.pipe_nodeCircleVisible : ''}`}
                style={{ transitionDelay: visible ? `${i * 110}ms` : '0ms' }}
              />
            ))}
          </svg>

          {}
          {nodes.map((node, i) => (
            <div
              key={`${node.id}-label`}
              className={[
                styles.pipe_label,
                node.y < 90 ? styles.pipe_labelAbove : styles.pipe_labelBelow,
                visible ? styles.pipe_labelVisible : '',
              ].join(' ')}
              style={{
                left: `${(node.x / VIEWBOX_WIDTH) * 100}%`,
                top:  `${(node.y / 300)  * 100}%`,
                transitionDelay: visible ? `${i * 110}ms` : '0ms',
              }}
              dir={isRtl ? 'rtl' : 'ltr'}
            >
              <div className={styles.pipe_nodeValue}>{node.value}</div>
              <div className={styles.pipe_nodeLabel}>{node.label}</div>
            </div>
          ))}
        </div>
      </div>
    </SurfaceCard>
  );
}

'use client';

import { useEffect, useLayoutEffect, useRef, useState, useTransition } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { BriefcaseBusiness, GitCompareArrows, UserRound } from 'lucide-react';

import type { Locale } from '@/types/jadarat';
import { messages } from '@/i18n/catalog';
import { writeDashboardPeriodCookie } from '@/lib/dashboard-period';
import { buildHref, type QueryInput } from '@/lib/routing';
import {
  hasSeenDashboardHeroIntro,
  markDashboardHeroIntroSeen,
} from '@/lib/hero-intro-storage';

import { ExportExcelButton } from '@/components/dashboard/export-excel-button/ExportExcelButton';
import { HeroLogo } from '@/components/HeroLogo/HeroLogo';
import { BrandWaves } from '@/components/brand/BrandWaves';
import { KpiCard } from '@/components/dashboard/kpi-card/KpiCard';
import type { DashboardSnapshot } from '@/types/domain';
import styles from './GreetingHero.module.css';

interface GreetingHeroProps {
  data: DashboardSnapshot;
  locale: Locale;
  query: QueryInput;
  userName: string;
  introSeen?: boolean;
  onLiftedChange?: (lifted: boolean) => void;
}

const SPLASH_IN_MS = 40;
const TYPE_DELAY_MS = 480;
const CHAR_STEP_MS = 42;
const PAUSE_AFTER_TYPE_MS = 560;

type IntroPhase = 'booting' | 'playing' | 'settled';

type IntroBoot = {
  phase: IntroPhase;
  typed: string;
  shrunk: boolean;
  lifted: boolean;
  revealed: boolean;
  splashReady: boolean;
  skipHeroMotion: boolean;
  playIntro: boolean;
};

function settledBoot(greetingFull: string): IntroBoot {
  return {
    phase: 'settled',
    typed: greetingFull,
    shrunk: true,
    lifted: true,
    revealed: true,
    splashReady: false,
    skipHeroMotion: true,
    playIntro: false,
  };
}

function readIntroBoot(greetingFull: string, introSeenHint = false): IntroBoot {
  if (introSeenHint) {
    return settledBoot(greetingFull);
  }

  if (typeof window === 'undefined') {
    return {
      phase: 'booting',
      typed: '',
      shrunk: false,
      lifted: false,
      revealed: false,
      splashReady: false,
      skipHeroMotion: false,
      playIntro: false,
    };
  }

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (hasSeenDashboardHeroIntro() || reduced) {
    return settledBoot(greetingFull);
  }

  return {
    phase: 'booting',
    typed: '',
    shrunk: false,
    lifted: false,
    revealed: false,
    splashReady: false,
    skipHeroMotion: false,
    playIntro: false,
  };
}

export function GreetingHero({
  data,
  locale,
  query,
  userName,
  introSeen = false,
  onLiftedChange,
}: GreetingHeroProps): JSX.Element {
  const router = useRouter();
  const [isPeriodPending, startPeriodTransition] = useTransition();
  const m = (key: keyof typeof messages): string => messages[key][locale];
  const greetingFull = m('greetingHello').replace('{name}', userName);

  const bootRef = useRef<IntroBoot | null>(null);
  if (bootRef.current === null) {
    bootRef.current = readIntroBoot(greetingFull, introSeen);
  }
  const boot = bootRef.current;

  const [phase, setPhase] = useState<IntroPhase>(boot.phase);
  const [typed, setTyped] = useState(boot.typed);
  const [shrunk, setShrunk] = useState(boot.shrunk);
  const [lifted, setLifted] = useState(boot.lifted);
  const [revealed, setRevealed] = useState(boot.revealed);
  const [splashReady, setSplashReady] = useState(boot.splashReady);
  const [skipHeroMotion, setSkipHeroMotion] = useState(boot.skipHeroMotion);
  const playIntroRef = useRef(boot.playIntro);

  useLayoutEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const seen = introSeen || hasSeenDashboardHeroIntro() || reduced;

    if (seen) {
      markDashboardHeroIntroSeen();
      setTyped(greetingFull);
      setShrunk(true);
      setLifted(true);
      setRevealed(true);
      setSplashReady(false);
      setSkipHeroMotion(true);
      playIntroRef.current = false;
      setPhase('settled');
      return;
    }

    setTyped('');
    setShrunk(false);
    setLifted(false);
    setRevealed(false);
    setSplashReady(false);
    setSkipHeroMotion(false);
    playIntroRef.current = true;
    setPhase('playing');
  }, [greetingFull, introSeen]);

  useEffect(() => {
    if (phase === 'booting') return;
    onLiftedChange?.(lifted);
  }, [lifted, onLiftedChange, phase]);

  useEffect(() => {
    if (phase !== 'playing') return;

    const { style } = document.body;
    const prevOverflow = style.overflow;
    style.overflow = 'hidden';
    return () => {
      style.overflow = prevOverflow;
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== 'playing' || !playIntroRef.current) return;

    const timers: ReturnType<typeof setTimeout>[] = [];
    let completed = false;

    const completeIntro = (instant: boolean): void => {
      if (completed) return;
      completed = true;
      playIntroRef.current = false;
      markDashboardHeroIntroSeen();
      setTyped(greetingFull);

      if (instant) {
        setSkipHeroMotion(true);
        setShrunk(true);
        setLifted(true);
        setRevealed(true);
        setPhase('settled');
        return;
      }

      setShrunk(true);
      timers.push(setTimeout(() => setLifted(true), 120));
      timers.push(setTimeout(() => {
        setRevealed(true);
        setPhase('settled');
      }, 520));
    };

    const skipIntro = (): void => {
      timers.forEach(clearTimeout);
      completeIntro(true);
    };

    timers.push(setTimeout(() => setSplashReady(true), SPLASH_IN_MS));

    window.addEventListener('wheel', skipIntro, { passive: true });
    window.addEventListener('touchstart', skipIntro, { passive: true });
    window.addEventListener('scroll', skipIntro, { passive: true });

    timers.push(setTimeout(() => {
      let i = 0;
      const tick = (): void => {
        i += 1;
        setTyped(greetingFull.slice(0, i));
        if (i < greetingFull.length) {
          timers.push(setTimeout(tick, CHAR_STEP_MS));
        } else {
          timers.push(setTimeout(() => completeIntro(false), PAUSE_AFTER_TYPE_MS));
        }
      };
      tick();
    }, TYPE_DELAY_MS));

    return () => {
      timers.forEach(clearTimeout);
      window.removeEventListener('wheel', skipIntro);
      window.removeEventListener('touchstart', skipIntro);
      window.removeEventListener('scroll', skipIntro);
    };
  }, [phase, greetingFull]);

  const today = new Intl.DateTimeFormat(locale === 'ar' ? 'ar' : 'en', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  }).format(new Date());

  const { kpis } = data;
  const metaLine = m('greetingMetaLine').replace('{date}', today);

  const periods: { key: DashboardSnapshot['period']; label: string }[] = [
    { key: '7',  label: m('dashPeriod7')   },
    { key: '30', label: m('dashPeriod30')  },
    { key: '90', label: m('dashPeriod90')  },
  ];

  const selectPeriod = (period: DashboardSnapshot['period']): void => {
    if (period === data.period || isPeriodPending) return;
    writeDashboardPeriodCookie(period);
    startPeriodTransition(() => {
      router.refresh();
    });
  };

  return (
    <section
      className={[
        styles.hero,
        lifted ? styles.heroLifted : '',
        skipHeroMotion ? styles.heroInstant : '',
        phase === 'booting' ? styles.heroPending : '',
        phase === 'playing' ? styles.heroPlaying : '',
      ].filter(Boolean).join(' ')}
      aria-label={greetingFull}
    >
      <BrandWaves intensity="hero" idPrefix="dash-hero-wave" className={styles.heroWaves} />

      <div className={styles.heroLogoSlot} aria-hidden="true">
        <HeroLogo src="/logo-white.svg" alt="" priority />
      </div>

      <div className={styles.inner}>
        <div
          className={[
            styles.splash,
            splashReady && !shrunk ? styles.splashReady : '',
            shrunk ? styles.splashGone : '',
          ].join(' ')}
          aria-hidden="true"
        >
          <div className={styles.splashLogo}>
            <Image
              src="/logo-white.svg"
              alt=""
              fill
              sizes="120px"
              unoptimized
              priority
              className={styles.splashLogoImg}
            />
          </div>
          <p className={styles.splashTagline}>
            {locale === 'ar' ? 'محرك مطابقة الوظائف' : 'Job Matching Engine'}
          </p>
        </div>

        <h1 className={`${styles.greeting} ${shrunk ? styles.greetingSmall : ''}`}>
          <span className={styles.greetingText}>{typed}</span>
          {phase === 'playing' && !shrunk ? <span className={styles.caret} aria-hidden="true" /> : null}
        </h1>

        <div className={`${styles.rest} ${revealed ? styles.restRevealed : ''}`}>
          <div className={styles.metaRow}>
            <div className={styles.metaLeft}>
              <span className={styles.liveDot} aria-hidden="true" />
              <span className={styles.metaText}>{metaLine}</span>
            </div>
            <div className={styles.metaRight}>
              <div
                className={styles.periodGroup}
                aria-label={m('dashPeriodLabel')}
                aria-busy={isPeriodPending || undefined}
              >
                {periods.map((p) => (
                  <button
                    key={p.key}
                    type="button"
                    onClick={() => selectPeriod(p.key)}
                    className={`${styles.periodPill} ${data.period === p.key ? styles.periodPillActive : ''}`}
                    aria-pressed={data.period === p.key}
                    disabled={isPeriodPending && data.period !== p.key}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
              <ExportExcelButton data={data} locale={locale} className={styles.exportBtn} />
            </div>
          </div>

          <div className={styles.kpiGrid}>
            <Link href="/candidates" className={styles.kpiLink}>
              <KpiCard
                label={m('dashKpiCandidates')}
                value={kpis.candidates}
                icon={UserRound}
                secondaryNote={`${data.readiness.readyPct}% ${m('dashKpiReadyProfilesOfCandidates')} · ${data.readiness.recentGrads.toLocaleString()} ${m('dashRecentGrads')}`}
                animateStart={revealed}
              />
            </Link>
            <Link href={buildHref('/employers', {}, { has_jobs: '1' })} className={styles.kpiLink}>
              <KpiCard
                label={m('dashKpiActiveJobs')}
                value={kpis.activeJobs}
                icon={BriefcaseBusiness}
                secondaryNote={`${kpis.openPositions} ${m('dashKpiOpenPositions')} · ${kpis.employers} ${m('dashKpiEmployers')}`}
                animateStart={revealed}
              />
            </Link>
            <KpiCard
              label={m('dashKpiMatches')}
              value={kpis.matchesCreated}
              icon={GitCompareArrows}
              secondaryNote={`${m('dashKpiAvgScore')} ${kpis.avgMatchScore}%`}
              animateStart={revealed}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

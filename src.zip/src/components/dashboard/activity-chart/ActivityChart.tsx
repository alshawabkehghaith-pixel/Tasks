'use client';

import type { JSX } from 'react';
import { LineChart } from 'lucide-react';
import { CartesianGrid, Line, LineChart as RechartsLineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

import { ReadinessInfoTooltip } from '@/components/dashboard/readiness-info-tooltip/ReadinessInfoTooltip';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { useInViewOnce } from '@/hooks/useInViewOnce';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import { ICON_STROKE } from '@/lib/icons';
import type { TimelinePoint } from '@/types/domain';

import styles from './ActivityChart.module.css';

interface ActivityChartProps {
  timeline: TimelinePoint[];
  locale: Locale;
  showNotifications?: boolean;
}

const SERIES = [
  { key: 'reviews', cls: 'rev', color: 'var(--brand)', label: 'dashActReviews' },
  { key: 'approvals', cls: 'app', color: 'var(--teal)', label: 'dashActApprovals' },
  { key: 'notifications', cls: 'notif', color: 'var(--accent)', label: 'dashActNotifications' },
] as const satisfies readonly {
  key: keyof Pick<TimelinePoint, 'reviews' | 'approvals' | 'notifications'>;
  cls: string;
  color: string;
  label: keyof typeof messages;
}[];

const CHART_HEIGHT_PX = 286;

function formatAxisDate(value: string): string {
  const parsed = new Date(`${value}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) {
    return value;
  }

  const day = String(parsed.getDate()).padStart(2, '0');
  const month = String(parsed.getMonth() + 1).padStart(2, '0');
  const year = String(parsed.getFullYear());

  return `${day}/${month}/${year}`;
}

interface TooltipPayloadRow {
  dataKey?: keyof Pick<TimelinePoint, 'reviews' | 'approvals' | 'notifications'>;
  value?: number;
  color?: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadRow[];
  label?: string;
  locale: Locale;
  showNotifications: boolean;
}

function CustomTooltip({ active, payload, label, locale, showNotifications }: CustomTooltipProps): JSX.Element | null {
  if (!active || !payload?.length) {
    return null;
  }

  const m = (key: keyof typeof messages): string => messages[key][locale];
  const seriesByKey = new Map(SERIES.map((series) => [series.key, series]));
  const lowMatchLabel = locale === 'ar'
    ? 'مرشحون بدرجة مطابقة أقل من 80%'
    : 'Candidates with match score less than80%';

  const getSeriesLabel = (entryKey: keyof Pick<TimelinePoint, 'reviews' | 'approvals' | 'notifications'>): string => {
    if (!showNotifications && entryKey === 'reviews') {
      return lowMatchLabel;
    }

    const series = seriesByKey.get(entryKey);
    if (!series) {
      return '';
    }

    return m(series.label);
  };

  return (
    <div className={styles.tooltip}>
      <div className={styles.tooltipLabel}>{label ? formatAxisDate(label) : label}</div>
      <div className={styles.tooltipRows}>
        {payload.map((entry) => {
          const series = entry.dataKey ? seriesByKey.get(entry.dataKey) : undefined;
          if (!series) {
            return null;
          }

          return (
            <div key={series.key} className={styles.tooltipRow}>
              <span className={styles.tooltipSeriesInfo}>
                <span className={styles.tooltipDot} style={{ background: series.color }} aria-hidden="true" />
                  <span className={styles.tooltipSeriesLabel}>{getSeriesLabel(series.key)}</span>
              </span>
              <span className={styles.tooltipSeriesValue}>{(entry.value ?? 0).toLocaleString()}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ActivityChart({
  timeline,
  locale,
  showNotifications = true,
}: ActivityChartProps): JSX.Element {
  const m = (key: keyof typeof messages): string => messages[key][locale];
  const lowMatchLabel = locale === 'ar'
    ? 'مرشحون بدرجة مطابقة أقل من 80%'
    : 'Candidates with match score less than 80%';
  const weeklySubtitle = locale === 'ar'
    ? 'يوضح عدد المرشحين ذوي الملفات غير المكتملة الذين تم اعتماد المطابقات المقترحة من المحرك لهم مقارنةً بالمرشحين الذين لم يتم اعتمادها.'
    : 'This chart compares candidates with ready profiles based on the approval status of the job matches recommended by the engine.';
  const activityInfoLabel = locale === 'ar' ? 'معلومات عرض النشاط' : 'Activity view information';
  const xAxisTitle = locale === 'ar' ? 'التاريخ' : 'Date';
  const yAxisTitle = locale === 'ar' ? 'العدد' : 'Count';
  const { ref, visible } = useInViewOnce<HTMLDivElement>();

  const visibleSeries = showNotifications
    ? SERIES
    : SERIES.filter((s) => s.key !== 'notifications');

  if (timeline.length === 0) {
    return <div className={styles.empty}>{m('dashNoActivity')}</div>;
  }

  const isArabic = locale === 'ar';
  const chartBottom = isArabic ? 56 : 44;
  const xTickHeight = isArabic ? 52 : 40;

  const chart = (
    <div ref={ref} className={styles.mount}>
      {!visible ? (
        <div className={styles.placeholder} />
      ) : (
        <>
          <div className={styles.chartFrame} role="img" aria-label={buildAriaLabel(timeline[0]!, showNotifications, m)}>
            <ResponsiveContainer width="100%" height={CHART_HEIGHT_PX}>
              <RechartsLineChart
                data={timeline}
                margin={{ top: 12, right: 20, left: 4, bottom: chartBottom }}
              >
                <CartesianGrid vertical={false} stroke="var(--line)" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(value: string) => formatAxisDate(value)}
                  axisLine={false}
                  tickLine={false}
                  interval="preserveStartEnd"
                  minTickGap={isArabic ? 36 : 24}
                  height={xTickHeight}
                  tickMargin={12}
                  padding={{ left: 16, right: 16 }}
                  tick={{
                    fontSize: isArabic ? 11 : 12,
                    fill: 'var(--text-faint)',
                    fontWeight: 600,
                  }}
                  label={{
                    value: xAxisTitle,
                    position: 'insideBottom',
                    offset: isArabic ? 0 : -4,
                    fill: 'var(--text-faint)',
                    fontSize: 12,
                  }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: 'var(--text-faint)' }}
                  width={isArabic ? 48 : 44}
                  tickMargin={6}
                  label={{
                    value: yAxisTitle,
                    angle: -90,
                    position: 'insideLeft',
                    offset: 8,
                    fill: 'var(--text-faint)',
                    fontSize: 12,
                  }}
                />
                <Tooltip
                  cursor={{ stroke: 'var(--line)', strokeWidth: 1 }}
                  content={<CustomTooltip locale={locale} showNotifications={showNotifications} />}
                />
                {visibleSeries.map((series) => (
                  <Line
                    key={series.key}
                    type="monotone"
                    dataKey={series.key}
                    stroke={series.color}
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 5, fill: series.color, stroke: 'var(--card)', strokeWidth: 2 }}
                    isAnimationActive
                    animationDuration={700}
                    animationEasing="ease-out"
                  />
                ))}
              </RechartsLineChart>
            </ResponsiveContainer>
          </div>

          <div className={styles.legend}>
            {visibleSeries.map((series) => (
              <span key={series.key} className={styles.legendItem}>
                <span className={styles.legendDot} style={{ background: series.color }} aria-hidden="true" />
                <span>{!showNotifications && series.key === 'reviews' ? lowMatchLabel : m(series.label)}</span>
              </span>
            ))}
          </div>
        </>
      )}
    </div>
  );

  return (
    <SurfaceCard className={`card ${styles.card}`}>
      <div className={styles.accent} aria-hidden="true" />
      <div className={styles.corner} aria-hidden="true" />

      <div className={styles.header}>
        <span className={styles.badge} aria-hidden="true">
          <LineChart size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <div className={styles.headingGroup}>
          <div className={styles.titleRow}>
            <h2 className={styles.title}>{m('dashActivityTitle')}</h2>
            {!showNotifications ? <ReadinessInfoTooltip label={activityInfoLabel} text={weeklySubtitle} /> : null}
          </div>
          {showNotifications ? <p className={styles.subtitle}>{m('dashActivitySubtitle')}</p> : null}
        </div>
      </div>

      {chart}
    </SurfaceCard>
  );
}

function buildAriaLabel(
  point: TimelinePoint,
  showNotifications: boolean,
  m: (key: keyof typeof messages) => string,
): string {
  const parts = [
    point.date,
    `${point.reviews} ${showNotifications ? m('dashActReviews') : 'candidates with match score less than 80%'}`,
    `${point.approvals} ${m('dashActApprovals')}`,
  ];
  if (showNotifications) {
    parts.push(`${point.notifications} ${m('dashActNotifications')}`);
  }
  return parts.join(' · ');
}
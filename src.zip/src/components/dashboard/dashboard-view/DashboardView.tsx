"use client";

import Link from 'next/link';
import dynamic from 'next/dynamic';
import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { CircleGauge, Minus, Scale, TrendingDown, TrendingUp, TriangleAlert, Wallet } from 'lucide-react';

import { CountUpNumber } from '@/components/dashboard/count-up-number/CountUpNumber';
import { ReadinessInfoTooltip } from '@/components/dashboard/readiness-info-tooltip/ReadinessInfoTooltip';
import { GreetingHero } from '@/components/dashboard/greeting-hero/GreetingHero';
import { TalentPipelineCard } from '@/components/dashboard/talent-pipeline/TalentPipeline';
import { EmptyState } from '@/components/ui/EmptyState';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { useInViewOnce } from '@/hooks/useInViewOnce';
import { messages } from '@/i18n/catalog';
import { ICON_STROKE } from '@/lib/icons';
import { hasSeenDashboardHeroIntro } from '@/lib/hero-intro-storage';
import { buildHref, type QueryInput } from '@/lib/routing';
import type {
  DashboardSnapshot,
  FollowUpItem,
  JobDistributionRow,
  ReadinessBreakdown,
  SupplyDemandRow,
} from '@/types/domain';
import type { Locale } from '@/types/jadarat';

import styles from './DashboardView.module.css';

const ActivityChart = dynamic(
  () => import('@/components/dashboard/activity-chart/ActivityChart').then((m) => m.ActivityChart),
  { ssr: false, loading: () => <div className={`${styles.dist_placeholder} ${styles.dist_placeholderTall}`} /> },
);
const ScoreDistribution = dynamic(
  () => import('@/components/dashboard/score-distribution/ScoreDistribution').then((m) => m.ScoreDistribution),
  { ssr: false, loading: () => <div className={`${styles.dist_placeholder} ${styles.dist_placeholderShort}`} /> },
);
const JobsBySalaryChart = dynamic(
  () => import('@/components/dashboard/jobs-by-salary/JobsBySalaryChart').then((m) => m.JobsBySalaryChart),
  { ssr: false, loading: () => <div className={styles.dist_placeholder} /> },
);

interface DashboardViewProps {
  data: DashboardSnapshot;
  locale: Locale;
  query: QueryInput;
  userName?: string;
  heroIntroSeen?: boolean;
}

function m(key: keyof typeof messages, locale: Locale): string {
  return messages[key][locale];
}

interface ScrollRevealProps {
  children: (visible: boolean) => JSX.Element;
  delayMs?: number;
}

function ScrollReveal({ children, delayMs = 0 }: ScrollRevealProps): JSX.Element {
  const { ref, visible } = useInViewOnce<HTMLDivElement>({ delayMs });

  return (
    <div ref={ref} className={`${styles.card_reveal} ${visible ? styles.card_revealVisible : ''}`}>
      {children(visible)}
    </div>
  );
}

export function DashboardView({ data, locale, query, userName, heroIntroSeen = false }: DashboardViewProps): JSX.Element {
  const hasData = data.kpis.candidates > 0;
  const greetingName = userName?.trim().split(/\s+/)[0] || (locale === 'ar' ? 'زائر' : 'there');
  const [heroLifted, setHeroLifted] = useState<boolean>(() => {
    if (heroIntroSeen) return true;
    if (typeof window === 'undefined') return false;
    return hasSeenDashboardHeroIntro()
      || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });
  const [sectionsVisible, setSectionsVisible] = useState<boolean>(() => {
    if (heroIntroSeen) return true;
    if (typeof window === 'undefined') return false;
    return hasSeenDashboardHeroIntro()
      || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });
  const startedSettledRef = useRef(heroLifted);

  useEffect(() => {
    if (!heroLifted) {
      setSectionsVisible(false);
      return;
    }

    if (startedSettledRef.current) {
      setSectionsVisible(true);
      return;
    }

    const timer = window.setTimeout(() => setSectionsVisible(true), 780);
    return () => window.clearTimeout(timer);
  }, [heroLifted]);

  return (
    <div className={`flex flex-col gap-[12px] ${styles.dashboard_root}`}>
      <GreetingHero
        data={data}
        locale={locale}
        query={query}
        userName={greetingName}
        introSeen={heroIntroSeen}
        onLiftedChange={setHeroLifted}
      />

      <div className={`${styles.dashboard_sections} ${sectionsVisible ? styles.dashboard_sectionsVisible : ''}`}>
        {!hasData ? (
          <EmptyState
            title={m('dashEmptyTitle', locale)}
            description={m('dashEmptyDesc', locale)}
            ctaHref="/candidates"
            ctaLabel={m('navCandidates', locale)}
          />
        ) : (
          <>
            <div className={styles.duo_readiness}>
              <ScrollReveal>
                {(visible) => (
                  <ReadinessCard
                    data={data.readiness}
                    locale={locale}
                    animate={visible && sectionsVisible}
                  />
                )}
              </ScrollReveal>
              <ScrollReveal delayMs={90}>
                {(visible) => (
                  <FollowUpCard
                    items={data.followUp}
                    notReadyCount={data.readiness.partial + data.readiness.incomplete}
                    locale={locale}
                    animate={visible && sectionsVisible}
                  />
                )}
              </ScrollReveal>
            </div>

            <div className="dgroup">{m('dashGroupPipeline', locale)}</div>
            <div className={styles.pipeline_spacer}>
              <ScrollReveal delayMs={90}>
                {() => <TalentPipelineCard data={data.talentPipeline} locale={locale} />}
              </ScrollReveal>
            </div>

            <div className={styles.pipeline_spacer}>
              <ScrollReveal delayMs={90}>
                {() => <ScoreDistribution bands={data.scoreBands} locale={locale} />}
              </ScrollReveal>
            </div>

            <div className={styles.supply_spacer}>
              <ScrollReveal>
                {(visible) => <SupplyDemandCard rows={data.supplyDemand} locale={locale} animate={visible} />}
              </ScrollReveal>
            </div>

            <div className={styles.distribution_spacer}>
              <DistributionCard
                title={m('dashJobsBySalaryTitle', locale)}
                rows={data.jobsBySalary}
                barColor="var(--teal)"
                locale={locale}
              />
            </div>

            <div className="dgroup">{m('dashGroupDistribution', locale)}</div>
            <ScrollReveal delayMs={90}>
              {() => <ActivityChart timeline={data.timeline} locale={locale} showNotifications={false} />}
            </ScrollReveal>
          </>
        )}
      </div>
    </div>
  );
}

interface ReadinessCardProps {
  data: ReadinessBreakdown;
  locale: Locale;
  animate: boolean;
}

function ReadinessCard({ data, locale, animate }: ReadinessCardProps): JSX.Element {
  const total = data.ready + data.partial + data.incomplete || 1;
  const readyPct = Math.max(0, Math.min(100, data.readyPct));
  const partialPct = Math.round((data.partial / total) * 100);
  const incompletePct = Math.max(0, 100 - readyPct - partialPct);

  const [ringDrawn, setRingDrawn] = useState(false);

  useEffect(() => {
    if (!animate) {
      setRingDrawn(false);
      return;
    }

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (reduceMotion) {
      setRingDrawn(true);
      return;
    }

    let frame2 = 0;
    const frame1 = window.requestAnimationFrame(() => {
      frame2 = window.requestAnimationFrame(() => setRingDrawn(true));
    });
    return () => {
      window.cancelAnimationFrame(frame1);
      window.cancelAnimationFrame(frame2);
    };
  }, [animate]);

  const renderCount = (value: number, className: string | undefined): JSX.Element => {
    if (!animate) {
      return <span className={className}>{value.toLocaleString()}</span>;
    }

    return <CountUpNumber value={value} durationMs={1100} className={className} />;
  };

  const segments = [
    { key: 'ready', value: readyPct, color: 'var(--brand)', label: m('dashReadinessReady', locale) },
    { key: 'partial', value: partialPct, color: 'var(--accent)', label: m('dashReadinessPartial', locale) },
    { key: 'incomplete', value: incompletePct, color: 'var(--rust)', label: m('dashReadinessIncomplete', locale) },
  ] as const;

  const donutSize = 160;
  const radius = 63;
  const center = donutSize / 2;

  const startAngle = 90;
  const paddingAngle = 2;
  const availableSweep = 360 - paddingAngle * (segments.length - 1);

  let cursor = startAngle;
  const donutSegments = segments.map((segment) => {
    const start = cursor;
    const end = cursor + (segment.value / 100) * availableSweep;
    const length = (end - start) / 360 * 100;
    cursor = end + paddingAngle;

    return { ...segment, start, end, length };
  });

  return (
    <SurfaceCard className={`card ${styles.readiness_card}`}>
      <div className={styles.readiness_header}>
        <span className={styles.readiness_badge} aria-hidden="true">
          <CircleGauge size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <div className={styles.readiness_heading_group}>
          <div className={styles.readiness_title_row}>
            <h2 className={styles.readiness_title}>{m('dashReadinessTitle', locale)}</h2>
            <ReadinessInfoTooltip label={m('dashReadinessInfoLabel', locale)} text={m('dashReadinessInfoTooltip', locale)} />
          </div>
          <p className={styles.readiness_subtitle}>
            {m('dashReadinessSubtitle', locale)}
          </p>
        </div>
      </div>

      <div className={styles.readiness_body}>
        <div className={`${styles.readiness_donut_wrap} ${animate ? styles.readiness_donut_wrapVisible : ''}`}>
          <svg className={styles.readiness_donut} viewBox={`0 0 ${donutSize} ${donutSize}`} aria-hidden="true">
            <circle
              className={styles.readiness_track}
              cx={center}
              cy={center}
              r={radius}
              pathLength={100}
            />
            {donutSegments.map((segment) => (
              <g key={segment.key}>
                <circle
                  className={styles.readiness_arcSeparator}
                  cx={center}
                  cy={center}
                  r={radius}
                  pathLength={100}
                  style={{
                    transform: `rotate(${segment.start - 90}deg)`,
                    strokeDasharray: ringDrawn ? `${segment.length} ${100 - segment.length}` : '0 100',
                  }}
                />
                <circle
                  className={styles.readiness_arc}
                  cx={center}
                  cy={center}
                  r={radius}
                  pathLength={100}
                  stroke={segment.color}
                  style={{
                    transform: `rotate(${segment.start - 90}deg)`,
                    strokeDasharray: ringDrawn ? `${segment.length} ${100 - segment.length}` : '0 100',
                  }}
                />
              </g>
            ))}
          </svg>

          <div className={styles.readiness_center}>
            <div className={styles.readiness_percent}>
              {renderCount(readyPct, styles.readiness_percent_value)}
              <span className={styles.readiness_percent_symbol}>%</span>
            </div>

            <div className={styles.readiness_center_label}>{m('dashReadinessReady', locale)}</div>
          </div>
        </div>

        <div className={styles.readiness_legend}>
          <Link href={buildHref('/candidates', {}, { tier: 'ready' })} className={styles.readiness_row}>
            <span className={styles.readiness_row_lhs}>
              <span className={`${styles.readiness_dot} ${styles.readiness_dot_ready}`} aria-hidden="true" />
              <span>{m('dashReadinessReady', locale)}</span>
            </span>
            <span className={styles.readiness_count}>
              {renderCount(data.ready, styles.readiness_count_value)}
            </span>
          </Link>
          <Link href={buildHref('/candidates', {}, { tier: 'partial' })} className={styles.readiness_row}>
            <span className={styles.readiness_row_lhs}>
              <span className={`${styles.readiness_dot} ${styles.readiness_dot_partial}`} aria-hidden="true" />
              <span>{m('dashReadinessPartial', locale)}</span>
            </span>
            <span className={styles.readiness_count}>
              {renderCount(data.partial, styles.readiness_count_value)}
            </span>
          </Link>
          <Link href={buildHref('/candidates', {}, { tier: 'incomplete' })} className={styles.readiness_row}>
            <span className={styles.readiness_row_lhs}>
              <span className={`${styles.readiness_dot} ${styles.readiness_dot_incomplete}`} aria-hidden="true" />
              <span>{m('dashReadinessIncomplete', locale)}</span>
            </span>
            <span className={styles.readiness_count}>
              {renderCount(data.incomplete, styles.readiness_count_value)}
            </span>
          </Link>
        </div>
      </div>
    </SurfaceCard>
  );
}

interface FollowUpCardProps {
  items: FollowUpItem[];
  notReadyCount: number;
  locale: Locale;
  animate: boolean;
}

function FollowUpCard({ items, notReadyCount, locale, animate }: FollowUpCardProps): JSX.Element {
  const topItems = [...items]
    .sort((a, b) => b.count - a.count)
    .slice(0, 4);
  const maxCount = Math.max(1, ...topItems.map((item) => item.count));

  return (
    <SurfaceCard className={`card ${styles.followup_card}`}>
      <div className="ptitle-row">
        <span className={styles.followup_badge} aria-hidden="true">
          <TriangleAlert size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <h2 className="ptitle">{m('dashFollowUpTitle', locale)}</h2>
        <ReadinessInfoTooltip label={m('dashFollowUpInfoLabel', locale)} text={m('dashFollowUpInfoTooltip', locale)} />
      </div>

      <div className={`${styles.work_item} ${styles.followup_summary}`}>
        <span>
          {animate ? <CountUpNumber value={notReadyCount} durationMs={1100} /> : notReadyCount.toLocaleString()}{' '}
          {m('dashNotReady', locale)} · {m('dashTopMissingFields', locale)}
        </span>
      </div>

      {topItems.map((item) => (
        <div key={item.field} className={styles.work_item}>
          <span className={styles.work_item_lhs}>
            <b>{item.field}</b>
          </span>
          <span className={styles.work_item_barTrack} aria-hidden="true">
            <span
              className={`${styles.work_item_barFill} ${animate ? styles.work_item_barFillVisible : ''}`}
              style={{ width: `${Math.max(8, Math.round((item.count / maxCount) * 100))}%` }}
            />
          </span>
          <span className={styles.fu_count}>
            {animate ? <CountUpNumber value={item.count} durationMs={1100} /> : item.count.toLocaleString()}
          </span>
        </div>
      ))}
    </SurfaceCard>
  );
}

interface SupplyDemandCardProps {
  rows: SupplyDemandRow[];
  locale: Locale;
  animate: boolean;
}

const COVERAGE_META: Record<
  SupplyDemandRow['coverage'],
  { labelKey: keyof typeof messages; icon: JSX.Element; colorClass: string | undefined }
> = {
  good: { labelKey: 'dashCoverageGood', icon: <TrendingUp size={12} strokeWidth={ICON_STROKE} />, colorClass: styles.sd_tagGood },
  moderate: { labelKey: 'dashCoverageModerate', icon: <Minus size={12} strokeWidth={ICON_STROKE} />, colorClass: styles.sd_tagModerate },
  gap: { labelKey: 'dashCoverageGap', icon: <TrendingDown size={12} strokeWidth={ICON_STROKE} />, colorClass: styles.sd_tagGap },
  surplus: { labelKey: 'dashCoverageSurplus', icon: <TrendingUp size={12} strokeWidth={ICON_STROKE} />, colorClass: styles.sd_tagSurplus },
};

function SupplyDemandCard({ rows, locale, animate }: SupplyDemandCardProps): JSX.Element {
  const maxVal = Math.max(...rows.flatMap((row) => [row.demand, row.supply]), 1);

  return (
    <SurfaceCard className={`card ${styles.sd_card}`}>
      <div className={styles.sd_header}>
        <span className={styles.sd_badge} aria-hidden="true">
          <Scale size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <div className={styles.sd_heading_group}>
          <h2 className={styles.sd_title}>{m('dashSupplyCardTitle', locale)}</h2>
          <p className={styles.sd_subtitle}>{m('dashSupplyCardSubtitle', locale)}</p>
        </div>
      </div>

      {rows.map((row) => (
        <div key={row.category} className={styles.sd_row}>
          <div className={styles.sd_rowHeader}>
            <span className={styles.sd_name}>{row.category}</span>
            <span className={`${styles.sd_tag} ${COVERAGE_META[row.coverage].colorClass}`}>
              {COVERAGE_META[row.coverage].icon}
              <span>{m(COVERAGE_META[row.coverage].labelKey, locale)}</span>
            </span>
          </div>

          <div className={styles.sd_line}>
            <span className={styles.sd_lineLabel}>{m('dashSupplyDemandLabel', locale)}</span>
            <div className={styles.sd_track} aria-hidden="true">
              <div
                className={`${styles.sd_fillDemand} ${animate ? styles.sd_fillVisible : ''}`}
                style={{ width: `${Math.round((row.demand / maxVal) * 100)}%` }}
              />
            </div>
            <span className={styles.sd_value}>{row.demand.toLocaleString()}</span>
          </div>

          <div className={styles.sd_line}>
            <span className={styles.sd_lineLabel}>{m('dashSupplySupplyLabel', locale)}</span>
            <div className={styles.sd_track} aria-hidden="true">
              <div
                className={`${styles.sd_fillSupply} ${animate ? styles.sd_fillVisible : ''}`}
                style={{ width: `${Math.round((row.supply / maxVal) * 100)}%` }}
              />
            </div>
            <span className={styles.sd_value}>{row.supply.toLocaleString()}</span>
          </div>
        </div>
      ))}
    </SurfaceCard>
  );
}

interface DistributionCardProps {
  title: string;
  rows: JobDistributionRow[];
  barColor: string;
  locale: Locale;
}

const DistributionCard = memo(function DistributionCard({ title, rows, barColor, locale }: DistributionCardProps): JSX.Element {
  const { ref, visible } = useInViewOnce<HTMLDivElement>();
  const sortedRows = useMemo(
    () => [...rows].sort((left, right) => getSalaryBandStart(left.label) - getSalaryBandStart(right.label)),
    [rows],
  );

  return (
    <SurfaceCard className={`card ${styles.dist_card}`}>
      <div className={styles.dist_header}>
        <span className={styles.dist_badge} aria-hidden="true">
          <Wallet size={16} strokeWidth={ICON_STROKE} color="currentColor" />
        </span>
        <h2 className={styles.dist_title}>{title}</h2>
      </div>

      <div ref={ref} className={styles.dist_chartMount}>
        {!visible
          ? <div className={styles.dist_placeholder} />
          : <JobsBySalaryChart rows={sortedRows} barColor={barColor} locale={locale} />}
      </div>
    </SurfaceCard>
  );
});

function getSalaryBandStart(label: string): number {
  const numericParts = label.match(/\d+/g);
  if (!numericParts?.length) {
    return Number.MAX_SAFE_INTEGER;
  }

  return Number.parseInt(numericParts[0], 10);
}

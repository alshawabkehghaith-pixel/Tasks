'use client';

import { useCountUp } from '@/hooks/useCountUp';

interface CountUpNumberProps {
  value: number;
  className?: string;
  durationMs?: number;
}

export function CountUpNumber({ value, className, durationMs }: CountUpNumberProps): JSX.Element {
  const animated = useCountUp(value, { durationMs });

  return <span className={className}>{animated.toLocaleString()}</span>;
}
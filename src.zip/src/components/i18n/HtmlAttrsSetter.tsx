'use client';

import { useEffect } from 'react';

import { localeDirection, type Locale } from '@/i18n/config';
import type { ThemeMode } from '@/types/jadarat';

const DEFAULT_STRIP_QUERY_KEYS = ['lang', 'theme'] as const;

const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

export interface HtmlAttrsSetterProps {
  locale: Locale;
  theme: ThemeMode;
  stripQueryKeys?: readonly string[];
}

export function HtmlAttrsSetter({
  locale,
  theme,
  stripQueryKeys = DEFAULT_STRIP_QUERY_KEYS,
}: HtmlAttrsSetterProps): null {
  const stripKey = stripQueryKeys.join(',');

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('lang', locale);
    root.setAttribute('dir', localeDirection[locale]);
    root.setAttribute('data-theme', theme);

    try {
      localStorage.setItem('locale', locale);
      localStorage.setItem('theme', theme);
    } catch {

    }

    const secure = window.location.protocol === 'https:' ? '; secure' : '';
    document.cookie = `locale=${locale}; path=/; max-age=${COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;
    document.cookie = `theme=${theme}; path=/; max-age=${COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;

    const current = new URL(window.location.href);
    const before = current.search;
    for (const key of stripKey.split(',')) {
      if (key) current.searchParams.delete(key);
    }
    if (current.search !== before) {
      const cleaned = `${current.pathname}${current.search}${current.hash}`;
      window.history.replaceState(window.history.state, '', cleaned);
    }
  }, [locale, theme, stripKey]);

  return null;
}

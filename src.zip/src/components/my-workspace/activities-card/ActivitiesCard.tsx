import Link from 'next/link';
import { ArrowLeft, ArrowRight, Briefcase, CheckCircle2, ChevronLeft, ChevronRight, Clock3, UserCheck, XCircle } from 'lucide-react';

import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import { buildHref } from '@/lib/routing';
import type { ActivityItem, CampaignPurpose } from '@/types/domain';

import styles from './ActivitiesCard.module.css';

const CAMPAIGN_ICON = {
  vacancy: { Icon: Briefcase, tone: 'tone_employers' },
  completeness: { Icon: UserCheck, tone: 'tone_candidates' },
} satisfies Record<CampaignPurpose, { Icon: typeof Briefcase; tone: string }>;

function purposeLabel(purpose: CampaignPurpose, locale: Locale): string {
  return purpose === 'vacancy'
    ? messages.campLogPurposeVacancy[locale]
    : messages.campLogPurposeCompleteness[locale];
}

function formatDate(iso: string, locale: Locale): string {
  try {
    return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-SA' : 'en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export interface ActivitiesCardProps {
  items: ActivityItem[];
  page: number;
  totalPages: number;
  locale: Locale;
  loadError?: boolean;
}

export function ActivitiesCard({ items, page, totalPages, locale, loadError = false }: ActivitiesCardProps): JSX.Element {
  if (loadError) {
    return (
      <div className={styles.emptyState}>
        <span className={styles.emptyIcon} aria-hidden="true">
          <Clock3 size={32} strokeWidth={1.5} />
        </span>
        <p className={styles.emptyTitle}>{messages.myWorkspaceHistoryLoadError[locale]}</p>
        <Link href="/my-workspace" className={styles.emptyCta}>
          {messages.myWorkspaceHistoryRetry[locale]}
        </Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className={styles.emptyState}>
        <span className={styles.emptyIcon} aria-hidden="true">
          <Clock3 size={32} strokeWidth={1.5} />
        </span>
        <p className={styles.emptyTitle}>{messages.myWorkspaceHistoryEmptyTitle[locale]}</p>
        <p className={styles.emptyDesc}>{messages.myWorkspaceHistoryEmptyDesc[locale]}</p>
      </div>
    );
  }

  const campaignCta = (
    <span className={styles.cta}>
      <span>{messages.campLogViewCampaign[locale]}</span>
      {locale === 'ar'
        ? <ArrowLeft size={13} strokeWidth={2.2} aria-hidden="true" />
        : <ArrowRight size={13} strokeWidth={2.2} aria-hidden="true" />}
    </span>
  );

  const candidateCta = (
    <span className={styles.cta}>
      <span>{messages.candListViewCandidate[locale]}</span>
      {locale === 'ar'
        ? <ArrowLeft size={13} strokeWidth={2.2} aria-hidden="true" />
        : <ArrowRight size={13} strokeWidth={2.2} aria-hidden="true" />}
    </span>
  );

  return (
    <div className={styles.wrapper}>
      <ul className={styles.list} role="list">
        {items.map((item) => {
          if (item.kind === 'campaign') {
            const { Icon, tone } = CAMPAIGN_ICON[item.purpose];
            return (
              <li key={`c-${item.id}`} className={styles.item}>
                <Link href={`/outreach/campaigns/${item.id}`} className={styles.row}>
                  <span className={`${styles.iconDot} ${styles[tone as keyof typeof styles]}`} aria-hidden="true">
                    <Icon size={15} strokeWidth={1.8} />
                  </span>
                  <div className={styles.info}>
                    <span className={styles.purpose}>{purposeLabel(item.purpose, locale)}</span>
                    <span className={styles.meta}>
                      {item.candidateCount.toLocaleString(locale)} {messages.campLogColCandidates[locale]} · {formatDate(item.sentAt, locale)}
                    </span>
                  </div>
                  {campaignCta}
                </Link>
              </li>
            );
          }

          const isApproved = item.verdict === 'approved';
          const VerdictIcon = isApproved ? CheckCircle2 : XCircle;
          const verdictLabel = isApproved
            ? messages.cand360Approved[locale]
            : messages.cand360Rejected[locale];
          const verdictTone = isApproved ? styles.tone_candidates : styles.tone_rejected;

          return (
            <li key={`d-${item.id}`} className={styles.item}>
              <Link
                href={`/candidates/${encodeURIComponent(item.nin)}`}
                className={styles.row}
              >
                <span className={`${styles.iconDot} ${verdictTone}`} aria-hidden="true">
                  <VerdictIcon size={15} strokeWidth={1.8} />
                </span>
                <div className={styles.info}>
                  <span className={styles.purpose}>{item.candidateName}</span>
                  <span className={styles.meta}>
                    {item.jobTitle} · {verdictLabel} · {formatDate(item.decidedAt, locale)}
                  </span>
                </div>
                {candidateCta}
              </Link>
            </li>
          );
        })}
      </ul>

      {totalPages > 1 ? (
        <nav className={styles.pager} aria-label={messages.pagerNavLabel[locale]}>
          {page > 1 ? (
            <Link
              href={buildHref('/my-workspace', {}, { actPage: String(page - 1) })}
              className={styles.pagerBtn}
              aria-label={messages.pagerPrevPage[locale]}
            >
              <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
              <span>{messages.pagerPrevPage[locale]}</span>
            </Link>
          ) : (
            <span className={`${styles.pagerBtn} ${styles.pagerBtnDisabled}`} aria-hidden="true">
              <ChevronLeft size={14} strokeWidth={2.2} />
              <span>{messages.pagerPrevPage[locale]}</span>
            </span>
          )}
          <span className={styles.pagerInfo} aria-current="page">
            {page} / {totalPages}
          </span>
          {page < totalPages ? (
            <Link
              href={buildHref('/my-workspace', {}, { actPage: String(page + 1) })}
              className={styles.pagerBtn}
              aria-label={messages.pagerNextPage[locale]}
            >
              <span>{messages.pagerNextPage[locale]}</span>
              <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
            </Link>
          ) : (
            <span className={`${styles.pagerBtn} ${styles.pagerBtnDisabled}`} aria-hidden="true">
              <span>{messages.pagerNextPage[locale]}</span>
              <ChevronRight size={14} strokeWidth={2.2} />
            </span>
          )}
        </nav>
      ) : null}
    </div>
  );
}

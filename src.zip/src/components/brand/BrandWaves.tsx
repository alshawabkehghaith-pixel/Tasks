'use client';

import { cn } from '@/lib/utils';

import styles from './BrandWaves.module.css';

const WAVE_WIDTH = 2880;
const LOOP_WIDTH = WAVE_WIDTH * 2;
const WAVE_HEIGHT = 620;
/** Longer half-period = gentler, more subtle roll */
const HALF_PERIOD = 560;

/** Teal identity + forest depth · bronze secondary */
const P = {
  primary: '#348486',
  primaryDeep: '#0A3D2E',
  primaryMid: '#2C7C88',
  tertiary: '#87B8BA',
  tertiaryDeep: '#134A38',
  secondary: '#A88A56',
  secondaryTan: '#D3B16D',
  cream: '#E5E5E5',
  green: '#40BEA3',
  greenMid: '#0F8A5D',
  neutral: '#1F2A2B',
} as const;

/**
 * Soft sine-like band: long bezier handles so crests roll instead of spike.
 * Continuous across two periods for a seamless horizontal loop.
 */
function waveBand(baseline: number, amplitude: number): string {
  const segments = Math.round(LOOP_WIDTH / HALF_PERIOD);
  const cp = HALF_PERIOD * 0.48;
  let path = `M 0 ${baseline - amplitude}`;

  for (let i = 0; i < segments; i += 1) {
    const x0 = i * HALF_PERIOD;
    const from = i % 2 === 0 ? baseline - amplitude : baseline + amplitude;
    const to = i % 2 === 0 ? baseline + amplitude : baseline - amplitude;
    path += ` C ${x0 + cp} ${from}, ${x0 + HALF_PERIOD - cp} ${to}, ${x0 + HALF_PERIOD} ${to}`;
  }

  const endX = segments * HALF_PERIOD;
  return `${path} L ${endX} ${WAVE_HEIGHT} L 0 ${WAVE_HEIGHT} Z`;
}

const FULL_WAVES = [
  { id: 'w1', className: 'waveTeal', baseline: 250, amplitude: 16, from: P.tertiary, to: P.secondary },
  { id: 'w2', className: 'waveMint', baseline: 325, amplitude: 20, from: P.primary, to: P.secondaryTan },
  { id: 'w3', className: 'waveBrand', baseline: 395, amplitude: 18, from: P.primaryMid, to: P.primaryDeep },
  { id: 'w4', className: 'waveDeep', baseline: 470, amplitude: 14, from: P.primaryDeep, to: P.neutral },
] as const;

/** Hero — original teal led, forest depth + bronze wash */
const HERO_WAVES = [
  {
    id: 'w1',
    className: 'waveTeal',
    baseline: 210,
    amplitude: 22,
    from: 'rgba(52, 132, 134, 0.88)',
    to: 'rgba(135, 184, 186, 0.48)',
  },
  {
    id: 'w2',
    className: 'waveMint',
    baseline: 290,
    amplitude: 26,
    from: 'rgba(44, 124, 136, 0.72)',
    to: 'rgba(168, 138, 86, 0.42)',
  },
  {
    id: 'w3',
    className: 'waveBrand',
    baseline: 370,
    amplitude: 24,
    from: 'rgba(52, 132, 134, 0.9)',
    to: 'rgba(10, 61, 46, 0.55)',
  },
  {
    id: 'w4',
    className: 'waveDeep',
    baseline: 448,
    amplitude: 18,
    from: 'rgba(15, 138, 93, 0.28)',
    to: 'rgba(10, 61, 46, 0.78)',
  },
] as const;

/** Punchy — teal / jade / forest / gold */
const PUNCHY_WAVES = [
  {
    id: 'w1',
    className: 'waveTeal',
    baseline: 200,
    amplitude: 28,
    from: 'rgba(64, 190, 163, 0.88)',
    to: 'rgba(44, 124, 136, 0.55)',
  },
  {
    id: 'w2',
    className: 'waveMint',
    baseline: 280,
    amplitude: 32,
    from: 'rgba(52, 132, 134, 0.92)',
    to: 'rgba(211, 177, 109, 0.4)',
  },
  {
    id: 'w3',
    className: 'waveBrand',
    baseline: 360,
    amplitude: 28,
    from: 'rgba(44, 124, 136, 0.92)',
    to: 'rgba(15, 138, 93, 0.55)',
  },
  {
    id: 'w4',
    className: 'waveDeep',
    baseline: 440,
    amplitude: 22,
    from: 'rgba(168, 138, 86, 0.35)',
    to: 'rgba(10, 61, 46, 0.9)',
  },
] as const;

export interface BrandWavesProps {
  className?: string;
  /** `hero` sleek dash boards · `full` login · `punchy` workspace cards */
  intensity?: 'hero' | 'full' | 'punchy';
  idPrefix?: string;
}

export function BrandWaves({
  className,
  intensity = 'hero',
  idPrefix = 'brand-wave',
}: BrandWavesProps): JSX.Element {
  const waves =
    intensity === 'full' ? FULL_WAVES
    : intensity === 'punchy' ? PUNCHY_WAVES
    : HERO_WAVES;

  const toneClass =
    intensity === 'full' ? styles.full
    : intensity === 'punchy' ? styles.punchy
    : styles.hero;

  const showAtmosphere = intensity === 'hero' || intensity === 'punchy';

  return (
    <div
      className={cn(styles.waves, toneClass, className)}
      aria-hidden="true"
    >
      {showAtmosphere ? (
        <>
          <div className={styles.auroraA} />
          <div className={styles.auroraB} />
          <div className={styles.sheen} />
        </>
      ) : null}
      {waves.map((wave) => (
        <div key={wave.id} className={cn(styles.band, styles[wave.className])}>
          <div className={styles.swell}>
            <div className={styles.track}>
              <svg
                className={styles.waveSvg}
                viewBox={`0 0 ${LOOP_WIDTH} ${WAVE_HEIGHT}`}
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient
                    id={`${idPrefix}-${wave.id}`}
                    gradientUnits="userSpaceOnUse"
                    x1="0"
                    y1="0"
                    x2={WAVE_WIDTH}
                    y2={WAVE_HEIGHT * (intensity === 'punchy' ? 0.45 : 0.35)}
                    spreadMethod="repeat"
                  >
                    <stop offset="0%" stopColor={wave.from} />
                    <stop offset={intensity === 'punchy' ? '45%' : '50%'} stopColor={wave.to} />
                    <stop offset="100%" stopColor={wave.from} />
                  </linearGradient>
                </defs>
                <path
                  d={waveBand(wave.baseline, wave.amplitude)}
                  fill={`url(#${idPrefix}-${wave.id})`}
                />
              </svg>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

'use client';

import { cn } from '@/lib/utils';

import styles from './BrandWaves.module.css';

const WAVE_WIDTH = 2880;
const LOOP_WIDTH = WAVE_WIDTH * 2;
const WAVE_HEIGHT = 620;
/** Long half-period = soft, editorial roll */
const HALF_PERIOD = 480;

/** Brand palette — Primary #00AC65 · Tertiary #326A9D · Secondary #DF7C2E · Neutral #0A1A1A */
const P = {
  primary: '#00AC65',
  primaryDeep: '#006B3F',
  primaryMid: '#008F54',
  tertiary: '#326A9D',
  tertiaryDeep: '#1E4568',
  secondary: '#DF7C2E',
  neutral: '#0A1A1A',
} as const;

/**
 * Soft sine-like band: long bezier handles so crests roll instead of spike.
 * Continuous across two periods for a seamless horizontal loop.
 */
function waveBand(baseline: number, amplitude: number): string {
  const segments = Math.round(LOOP_WIDTH / HALF_PERIOD);
  const cp = HALF_PERIOD * 0.42;
  let path = `M 0 ${baseline - amplitude}`;

  for (let i = 0; i < segments; i += 1) {
    const x0 = i * HALF_PERIOD;
    const from = i % 2 === 0 ? baseline - amplitude : baseline + amplitude;
    const to = i % 2 === 0 ? baseline + amplitude : baseline - amplitude;
    path += ` C ${x0 + cp} ${from}, ${x0 + HALF_PERIOD - cp} ${to}, ${x0 + HALF_PERIOD} ${to}`;
  }

  const endX = segments * HALF_PERIOD;
  return `${path} L ${endX} ${WAVE_HEIGHT} L 0 ${WAVE_HEIGHT} Z`;
}

const FULL_WAVES = [
  { id: 'w1', className: 'waveTeal', baseline: 250, amplitude: 30, from: P.tertiary, to: P.primaryDeep },
  { id: 'w2', className: 'waveMint', baseline: 325, amplitude: 36, from: P.primary, to: P.primaryMid },
  { id: 'w3', className: 'waveBrand', baseline: 395, amplitude: 32, from: P.primaryMid, to: P.primaryDeep },
  { id: 'w4', className: 'waveDeep', baseline: 470, amplitude: 26, from: P.primaryDeep, to: P.neutral },
] as const;

/** Hero — luminous bands with clearer crest definition on brand-green surfaces */
const HERO_WAVES = [
  {
    id: 'w1',
    className: 'waveTeal',
    baseline: 210,
    amplitude: 44,
    from: 'rgba(50, 106, 157, 0.78)',
    to: 'rgba(0, 172, 101, 0.52)',
  },
  {
    id: 'w2',
    className: 'waveMint',
    baseline: 290,
    amplitude: 50,
    from: 'rgba(0, 172, 101, 0.82)',
    to: 'rgba(0, 107, 63, 0.55)',
  },
  {
    id: 'w3',
    className: 'waveBrand',
    baseline: 370,
    amplitude: 46,
    from: 'rgba(0, 172, 101, 0.9)',
    to: 'rgba(50, 106, 157, 0.58)',
  },
  {
    id: 'w4',
    className: 'waveDeep',
    baseline: 448,
    amplitude: 36,
    from: 'rgba(223, 124, 46, 0.34)',
    to: 'rgba(0, 107, 63, 0.68)',
  },
] as const;

/** Punchy — workspace banners; denser crests, stronger chroma */
const PUNCHY_WAVES = [
  {
    id: 'w1',
    className: 'waveTeal',
    baseline: 200,
    amplitude: 52,
    from: 'rgba(50, 106, 157, 0.9)',
    to: 'rgba(0, 172, 101, 0.7)',
  },
  {
    id: 'w2',
    className: 'waveMint',
    baseline: 280,
    amplitude: 60,
    from: 'rgba(0, 172, 101, 0.95)',
    to: 'rgba(0, 107, 63, 0.75)',
  },
  {
    id: 'w3',
    className: 'waveBrand',
    baseline: 360,
    amplitude: 54,
    from: 'rgba(0, 172, 101, 1)',
    to: 'rgba(50, 106, 157, 0.78)',
  },
  {
    id: 'w4',
    className: 'waveDeep',
    baseline: 440,
    amplitude: 44,
    from: 'rgba(223, 124, 46, 0.5)',
    to: 'rgba(0, 107, 63, 0.85)',
  },
] as const;

export interface BrandWavesProps {
  className?: string;
  /** `hero` sleek dash boards · `full` login · `punchy` workspace cards */
  intensity?: 'hero' | 'full' | 'punchy';
  idPrefix?: string;
}

export function BrandWaves({
  className,
  intensity = 'hero',
  idPrefix = 'brand-wave',
}: BrandWavesProps): JSX.Element {
  const waves =
    intensity === 'full' ? FULL_WAVES
    : intensity === 'punchy' ? PUNCHY_WAVES
    : HERO_WAVES;

  const toneClass =
    intensity === 'full' ? styles.full
    : intensity === 'punchy' ? styles.punchy
    : styles.hero;

  const showAtmosphere = intensity === 'hero' || intensity === 'punchy';

  return (
    <div
      className={cn(styles.waves, toneClass, className)}
      aria-hidden="true"
    >
      {showAtmosphere ? (
        <>
          <div className={styles.auroraA} />
          <div className={styles.auroraB} />
          <div className={styles.sheen} />
        </>
      ) : null}
      {waves.map((wave) => (
        <div key={wave.id} className={cn(styles.band, styles[wave.className])}>
          <div className={styles.swell}>
            <div className={styles.track}>
              <svg
                className={styles.waveSvg}
                viewBox={`0 0 ${LOOP_WIDTH} ${WAVE_HEIGHT}`}
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient
                    id={`${idPrefix}-${wave.id}`}
                    gradientUnits="userSpaceOnUse"
                    x1="0"
                    y1="0"
                    x2={WAVE_WIDTH}
                    y2={WAVE_HEIGHT * (intensity === 'punchy' ? 0.45 : 0.35)}
                    spreadMethod="repeat"
                  >
                    <stop offset="0%" stopColor={wave.from} />
                    <stop offset={intensity === 'punchy' ? '45%' : '50%'} stopColor={wave.to} />
                    <stop offset="100%" stopColor={wave.from} />
                  </linearGradient>
                </defs>
                <path
                  d={waveBand(wave.baseline, wave.amplitude)}
                  fill={`url(#${idPrefix}-${wave.id})`}
                />
              </svg>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

'use client';

import { useCallback, useMemo, useState } from 'react';
import { CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

import type { PublishCampaignPayload, PublishTargetEntry } from '@/types/domain';
import { clearOutreachDraft } from '@/lib/outreach/draft-client';
import { cn } from '@/lib/utils';
import { useDialogFocus } from '@/components/ui/useDialogFocus';

import styles from './PublishingStep.module.css';

export interface PublishingStepLabels {
  headline: string;
  subtext: string;
  totalCandidatesLabel: string;
  channelLabel: string;
  channelEmail: string;
  viewCandidates: string;
  hideCandidates: string;
  colSeeker: string;
  colSelectedJobs: string;
  back: string;
  publish: string;
  publishing: string;
  confirmTitle: string;
  confirmBodyTemplate: string;
  confirmOk: string;
  confirmCancel: string;
  successTitle: string;
  successBodyTemplate: string;
  startNew: string;
  errorTitle: string;
  errorBody: string;
  retry: string;
}

interface PublishingStepProps {
  targets: PublishTargetEntry[];
  sessionKey: string;
  backHref: string;
  startNewHref: string;
  labels: PublishingStepLabels;
}

type PublishState = 'idle' | 'confirming' | 'loading' | 'success' | 'error';

const PAGE_SIZE = 10;

function applyN(template: string, n: number): string {
  return template.replace('{n}', String(n));
}

export function PublishingStep({
  targets,
  sessionKey,
  backHref,
  startNewHref,
  labels,
}: PublishingStepProps): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const [page, setPage] = useState(1);
  const [state, setState] = useState<PublishState>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const targetCount = targets.length;
  const totalPages = Math.max(1, Math.ceil(targetCount / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageTargets = useMemo(
    () => targets.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE),
    [targets, safePage],
  );

  function handlePublishClick(): void {
    setState('confirming');
  }

  const cancelConfirm = useCallback((): void => {
    setState('idle');
  }, []);

  const confirmDialogRef = useDialogFocus(state === 'confirming', cancelConfirm);

  async function confirmPublish(): Promise<void> {
    setState('loading');
    setErrorMsg(null);

    try {

      let message: PublishCampaignPayload['message'] = {
        purpose: 'vacancy',
        subject: '',
        body: '',
      };
      try {
        const raw = sessionStorage.getItem(sessionKey);
        if (raw) {
          const draft = JSON.parse(raw) as { purpose?: string; ar?: { subject?: string; body?: string } };
          message = {
            purpose: (draft.purpose as 'vacancy' | 'completeness') ?? 'vacancy',
            subject: draft.ar?.subject ?? '',
            body: draft.ar?.body ?? '',
          };
        }
      } catch {

      }

      const payload: PublishCampaignPayload = {
        targets,
        message,
        channel: 'email',
        batchContext: { mode: 'selected' },
      };

      const response = await fetch('/api/campaigns/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      await clearOutreachDraft();
      setState('success');
      toast.success(labels.successTitle);
    } catch {
      setErrorMsg(labels.errorBody);
      setState('error');
      toast.error(labels.errorTitle, { description: labels.errorBody });
    }
  }

  if (state === 'success') {
    return (
      <div className={styles.wrapper}>
        <div className={cn(styles.card, styles.successCard)}>
          <span className={styles.successIcon} aria-hidden="true">
            <CheckCircle2 size={48} strokeWidth={1.75} />
          </span>
          <h2 className={styles.successTitle}>{labels.successTitle}</h2>
          <p className={styles.successBody}>{applyN(labels.successBodyTemplate, targetCount)}</p>
          <Link href={startNewHref} className={styles.startNewButton}>
            {labels.startNew}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      {}
      {state === 'confirming' && (
        <div className={styles.dialogBackdrop}>
          <div
            ref={confirmDialogRef}
            className={styles.dialog}
            role="dialog"
            aria-modal="true"
            aria-labelledby="pub-confirm-title"
            tabIndex={-1}
          >
            <h2 id="pub-confirm-title" className={styles.dialogTitle}>{labels.confirmTitle}</h2>
            <p className={styles.dialogBody}>{applyN(labels.confirmBodyTemplate, targetCount)}</p>
            <div className={styles.dialogActions}>
              <button type="button" className={styles.dialogCancel} onClick={cancelConfirm}>
                {labels.confirmCancel}
              </button>
              <button type="button" className={styles.dialogOk} onClick={confirmPublish}>
                {labels.confirmOk}
              </button>
            </div>
          </div>
        </div>
      )}

      {}
      <div className={styles.topNav}>
        <Link href={backHref} className={styles.backLink}>
          <ChevronLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
          {labels.back}
        </Link>
      </div>

      <section className={styles.card}>

        {}
        <div className={styles.heroHeader}>
          <span className={styles.heroCheckCircle} aria-hidden="true">
            <CheckCircle2 size={36} strokeWidth={1.75} />
          </span>
          <h2 className={styles.heroHeadline}>{labels.headline}</h2>
          <p className={styles.heroSubtext}>{labels.subtext}</p>
        </div>

        {}
        <div className={styles.cardBody}>

        {}
        <div className={styles.statsRow}>
          <div className={styles.stat}>
            <span className={styles.statValue}>{targetCount}</span>
            <span className={styles.statLabel}>{labels.totalCandidatesLabel}</span>
          </div>
        </div>
        <div className={styles.channelRow}>
          <span className={styles.channelMeta}>{labels.channelLabel}:</span>
          <span className={styles.channelValue}>{labels.channelEmail}</span>
        </div>

          {}
          <div className={styles.expandSection}>
            <button
              type="button"
              className={styles.expandToggle}
              aria-expanded={expanded}
              onClick={() => setExpanded((prev) => !prev)}
            >
              <span>{expanded ? labels.hideCandidates : labels.viewCandidates}</span>
              {expanded
                ? <ChevronUp size={16} strokeWidth={2} className={styles.chevron} aria-hidden="true" />
                : <ChevronDown size={16} strokeWidth={2} className={styles.chevron} aria-hidden="true" />
              }
            </button>

            <div className={cn(styles.expandOuter, expanded && styles.expandOuterOpen)}>
              <div className={styles.tableWrap}>
                <table className={styles.table}>
                  <thead>
                    <tr>
                      <th>{labels.colSeeker}</th>
                      <th>{labels.colSelectedJobs}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pageTargets.map((target) => (
                      <tr key={target.nin}>
                        <td>
                          <div className={styles.seekerName}>{target.name}</div>
                        </td>
                        <td>
                          <ul className={styles.jobList}>
                            {target.jobTitles.length > 0
                              ? target.jobTitles.map((title) => (
                                  <li key={title} className={styles.jobItem}>{title}</li>
                                ))
                              : <li className={styles.jobItem}>—</li>
                            }
                          </ul>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {totalPages > 1 ? (
                  <div className={styles.pagination} style={{ display: 'flex', gap: 8, alignItems: 'center', justifyContent: 'center', marginTop: 12 }}>
                    <button
                      type="button"
                      className={styles.expandToggle}
                      disabled={safePage <= 1}
                      onClick={() => setPage((p) => Math.max(1, p - 1))}
                      aria-label="Previous page"
                    >
                      <ChevronLeft size={16} strokeWidth={2} />
                    </button>
                    <span>{safePage} / {totalPages}</span>
                    <button
                      type="button"
                      className={styles.expandToggle}
                      disabled={safePage >= totalPages}
                      onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                      aria-label="Next page"
                    >
                      <ChevronRight size={16} strokeWidth={2} />
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          </div>

        {}
        {state === 'error' && errorMsg && (
          <div className={styles.errorBanner} role="alert" aria-live="assertive">
            <strong className={styles.errorTitle}>{labels.errorTitle}</strong>
            <span>{errorMsg}</span>
          </div>
        )}

        </div>{}
      </section>

      {}
      <div className={styles.pageFooter}>
        <button
          type="button"
          className={styles.publishButton}
          disabled={state === 'loading'}
          onClick={state === 'error' ? confirmPublish : handlePublishClick}
        >
          {state === 'loading' && (
            <Loader2 size={16} strokeWidth={2} className={styles.spinner} aria-hidden="true" />
          )}
          {state === 'loading' ? labels.publishing : state === 'error' ? labels.retry : labels.publish}
        </button>
      </div>
    </div>
  );
}

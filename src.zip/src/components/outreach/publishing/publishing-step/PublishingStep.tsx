'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, ChevronLeft, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

import type { CampaignDraft, PublishCampaignPayload, PublishTargetEntry } from '@/types/domain';
import { clearOutreachDraft, saveOutreachDraft } from '@/lib/outreach/draft-client';
import { useDialogFocus } from '@/components/ui/useDialogFocus';
import {
  ReviewStep,
  type ReviewStepLabels,
} from '@/components/outreach/preparation/review-step/ReviewStep';

import styles from './PublishingStep.module.css';

export interface PublishingStepLabels {
  reviewColumnTitle: string;
  publishColumnTitle: string;
  headline: string;
  subtext: string;
  channelLabel: string;
  channelEmail: string;
  frequencyLabel: string;
  frequencyValue: string;
  back: string;
  publish: string;
  publishing: string;
  confirmTitle: string;
  confirmBodyTemplate: string;
  confirmOk: string;
  confirmCancel: string;
  successTitle: string;
  successBodyTemplate: string;
  startNew: string;
  errorTitle: string;
  errorBody: string;
  retry: string;
}

interface PublishingStepProps {
  targets: PublishTargetEntry[];
  batchName: string;
  sessionKey: string;
  backHref: string;
  startNewHref: string;
  labels: PublishingStepLabels;
  reviewLabels: ReviewStepLabels;
}

type PublishState = 'idle' | 'confirming' | 'loading' | 'success' | 'error';

const EMPTY_DRAFT: CampaignDraft = {
  purpose: null,
  template: 'interactive',
  en: { subject: '', body: '' },
  ar: { subject: '', body: '' },
  seededForPurpose: null,
};

function applyN(template: string, n: number): string {
  return template.replace('{n}', String(n));
}

function loadDraft(key: string): CampaignDraft {
  if (typeof window === 'undefined') return EMPTY_DRAFT;
  try {
    const raw = window.sessionStorage.getItem(key);
    if (!raw) return EMPTY_DRAFT;
    const parsed = JSON.parse(raw) as CampaignDraft;
    if (!parsed || typeof parsed !== 'object' || !('purpose' in parsed)) {
      return EMPTY_DRAFT;
    }
    return parsed;
  } catch {
    return EMPTY_DRAFT;
  }
}

export function PublishingStep({
  targets: initialTargets,
  batchName,
  sessionKey,
  backHref,
  startNewHref,
  labels,
  reviewLabels,
}: PublishingStepProps): JSX.Element {
  const [state, setState] = useState<PublishState>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [removedNins, setRemovedNins] = useState<Set<string>>(new Set());
  const [draft, setDraft] = useState<CampaignDraft>(EMPTY_DRAFT);

  useEffect(() => {
    setDraft(loadDraft(sessionKey));
  }, [sessionKey]);

  const targets = useMemo(
    () => initialTargets.filter((t) => !removedNins.has(t.nin)),
    [initialTargets, removedNins],
  );

  const targetCount = targets.length;

  const canPublish =
    targetCount > 0 &&
    Boolean(draft.purpose) &&
    draft.ar.subject.trim().length > 0 &&
    draft.ar.body.trim().length > 0;

  const persistTargets = useCallback(async (nextTargets: PublishTargetEntry[]): Promise<void> => {
    const activeSel = nextTargets.map((t) => t.nin);
    const nextJobsel: Record<string, string> = {};
    for (const target of nextTargets) {
      if (target.jobIds.includes('*')) nextJobsel[target.nin] = '*';
      else if (target.jobIds.length > 0) nextJobsel[target.nin] = target.jobIds.join('+');
    }
    await saveOutreachDraft({
      sel: activeSel,
      jobsel: nextJobsel,
    });
  }, []);

  function removeCandidate(nin: string): void {
    const nextRemoved = new Set([...removedNins, nin]);
    const nextTargets = initialTargets.filter((t) => !nextRemoved.has(t.nin));
    setRemovedNins(nextRemoved);
    void persistTargets(nextTargets).catch((error) => {
      toast.error(error instanceof Error ? error.message : 'Failed to update targets');
    });
  }

  function handlePublishClick(): void {
    if (!canPublish) return;
    setState('confirming');
  }

  const cancelConfirm = useCallback((): void => {
    setState('idle');
  }, []);

  const confirmDialogRef = useDialogFocus(state === 'confirming', cancelConfirm);

  async function confirmPublish(): Promise<void> {
    if (!canPublish) return;
    setState('loading');
    setErrorMsg(null);

    try {
      let message: PublishCampaignPayload['message'] = {
        purpose: 'vacancy',
        subject: '',
        body: '',
      };
      try {
        const raw = sessionStorage.getItem(sessionKey);
        if (raw) {
          const stored = JSON.parse(raw) as { purpose?: string; ar?: { subject?: string; body?: string } };
          message = {
            purpose: (stored.purpose as 'vacancy' | 'completeness') ?? 'vacancy',
            subject: stored.ar?.subject ?? '',
            body: stored.ar?.body ?? '',
          };
        }
      } catch {
      }

      const payload: PublishCampaignPayload = {
        targets,
        message,
        channel: 'email',
        batchContext: { mode: 'selected' },
      };

      const response = await fetch('/api/campaigns/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      await clearOutreachDraft();
      setState('success');
      toast.success(labels.successTitle);
    } catch {
      setErrorMsg(labels.errorBody);
      setState('error');
      toast.error(labels.errorTitle, { description: labels.errorBody });
    }
  }

  if (state === 'success') {
    return (
      <div className={styles.wrapper}>
        <div className={styles.successCard}>
          <span className={styles.successIcon} aria-hidden="true">
            <CheckCircle2 size={48} strokeWidth={1.75} />
          </span>
          <h2 className={styles.successTitle}>{labels.successTitle}</h2>
          <p className={styles.successBody}>{applyN(labels.successBodyTemplate, targetCount)}</p>
          <Link href={startNewHref} className={styles.startNewButton}>
            {labels.startNew}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      {state === 'confirming' && (
        <div className={styles.dialogBackdrop}>
          <div
            ref={confirmDialogRef}
            className={styles.dialog}
            role="dialog"
            aria-modal="true"
            aria-labelledby="pub-confirm-title"
            tabIndex={-1}
          >
            <h2 id="pub-confirm-title" className={styles.dialogTitle}>{labels.confirmTitle}</h2>
            <p className={styles.dialogBody}>{applyN(labels.confirmBodyTemplate, targetCount)}</p>
            <div className={styles.dialogActions}>
              <button type="button" className={styles.dialogCancel} onClick={cancelConfirm}>
                {labels.confirmCancel}
              </button>
              <button type="button" className={styles.dialogOk} onClick={() => void confirmPublish()}>
                {labels.confirmOk}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className={styles.layout}>
        <aside className={styles.reviewCol}>
          <h2 className={styles.columnTitle}>
            <span className={styles.stepIndex} aria-hidden="true">1</span>
            {labels.reviewColumnTitle}
          </h2>
          <div className={styles.columnBody}>
            <ReviewStep
              draft={draft}
              targets={targets}
              batchName={batchName}
              showContinue={false}
              onRemoveCandidate={removeCandidate}
              labels={reviewLabels}
            />
          </div>
        </aside>

        <main className={styles.publishCol}>
          <h2 className={styles.columnTitle}>
            <span className={styles.stepIndex} aria-hidden="true">2</span>
            {labels.publishColumnTitle}
          </h2>
          <div className={styles.columnBody}>
            <section className={styles.card}>
              <div className={styles.heroHeader}>
                <span className={styles.heroCheckCircle} aria-hidden="true">
                  <CheckCircle2 size={36} strokeWidth={1.75} />
                </span>
                <h3 className={styles.heroHeadline}>{labels.headline}</h3>
                <p className={styles.heroSubtext}>{labels.subtext}</p>
              </div>

              <div className={styles.cardBody}>
                <dl className={styles.infoList}>
                  <div className={styles.infoRow}>
                    <dt className={styles.infoLabel}>{labels.channelLabel}</dt>
                    <dd className={styles.infoValue}>{labels.channelEmail}</dd>
                  </div>
                  <div className={styles.infoRow}>
                    <dt className={styles.infoLabel}>{labels.frequencyLabel}</dt>
                    <dd className={styles.infoValue}>{labels.frequencyValue}</dd>
                  </div>
                </dl>

                {state === 'error' && errorMsg && (
                  <div className={styles.errorBanner} role="alert" aria-live="assertive">
                    <strong className={styles.errorTitle}>{labels.errorTitle}</strong>
                    <span>{errorMsg}</span>
                  </div>
                )}
              </div>
            </section>

            <button
              type="button"
              className={styles.publishButton}
              disabled={state === 'loading' || (!canPublish && state !== 'error')}
              onClick={state === 'error' ? () => void confirmPublish() : handlePublishClick}
            >
              {state === 'loading' && (
                <Loader2 size={16} strokeWidth={2} className={styles.spinner} aria-hidden="true" />
              )}
              {state === 'loading' ? labels.publishing : state === 'error' ? labels.retry : labels.publish}
            </button>
          </div>
        </main>
      </div>

      <div className={styles.footerNav}>
        <Link href={backHref} className={styles.backLink}>
          <ChevronLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
          {labels.back}
        </Link>
      </div>
    </div>
  );
}

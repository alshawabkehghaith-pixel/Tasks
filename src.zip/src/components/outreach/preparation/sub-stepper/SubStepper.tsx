import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import styles from './SubStepper.module.css';

interface SubStepperProps {
  currentStep: 0 | 1 | 2;
  labels: [string, string, string];
}

export function SubStepper({ currentStep, labels }: SubStepperProps): JSX.Element {
  return (
    <ol className={styles.list} aria-label={`${currentStep + 1} / ${labels.length}`}>
      {labels.map((label, index) => {
        const isCompleted = index < currentStep;
        const isActive = index === currentStep;

        return (
          <li
            key={label}
            className={cn(
              styles.item,
              isActive && styles.itemActive,
              isCompleted && styles.itemCompleted,
            )}
            aria-current={isActive ? 'step' : undefined}
          >
            <span
              className={cn(
                styles.circle,
                isActive && styles.circleActive,
                isCompleted && styles.circleCompleted,
              )}
              aria-hidden="true"
            >
              {isCompleted ? <Check size={13} strokeWidth={2.75} /> : index + 1}
            </span>
            <span className={styles.label}>{label}</span>
          </li>
        );
      })}
    </ol>
  );
}

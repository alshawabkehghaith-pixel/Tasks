import type { CampaignPurpose } from '@/types/domain';
import { cn } from '@/lib/utils';
import styles from './DesignStep.module.css';

interface DesignStepLabels {
  purposeLabel: string;
  purposeVacancyTitle: string;
  purposeVacancyDesc: string;
  purposeCompletenessTitle: string;
  purposeCompletenessDesc: string;
}

interface DesignStepProps {
  purpose: CampaignPurpose | null;
  onPurposeChange: (p: CampaignPurpose) => void;
  stackPurposeCards?: boolean;
  hidePurposeLabel?: boolean;
  labels: DesignStepLabels;
}

export function DesignStep({
  purpose,
  onPurposeChange,
  stackPurposeCards = false,
  hidePurposeLabel = false,
  labels,
}: DesignStepProps): JSX.Element {
  return (
    <div className={styles.wrapper}>
      <section className={styles.section}>
        {!hidePurposeLabel && (
          <h3 className={styles.sectionLabel}>{labels.purposeLabel}</h3>
        )}
        <div className={cn(styles.purposeRow, stackPurposeCards && styles.purposeRowStacked)}>
          {(['vacancy', 'completeness'] as const).map((key) => (
            <button
              key={key}
              type="button"
              className={cn(styles.purposeCard, purpose === key && styles.purposeCardSelected)}
              onClick={() => onPurposeChange(key)}
              aria-pressed={purpose === key}
            >
              <span className={styles.purposeTitle}>
                {key === 'vacancy' ? labels.purposeVacancyTitle : labels.purposeCompletenessTitle}
              </span>
              <span className={styles.purposeDesc}>
                {key === 'vacancy' ? labels.purposeVacancyDesc : labels.purposeCompletenessDesc}
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

import type { CampaignPurpose } from '@/types/domain';
import { cn } from '@/lib/utils';
import styles from './DesignStep.module.css';

interface DesignStepLabels {
  purposeLabel: string;
  purposeVacancyTitle: string;
  purposeVacancyDesc: string;
  purposeCompletenessTitle: string;
  purposeCompletenessDesc: string;
}

interface DesignStepProps {
  purpose: CampaignPurpose | null;
  onPurposeChange: (p: CampaignPurpose) => void;
  labels: DesignStepLabels;
}

export function DesignStep({ purpose, onPurposeChange, labels }: DesignStepProps): JSX.Element {
  return (
    <div className={styles.wrapper}>
      <section className={styles.section}>
        <h3 className={styles.sectionLabel}>{labels.purposeLabel}</h3>
        <div className={styles.purposeRow}>
          {(['vacancy', 'completeness'] as const).map((key) => (
            <button
              key={key}
              type="button"
              className={cn(styles.purposeCard, purpose === key && styles.purposeCardSelected)}
              onClick={() => onPurposeChange(key)}
              aria-pressed={purpose === key}
            >
              <span className={styles.purposeTitle}>
                {key === 'vacancy' ? labels.purposeVacancyTitle : labels.purposeCompletenessTitle}
              </span>
              <span className={styles.purposeDesc}>
                {key === 'vacancy' ? labels.purposeVacancyDesc : labels.purposeCompletenessDesc}
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

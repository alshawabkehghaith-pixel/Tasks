'use client';

import type { CampaignDraft, CampaignLanguageDraft } from '@/types/domain';
import { cn } from '@/lib/utils';
import styles from './WritingStep.module.css';

interface WritingStepLabels {
  subjectLabel: string;
  bodyLabel: string;
  subjectEmptyError: string;
  bodyEmptyError: string;
}

interface WritingStepProps {
  draft: CampaignDraft;
  onDraftChange: (patch: { ar?: Partial<CampaignLanguageDraft> }) => void;
  showErrors: boolean;
  disabled?: boolean;
  labels: WritingStepLabels;
}

export function WritingStep({
  draft,
  onDraftChange,
  showErrors,
  disabled = false,
  labels,
}: WritingStepProps): JSX.Element {
  const { ar } = draft;
  const subjectError = showErrors && !ar.subject.trim();
  const bodyError = showErrors && !ar.body.trim();

  function handleSubjectChange(value: string): void {
    if (disabled) return;
    onDraftChange({ ar: { subject: value } });
  }

  function handleBodyChange(value: string): void {
    if (disabled) return;
    onDraftChange({ ar: { body: value } });
  }

  return (
    <div className={cn(styles.wrapper, disabled && styles.wrapperDisabled)}>
      <div className={styles.field}>
        <label className={styles.fieldLabel} htmlFor="prep-subject">
          {labels.subjectLabel}
        </label>
        <input
          id="prep-subject"
          type="text"
          className={cn(styles.subjectInput, subjectError && styles.inputError)}
          value={ar.subject}
          onChange={(e) => handleSubjectChange(e.target.value)}
          dir="rtl"
          disabled={disabled}
          aria-invalid={subjectError}
          aria-describedby={subjectError ? 'prep-subject-err' : undefined}
        />
        {subjectError && (
          <span id="prep-subject-err" className={styles.error}>{labels.subjectEmptyError}</span>
        )}
      </div>

      <div className={styles.field}>
        <label className={styles.fieldLabel} htmlFor="prep-body">
          {labels.bodyLabel}
        </label>
        <textarea
          id="prep-body"
          className={cn(styles.bodyTextarea, bodyError && styles.inputError)}
          value={ar.body}
          onChange={(e) => handleBodyChange(e.target.value)}
          dir="rtl"
          rows={9}
          disabled={disabled}
          aria-invalid={bodyError}
          aria-describedby={bodyError ? 'prep-body-err' : undefined}
        />
        {bodyError && (
          <span id="prep-body-err" className={styles.error}>{labels.bodyEmptyError}</span>
        )}
      </div>
    </div>
  );
}

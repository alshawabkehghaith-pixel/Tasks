'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, ArrowRight } from 'lucide-react';

import type {
  CampaignDraft,
  CampaignLanguageDraft,
  CampaignPurpose,
  PreparationRepresentative,
  PublishTargetEntry,
} from '@/types/domain';
import { PURPOSE_DEFAULTS } from '@/lib/campaign-utils';
import { saveOutreachDraft } from '@/lib/outreach/draft-client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';

import { SubStepper } from '@/components/outreach/preparation/sub-stepper/SubStepper';
import { PhonePreview } from '@/components/outreach/preparation/phone-preview/PhonePreview';
import { DesignStep } from '@/components/outreach/preparation/design-step/DesignStep';
import { WritingStep } from '@/components/outreach/preparation/writing-step/WritingStep';
import { ReviewStep } from '@/components/outreach/preparation/review-step/ReviewStep';
import { useDialogFocus } from '@/components/ui/useDialogFocus';

import styles from './PreparationWorkspace.module.css';

type SubStep = 0 | 1 | 2;

const EMPTY_DRAFT: CampaignDraft = {
  purpose: null,
  template: 'interactive',
  en: { subject: '', body: '' },
  ar: { subject: '', body: '' },
  seededForPurpose: null,
};

export interface PreparationWorkspaceLabels {
  subStepDesign: string;
  subStepWriting: string;
  subStepReview: string;
  purposeLabel: string;
  purposeVacancyTitle: string;
  purposeVacancyDesc: string;
  purposeCompletenessTitle: string;
  purposeCompletenessDesc: string;
  purposeSwitchConfirmTitle: string;
  purposeSwitchConfirmBody: string;
  purposeSwitchConfirmOk: string;
  purposeSwitchConfirmCancel: string;
  subjectLabel: string;
  bodyLabel: string;
  subjectEmptyError: string;
  bodyEmptyError: string;
  reviewCheckTargets: string;
  reviewBatchLabel: string;
  reviewChannelLabel: string;
  reviewPurposeLabel: string;
  reviewChannelEmail: string;
  reviewPurposeVacancy: string;
  reviewPurposeCompleteness: string;
  reviewViewCandidates: string;
  reviewHideCandidates: string;
  reviewRemoveCandidate: string;
  reviewPageTemplate: string;
  reviewPrev: string;
  reviewNext: string;
  continueToPublishing: string;
  nextToWriting: string;
  nextToReview: string;
  prevToDesign: string;
  prevToWriting: string;
  backToVerification: string;
  previewTitle: string;
  previewCaptionTemplate: string;
  previewSubjectLabel: string;
  previewCtaVacancy: string;
  previewCtaCompleteness: string;
  previewLinkText: string;
  previewNoSelection: string;
}

interface PreparationWorkspaceProps {
  representative: PreparationRepresentative | null;
  initialTargets: PublishTargetEntry[];
  batchName: string;
  sessionKey: string;
  publishingHref: string;
  backToVerificationHref: string;
  labels: PreparationWorkspaceLabels;
}

function loadDraft(key: string): CampaignDraft {
  if (typeof window === 'undefined') return EMPTY_DRAFT;
  try {
    const raw = window.sessionStorage.getItem(key);
    if (!raw) return EMPTY_DRAFT;
    const parsed = JSON.parse(raw) as CampaignDraft;

    if (!parsed || typeof parsed !== 'object' || !('purpose' in parsed)) {
      return EMPTY_DRAFT;
    }
    return parsed;
  } catch {
    return EMPTY_DRAFT;
  }
}

function saveDraft(key: string, draft: CampaignDraft): void {
  if (typeof window === 'undefined') return;
  try {
    window.sessionStorage.setItem(key, JSON.stringify(draft));
  } catch {

  }
}

export function PreparationWorkspace({
  representative,
  initialTargets,
  batchName,
  sessionKey,
  publishingHref: _publishingHref,
  backToVerificationHref,
  labels,
}: PreparationWorkspaceProps): JSX.Element {
  void _publishingHref;
  const router = useRouter();
  const [draft, setDraftRaw] = useState<CampaignDraft>(() => loadDraft(sessionKey));
  const [removedNins, setRemovedNins] = useState<Set<string>>(new Set());
  const [savingPublish, setSavingPublish] = useState(false);

  const activeTargets = useMemo(
    () => initialTargets.filter((t) => !removedNins.has(t.nin)),
    [initialTargets, removedNins],
  );

  async function continueToPublishing(): Promise<void> {
    if (savingPublish) return;
    setSavingPublish(true);
    try {
      const activeSel = activeTargets.map((t) => t.nin);
      const nextJobsel: Record<string, string> = {};
      for (const target of activeTargets) {
        if (target.jobIds.includes('*')) nextJobsel[target.nin] = '*';
        else if (target.jobIds.length > 0) nextJobsel[target.nin] = target.jobIds.join('+');
      }
      await saveOutreachDraft({
        sel: activeSel,
        jobsel: nextJobsel,
      });
      router.push('/outreach/publishing');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to continue');
      setSavingPublish(false);
    }
  }

  function removeCandidate(nin: string): void {
    setRemovedNins((prev) => new Set([...prev, nin]));
  }
  const [subStep, setSubStep] = useState<SubStep>(0);
  const [pendingPurpose, setPendingPurpose] = useState<CampaignPurpose | null>(null);
  const [showWritingErrors, setShowWritingErrors] = useState(false);

  const setDraft = useCallback(
    (updater: (prev: CampaignDraft) => CampaignDraft) => {
      setDraftRaw((prev) => {
        const next = updater(prev);
        saveDraft(sessionKey, next);
        return next;
      });
    },
    [sessionKey],
  );

  useEffect(() => {
    setDraftRaw(loadDraft(sessionKey));
  }, [sessionKey]);

  function handlePurposeChange(newPurpose: CampaignPurpose): void {
    if (newPurpose === draft.purpose) return;

    if (draft.seededForPurpose !== null && draft.seededForPurpose !== newPurpose) {
      setPendingPurpose(newPurpose);
    } else {

      setDraft((prev) => ({ ...prev, purpose: newPurpose }));
    }
  }

  function confirmPurposeSwitch(): void {
    if (!pendingPurpose) return;
    const defaults = PURPOSE_DEFAULTS[pendingPurpose];
    setDraft(() => ({
      purpose: pendingPurpose,
      template: draft.template,
      en: { ...defaults.en },
      ar: { ...defaults.ar },
      seededForPurpose: pendingPurpose,
    }));
    setPendingPurpose(null);
  }

  const cancelPurposeSwitch = useCallback((): void => {
    setPendingPurpose(null);
  }, []);

  const purposeDialogRef = useDialogFocus(!!pendingPurpose, cancelPurposeSwitch);

  function handleDraftChange(patch: {
    en?: Partial<CampaignLanguageDraft>;
    ar?: Partial<CampaignLanguageDraft>;
  }): void {
    setDraft((prev) => ({
      ...prev,
      en: patch.en ? { ...prev.en, ...patch.en } : prev.en,
      ar: patch.ar ? { ...prev.ar, ...patch.ar } : prev.ar,
    }));
  }

  function goToWriting(): void {
    if (!draft.purpose) return;

    if (draft.seededForPurpose !== draft.purpose) {
      const defaults = PURPOSE_DEFAULTS[draft.purpose];
      setDraft((prev) => ({
        ...prev,
        en: { ...defaults.en },
        ar: { ...defaults.ar },
        seededForPurpose: draft.purpose,
      }));
    }
    setShowWritingErrors(false);
    setSubStep(1);
  }

  function goToReview(): void {
    const { ar } = draft;
    const valid =
      ar.subject.trim().length > 0 &&
      ar.body.trim().length > 0;

    if (!valid) {
      setShowWritingErrors(true);
      return;
    }
    setShowWritingErrors(false);
    setSubStep(2);
  }

  const nextDisabledOnDesign = !draft.purpose;

  return (
    <div className={styles.wrapper}>
      {}
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      {}
      {pendingPurpose && (
        <div className={styles.dialogBackdrop}>
          <div
            ref={purposeDialogRef}
            className={styles.dialog}
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            tabIndex={-1}
          >
            <h2 id="confirm-title" className={styles.dialogTitle}>{labels.purposeSwitchConfirmTitle}</h2>
            <p className={styles.dialogBody}>{labels.purposeSwitchConfirmBody}</p>
            <div className={styles.dialogActions}>
              <button type="button" className={styles.dialogCancel} onClick={cancelPurposeSwitch}>
                {labels.purposeSwitchConfirmCancel}
              </button>
              <button type="button" className={styles.dialogOk} onClick={confirmPurposeSwitch}>
                {labels.purposeSwitchConfirmOk}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className={cn(styles.layout, subStep === 0 && styles.layoutNoPreview)}>
        {}
        {subStep > 0 && (
          <aside className={styles.previewCol}>
            <div className={styles.card}>
              <span className={styles.cardGlow} aria-hidden="true" />
              <span className={styles.previewTitle}>{labels.previewTitle}</span>
              <PhonePreview
                draft={draft}
                activeLang={'ar'}
                representative={representative}
                labels={{
                  noSelection: labels.previewNoSelection,
                  subjectLabel: labels.previewSubjectLabel,
                  ctaVacancy: labels.previewCtaVacancy,
                  ctaCompleteness: labels.previewCtaCompleteness,
                  linkText: labels.previewLinkText,
                  previewCaption: labels.previewCaptionTemplate,
                }}
              />
            </div>
          </aside>
        )}

        {}
        <main className={styles.mainCol}>
          <div className={styles.card}>
            <span className={cn(styles.cardGlow, styles.cardGlowTeal)} aria-hidden="true" />

            {}
            {subStep === 0 && (
              <DesignStep
                purpose={draft.purpose}
                onPurposeChange={handlePurposeChange}
                labels={{
                  purposeLabel: labels.purposeLabel,
                  purposeVacancyTitle: labels.purposeVacancyTitle,
                  purposeVacancyDesc: labels.purposeVacancyDesc,
                  purposeCompletenessTitle: labels.purposeCompletenessTitle,
                  purposeCompletenessDesc: labels.purposeCompletenessDesc,
                }}
              />
            )}

            {}
            {subStep === 1 && draft.purpose && draft.template && (
              <WritingStep
                draft={draft}
                onDraftChange={handleDraftChange}
                showErrors={showWritingErrors}
                labels={{
                  subjectLabel: labels.subjectLabel,
                  bodyLabel: labels.bodyLabel,
                  subjectEmptyError: labels.subjectEmptyError,
                  bodyEmptyError: labels.bodyEmptyError,
                }}
              />
            )}

            {}
            {subStep === 2 && (
              <ReviewStep
                draft={draft}
                targets={activeTargets}
                batchName={batchName}
                continueLabel={labels.continueToPublishing}
                onContinue={() => void continueToPublishing()}
                continueBusy={savingPublish}
                onRemoveCandidate={removeCandidate}
                labels={{
                  checkTargets: labels.reviewCheckTargets,
                  batchLabel: labels.reviewBatchLabel,
                  purposeLabel: labels.reviewPurposeLabel,
                  purposeVacancy: labels.reviewPurposeVacancy,
                  purposeCompleteness: labels.reviewPurposeCompleteness,
                  viewCandidates: labels.reviewViewCandidates,
                  hideCandidates: labels.reviewHideCandidates,
                  removeCandidate: labels.reviewRemoveCandidate,
                  pageTemplate: labels.reviewPageTemplate,
                  prev: labels.reviewPrev,
                  next: labels.reviewNext,
                }}
              />
            )}

            {}
            <div className={styles.navRow}>
              {subStep === 0 && (
                <Link href={backToVerificationHref} className={styles.backLink}>
                  <ArrowLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
                  {labels.backToVerification}
                </Link>
              )}
              {subStep === 1 && (
                <button type="button" className={styles.prevButton} onClick={() => setSubStep(0)}>
                  <ArrowLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
                  {labels.prevToDesign}
                </button>
              )}
              {subStep === 2 && (
                <button type="button" className={styles.prevButton} onClick={() => setSubStep(1)}>
                  <ArrowLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
                  {labels.prevToWriting}
                </button>
              )}

              {subStep === 0 && (
                <button
                  type="button"
                  className={cn(styles.nextButton, nextDisabledOnDesign && styles.nextButtonDisabled)}
                  disabled={nextDisabledOnDesign}
                  onClick={goToWriting}
                >
                  {labels.nextToWriting}
                  <ArrowRight size={15} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" />
                </button>
              )}
              {subStep === 1 && (
                <button type="button" className={styles.nextButton} onClick={goToReview}>
                  {labels.nextToReview}
                  <ArrowRight size={15} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" />
                </button>
              )}
              {}
            </div>
          </div>
        </main>

        {}
        <aside className={styles.subStepperCol}>
          <div className={styles.card}>
            <span className={cn(styles.cardGlow, styles.cardGlowBrand)} aria-hidden="true" />
            <SubStepper
              currentStep={subStep}
              labels={[labels.subStepDesign, labels.subStepWriting, labels.subStepReview]}
            />
          </div>
        </aside>
      </div>
    </div>
  );
}

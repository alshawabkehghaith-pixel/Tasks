'use client';

import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';

import type {
  CampaignDraft,
  CampaignLanguageDraft,
  CampaignPurpose,
  PreparationRepresentative,
  PublishTargetEntry,
} from '@/types/domain';
import { PURPOSE_DEFAULTS } from '@/lib/campaign-utils';
import { saveOutreachDraft } from '@/lib/outreach/draft-client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';

import { PhonePreview } from '@/components/outreach/preparation/phone-preview/PhonePreview';
import { DesignStep } from '@/components/outreach/preparation/design-step/DesignStep';
import { WritingStep } from '@/components/outreach/preparation/writing-step/WritingStep';
import { useDialogFocus } from '@/components/ui/useDialogFocus';

import styles from './PreparationWorkspace.module.css';

const EMPTY_DRAFT: CampaignDraft = {
  purpose: null,
  template: 'interactive',
  en: { subject: '', body: '' },
  ar: { subject: '', body: '' },
  seededForPurpose: null,
};

export interface PreparationWorkspaceLabels {
  purposeLabel: string;
  purposeVacancyTitle: string;
  purposeVacancyDesc: string;
  purposeCompletenessTitle: string;
  purposeCompletenessDesc: string;
  purposeSwitchConfirmTitle: string;
  purposeSwitchConfirmBody: string;
  purposeSwitchConfirmOk: string;
  purposeSwitchConfirmCancel: string;
  writingColumnTitle: string;
  subjectLabel: string;
  bodyLabel: string;
  subjectEmptyError: string;
  bodyEmptyError: string;
  continueToPublishing: string;
  backToVerification: string;
  previewTitle: string;
  previewCaptionTemplate: string;
  previewSubjectLabel: string;
  previewCtaVacancy: string;
  previewCtaCompleteness: string;
  previewLinkText: string;
  previewNoSelection: string;
}

interface PreparationWorkspaceProps {
  representative: PreparationRepresentative | null;
  initialTargets: PublishTargetEntry[];
  batchName: string;
  sessionKey: string;
  publishingHref: string;
  backToVerificationHref: string;
  labels: PreparationWorkspaceLabels;
}

function loadDraft(key: string): CampaignDraft {
  if (typeof window === 'undefined') return EMPTY_DRAFT;
  try {
    const raw = window.sessionStorage.getItem(key);
    if (!raw) return EMPTY_DRAFT;
    const parsed = JSON.parse(raw) as CampaignDraft;

    if (!parsed || typeof parsed !== 'object' || !('purpose' in parsed)) {
      return EMPTY_DRAFT;
    }
    return parsed;
  } catch {
    return EMPTY_DRAFT;
  }
}

function saveDraft(key: string, draft: CampaignDraft): void {
  if (typeof window === 'undefined') return;
  try {
    window.sessionStorage.setItem(key, JSON.stringify(draft));
  } catch {
  }
}

function seedPurpose(purpose: CampaignPurpose, template: CampaignDraft['template']): CampaignDraft {
  const defaults = PURPOSE_DEFAULTS[purpose];
  return {
    purpose,
    template,
    en: { ...defaults.en },
    ar: { ...defaults.ar },
    seededForPurpose: purpose,
  };
}

export function PreparationWorkspace({
  representative,
  initialTargets,
  batchName: _batchName,
  sessionKey,
  publishingHref: _publishingHref,
  backToVerificationHref,
  labels,
}: PreparationWorkspaceProps): JSX.Element {
  void _batchName;
  void _publishingHref;
  const router = useRouter();
  const [draft, setDraftRaw] = useState<CampaignDraft>(() => loadDraft(sessionKey));
  const [savingPublish, setSavingPublish] = useState(false);
  const [pendingPurpose, setPendingPurpose] = useState<CampaignPurpose | null>(null);
  const [showWritingErrors, setShowWritingErrors] = useState(false);

  const setDraft = useCallback(
    (updater: (prev: CampaignDraft) => CampaignDraft) => {
      setDraftRaw((prev) => {
        const next = updater(prev);
        saveDraft(sessionKey, next);
        return next;
      });
    },
    [sessionKey],
  );

  useEffect(() => {
    const loaded = loadDraft(sessionKey);
    if (
      loaded.purpose &&
      loaded.seededForPurpose !== loaded.purpose &&
      !loaded.ar.subject.trim() &&
      !loaded.ar.body.trim()
    ) {
      const seeded = seedPurpose(loaded.purpose, loaded.template);
      saveDraft(sessionKey, seeded);
      setDraftRaw(seeded);
      return;
    }
    setDraftRaw(loaded);
  }, [sessionKey]);

  function handlePurposeChange(newPurpose: CampaignPurpose): void {
    if (newPurpose === draft.purpose) return;

    if (draft.seededForPurpose !== null && draft.seededForPurpose !== newPurpose) {
      setPendingPurpose(newPurpose);
      return;
    }

    setDraft((prev) => seedPurpose(newPurpose, prev.template));
    setShowWritingErrors(false);
  }

  function confirmPurposeSwitch(): void {
    if (!pendingPurpose) return;
    setDraft((prev) => seedPurpose(pendingPurpose, prev.template));
    setPendingPurpose(null);
    setShowWritingErrors(false);
  }

  const cancelPurposeSwitch = useCallback((): void => {
    setPendingPurpose(null);
  }, []);

  const purposeDialogRef = useDialogFocus(!!pendingPurpose, cancelPurposeSwitch);

  function handleDraftChange(patch: {
    en?: Partial<CampaignLanguageDraft>;
    ar?: Partial<CampaignLanguageDraft>;
  }): void {
    setDraft((prev) => ({
      ...prev,
      en: patch.en ? { ...prev.en, ...patch.en } : prev.en,
      ar: patch.ar ? { ...prev.ar, ...patch.ar } : prev.ar,
    }));
  }

  const canContinue =
    Boolean(draft.purpose) &&
    draft.ar.subject.trim().length > 0 &&
    draft.ar.body.trim().length > 0;

  async function continueToPublishing(): Promise<void> {
    if (savingPublish) return;

    if (!canContinue) {
      setShowWritingErrors(true);
      return;
    }

    setSavingPublish(true);
    try {
      const activeSel = initialTargets.map((t) => t.nin);
      const nextJobsel: Record<string, string> = {};
      for (const target of initialTargets) {
        if (target.jobIds.includes('*')) nextJobsel[target.nin] = '*';
        else if (target.jobIds.length > 0) nextJobsel[target.nin] = target.jobIds.join('+');
      }
      await saveOutreachDraft({
        sel: activeSel,
        jobsel: nextJobsel,
      });
      router.push('/outreach/publishing');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to continue');
      setSavingPublish(false);
    }
  }

  function clearCampaignDraft(): void {
    if (typeof window === 'undefined') return;
    try {
      window.sessionStorage.removeItem(sessionKey);
      const keysToRemove: string[] = [];
      for (let i = 0; i < window.sessionStorage.length; i += 1) {
        const key = window.sessionStorage.key(i);
        if (key?.startsWith('campaignDraftV1_')) keysToRemove.push(key);
      }
      for (const key of keysToRemove) window.sessionStorage.removeItem(key);
    } catch {
    }
  }

  function handleBackToVerification(): void {
    clearCampaignDraft();
    setDraftRaw(EMPTY_DRAFT);
    router.push(backToVerificationHref);
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      {pendingPurpose && (
        <div className={styles.dialogBackdrop}>
          <div
            ref={purposeDialogRef}
            className={styles.dialog}
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            tabIndex={-1}
          >
            <h2 id="confirm-title" className={styles.dialogTitle}>{labels.purposeSwitchConfirmTitle}</h2>
            <p className={styles.dialogBody}>{labels.purposeSwitchConfirmBody}</p>
            <div className={styles.dialogActions}>
              <button type="button" className={styles.dialogCancel} onClick={cancelPurposeSwitch}>
                {labels.purposeSwitchConfirmCancel}
              </button>
              <button type="button" className={styles.dialogOk} onClick={confirmPurposeSwitch}>
                {labels.purposeSwitchConfirmOk}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className={styles.layout}>
        <aside className={styles.templateCol}>
          <h2 className={styles.columnTitle}>
            <span className={styles.stepIndex} aria-hidden="true">1</span>
            {labels.purposeLabel}
          </h2>
          <div className={styles.columnBody}>
            <DesignStep
              purpose={draft.purpose}
              onPurposeChange={handlePurposeChange}
              stackPurposeCards
              hidePurposeLabel
              labels={{
                purposeLabel: labels.purposeLabel,
                purposeVacancyTitle: labels.purposeVacancyTitle,
                purposeVacancyDesc: labels.purposeVacancyDesc,
                purposeCompletenessTitle: labels.purposeCompletenessTitle,
                purposeCompletenessDesc: labels.purposeCompletenessDesc,
              }}
            />
          </div>
        </aside>

        <main className={styles.writingCol}>
          <h2 className={styles.columnTitle}>
            <span className={styles.stepIndex} aria-hidden="true">2</span>
            {labels.writingColumnTitle}
          </h2>
          <div className={styles.columnBody}>
            <WritingStep
              draft={draft}
              onDraftChange={handleDraftChange}
              showErrors={showWritingErrors}
              disabled={!draft.purpose}
              labels={{
                subjectLabel: labels.subjectLabel,
                bodyLabel: labels.bodyLabel,
                subjectEmptyError: labels.subjectEmptyError,
                bodyEmptyError: labels.bodyEmptyError,
              }}
            />
          </div>
        </main>

        <aside className={styles.previewCol}>
          <h2 className={styles.columnTitle}>
            <span className={styles.stepIndex} aria-hidden="true">3</span>
            {labels.previewTitle}
          </h2>
          <div className={styles.columnBody}>
            <PhonePreview
              draft={draft}
              activeLang={'ar'}
              representative={representative}
              labels={{
                noSelection: labels.previewNoSelection,
                subjectLabel: labels.previewSubjectLabel,
                ctaVacancy: labels.previewCtaVacancy,
                ctaCompleteness: labels.previewCtaCompleteness,
                linkText: labels.previewLinkText,
                previewCaption: labels.previewCaptionTemplate,
              }}
            />
          </div>
        </aside>
      </div>

      <div className={styles.footerNav}>
        <button
          type="button"
          className={styles.backLink}
          onClick={handleBackToVerification}
        >
          <ArrowLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
          {labels.backToVerification}
        </button>
        <button
          type="button"
          className={cn(styles.nextButton, (!canContinue || savingPublish) && styles.nextButtonDisabled)}
          disabled={!canContinue || savingPublish}
          onClick={() => void continueToPublishing()}
        >
          {labels.continueToPublishing}
          <ArrowRight size={15} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import type { CampaignDraft, CampaignPurpose } from '@/types/domain';
import { cn } from '@/lib/utils';
import styles from './ReviewStep.module.css';

const PAGE_SIZE = 5;

interface ReviewCandidate {
  nin: string;
  name: string;
}

export interface ReviewStepLabels {
  candidatesCountLabel: string;
  batchLabel: string;
  purposeLabel: string;
  purposeVacancy: string;
  purposeCompleteness: string;
  viewCandidates: string;
  hideCandidates: string;
  removeCandidate: string;
  pageTemplate: string;
  prev: string;
  next: string;
}

interface ReviewStepProps {
  draft: CampaignDraft;
  targets: ReviewCandidate[];
  batchName: string;
  continueLabel?: string;
  onContinue?: () => void;
  continueBusy?: boolean;
  showContinue?: boolean;
  onRemoveCandidate: (nin: string) => void;
  labels: ReviewStepLabels;
}

function getPurposeLabel(purpose: CampaignPurpose | null, labels: ReviewStepLabels): string {
  if (purpose === 'vacancy') return labels.purposeVacancy;
  if (purpose === 'completeness') return labels.purposeCompleteness;
  return '—';
}

function applyTemplate(template: string, replacements: Record<string, string | number>): string {
  return Object.entries(replacements).reduce(
    (s, [k, v]) => s.replace(`{${k}}`, String(v)),
    template,
  );
}

export function ReviewStep({
  draft,
  targets,
  batchName,
  continueLabel = '',
  onContinue,
  continueBusy = false,
  showContinue = true,
  onRemoveCandidate,
  labels,
}: ReviewStepProps): JSX.Element {
  const { purpose, template, ar } = draft;
  const [expanded, setExpanded] = useState(false);
  const [page, setPage] = useState(1);

  const targetCount = targets.length;
  const totalPages = Math.max(1, Math.ceil(targetCount / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageRows = targets.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const canContinue =
    targetCount > 0 &&
    Boolean(purpose) &&
    Boolean(template) &&
    ar.subject.trim().length > 0 &&
    ar.body.trim().length > 0;

  function handleRemove(nin: string): void {
    onRemoveCandidate(nin);

    const newTotal = targetCount - 1;
    const newTotalPages = Math.max(1, Math.ceil(newTotal / PAGE_SIZE));
    if (safePage > newTotalPages) setPage(newTotalPages);
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.countBox}>
        <span className={styles.countValue}>{targetCount}</span>
        <span className={styles.countLabel}>{labels.candidatesCountLabel}</span>
      </div>

      <div className={styles.candidatesSection}>
        <button
          type="button"
          className={styles.candidatesToggle}
          onClick={() => setExpanded((v) => !v)}
        >
          <span>{expanded ? labels.hideCandidates : labels.viewCandidates}</span>
          {expanded
            ? <ChevronRight size={14} strokeWidth={2} className={styles.toggleChevronUp} aria-hidden="true" />
            : <ChevronRight size={14} strokeWidth={2} className={styles.toggleChevron} aria-hidden="true" />}
        </button>

        {expanded && (
          <div className={styles.candidatesPanel}>
            <ul className={styles.candidatesList}>
              {pageRows.map((c) => (
                <li key={c.nin} className={styles.candidateRow}>
                  <div className={styles.candidateInfo}>
                    <span className={styles.candidateName}>{c.name}</span>
                    <span className={styles.candidateNin}>{c.nin}</span>
                  </div>
                  <button
                    type="button"
                    className={styles.removeBtn}
                    onClick={() => handleRemove(c.nin)}
                    aria-label={`${labels.removeCandidate}: ${c.name}`}
                  >
                    <X size={12} strokeWidth={2.5} />
                  </button>
                </li>
              ))}
            </ul>

            {totalPages > 1 && (
              <div className={styles.candidatesPagination}>
                <button
                  type="button"
                  className={cn(styles.pageBtn, safePage <= 1 && styles.pageBtnDisabled)}
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  aria-label={labels.prev}
                >
                  <ChevronLeft size={14} strokeWidth={2} />
                </button>
                <span className={styles.pageInfo}>
                  {applyTemplate(labels.pageTemplate, { p: safePage, t: totalPages })}
                </span>
                <button
                  type="button"
                  className={cn(styles.pageBtn, safePage >= totalPages && styles.pageBtnDisabled)}
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  aria-label={labels.next}
                >
                  <ChevronRight size={14} strokeWidth={2} />
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className={styles.divider} aria-hidden="true" />

      <dl className={styles.summary}>
        <div className={styles.summaryRow}>
          <dt className={styles.summaryKey}>{labels.batchLabel}</dt>
          <dd className={styles.summaryValue}>{batchName}</dd>
        </div>
        <div className={styles.summaryRow}>
          <dt className={styles.summaryKey}>{labels.purposeLabel}</dt>
          <dd className={styles.summaryValue}>{getPurposeLabel(purpose, labels)}</dd>
        </div>
      </dl>

      {showContinue && (
        canContinue && onContinue ? (
          <button
            type="button"
            className={styles.continueButton}
            onClick={onContinue}
            disabled={continueBusy}
          >
            {continueLabel}
          </button>
        ) : (
          <button type="button" className={styles.continueButton} disabled>
            {continueLabel}
          </button>
        )
      )}
    </div>
  );
}

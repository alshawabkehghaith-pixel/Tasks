'use client';

import { useEffect } from 'react';

const DRAFT_PREFIX = 'campaignDraftV1_';

export function ClearCampaignDraftOnMount(): null {
  useEffect(() => {
    try {
      const keysToRemove: string[] = [];
      for (let i = 0; i < window.sessionStorage.length; i += 1) {
        const key = window.sessionStorage.key(i);
        if (key?.startsWith(DRAFT_PREFIX)) keysToRemove.push(key);
      }
      for (const key of keysToRemove) window.sessionStorage.removeItem(key);
    } catch {
    }
  }, []);

  return null;
}

import type { CampaignDraft, CampaignPurpose, PreparationRepresentative } from '@/types/domain';
import { substituteVariables } from '@/lib/campaign-utils';
import styles from './PhonePreview.module.css';

interface PhonePreviewProps {
  draft: CampaignDraft;
  
  activeLang: 'en' | 'ar';
  representative: PreparationRepresentative | null;
  labels: {
    noSelection: string;
    subjectLabel: string;
    ctaVacancy: string;
    ctaCompleteness: string;
    linkText: string;
    previewCaption: string;
  };
}

function buildPreviewVars(
  representative: PreparationRepresentative | null,
  purpose: CampaignPurpose | null,
  lang: 'en' | 'ar',
): Record<string, string> {
  const name = representative?.name ?? (lang === 'ar' ? 'المرشّح' : 'Candidate');
  if (purpose === 'vacancy') {
    const jobList = (representative?.selectedJobLines ?? []).join('\n- ') || (lang === 'ar' ? 'الوظيفة 1 - جهة التوظيف' : 'Job 1 - Employer');
    return {
      'Candidate Name': name,
      'Job List': `- ${jobList}`,
      'Application Link': 'apply.example.com',
    };
  }
  if (purpose === 'completeness') {
    const sections = (representative?.missingFieldsEn ?? []).join('\n- ') || (lang === 'ar' ? 'السيرة الذاتية' : 'Resume');
    return {
      'Candidate Name': name,
      'Missing Sections': `- ${sections}`,
      'Profile Link': 'profile.example.com',
    };
  }
  return { 'Candidate Name': name };
}

export function PhonePreview({ draft, activeLang, representative, labels }: PhonePreviewProps): JSX.Element {
  const { purpose, template } = draft;
  const langDraft = activeLang === 'ar' ? draft.ar : draft.en;
  const vars = buildPreviewVars(representative, purpose, activeLang);

  const subjectRendered = substituteVariables(langDraft.subject || '', vars);
  const bodyRendered = substituteVariables(langDraft.body || '', vars);
  const contentDir = activeLang === 'ar' ? 'rtl' : 'ltr';
  const ctaLabel = purpose === 'completeness' ? labels.ctaCompleteness : labels.ctaVacancy;
  const hasContent = purpose && template && (langDraft.subject || langDraft.body);

  const previewCaption = hasContent ? labels.previewCaption : null;

  return (
    <div className={styles.wrapper}>
      <div className={styles.frame}>
        <div className={styles.notch} aria-hidden="true" />
        <div className={styles.screen}>
          {!hasContent ? (
            <div className={styles.empty}>{labels.noSelection}</div>
          ) : (
            <div className={styles.card} dir={contentDir}>
              <div className={styles.appChip} aria-hidden="true">
                <span className={styles.appDot} />
                Job Matching Engine
              </div>
              {langDraft.subject && (
                <div className={styles.subject}>{subjectRendered}</div>
              )}
              {langDraft.body && (
                <div className={styles.body}>
                  {bodyRendered.split('\n').map((line, i) => (

                    <p key={i} className={styles.bodyLine}>{line || '\u00A0'}</p>
                  ))}
                </div>
              )}
              {template === 'interactive' && (
                <button type="button" className={styles.ctaFilled} tabIndex={-1} aria-hidden="true">
                  {ctaLabel}
                </button>
              )}
              {template === 'professional' && (
                <button type="button" className={styles.ctaOutlined} tabIndex={-1} aria-hidden="true">
                  {ctaLabel}
                </button>
              )}
              {template === 'basic' && (
                <span className={styles.ctaLink}>{labels.linkText}</span>
              )}
            </div>
          )}
        </div>
        <div className={styles.homeBar} aria-hidden="true" />
      </div>
      {previewCaption && (
        <p className={styles.caption}>{previewCaption}</p>
      )}
    </div>
  );
}

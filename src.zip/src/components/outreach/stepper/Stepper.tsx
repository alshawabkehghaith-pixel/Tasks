import Link from 'next/link';
import { Check } from 'lucide-react';

import { cn } from '@/lib/utils';

import styles from './Stepper.module.css';

interface StepperProps {
  steps: string[];
  currentStepIndex: number;
  
  stepHrefs?: string[];
  
  progressLabel: string;
}

export function Stepper({ steps, currentStepIndex, stepHrefs, progressLabel }: StepperProps): JSX.Element {
  return (
    <ol className={styles.track} aria-label={progressLabel}>
      {steps.map((step, index) => {
        const isCompleted = index < currentStepIndex;
        const isActive = index === currentStepIndex;
        const state = isCompleted ? styles.completed : isActive ? styles.active : styles.upcoming;
        const href = stepHrefs?.[index];
        const clickable = Boolean(href) && isCompleted;

        const inner = (
          <>
            <span className={cn(styles.circle, state)} aria-hidden="true">
              {isCompleted ? <Check size={14} strokeWidth={2.75} /> : index + 1}
            </span>
            <span className={cn(styles.label, state)} aria-current={isActive ? 'step' : undefined}>
              {step}
            </span>
          </>
        );

        return (
          <li
            key={step}
            className={cn(
              styles.step,
              isCompleted && styles.done,
              isActive && styles.active,
            )}
          >
            {clickable && href ? (
              <Link href={href} className={styles.stepLink}>
                {inner}
              </Link>
            ) : (
              <span className={styles.stepStatic}>{inner}</span>
            )}
          </li>
        );
      })}
    </ol>
  );
}

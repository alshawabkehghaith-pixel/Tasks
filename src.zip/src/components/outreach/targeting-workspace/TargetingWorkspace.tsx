'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Crosshair, Search, X, Check, Info, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

import type { CandidateSummary, CandidateFacets, BatchTypeBatch, BatchType, CustomBatchFilters } from '@/types/domain';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import { CountUpNumber } from '@/components/dashboard/count-up-number/CountUpNumber';
import { cn } from '@/lib/utils';
import { searchCandidates, previewBatchCount } from '@/lib/actions';
import { saveOutreachDraft } from '@/lib/outreach/draft-client';
import { CustomBatchFilterPanel, EMPTY_CUSTOM_BATCH_FILTERS, hasAnyCustomFilter } from './CustomBatchFilterPanel';

import styles from './TargetingWorkspace.module.css';

export interface TargetingWorkspaceLabels {
  summaryTitle: string;
  channelRowLabel: string;
  channelEmail: string;
  frequencyRowLabel: string;
  frequencyValue: string;
  frequencyCaption: string;
  targetRowLabel: string;
  targetNoneSelected: string;
  targetCandidatesCountTemplate: string;
  targetBatchCaption: string;
  campaignTitle: string;
  campaignDesc: string;
  findCandidatesTitle: string;
  searchPlaceholder: string;
  jobMatchesCountTemplate: string;
  removeChip: string;
  orJobLevelDivider: string;
  batchTypeOctoberLabel: string;
  batchTypeFreshGradLabel: string;
  orCustomBatchDivider: string;
  customBatchClearAll: string;
  previewSelectFilter: string;
  previewNoMatch: string;
  previewMatchSuffix: string;
  disclaimer: string;
  nextButton: string;
}

interface TargetingWorkspaceProps {
  locale: Locale;
  facets: CandidateFacets;
  batchTypeBatches: BatchTypeBatch[];
  labels: TargetingWorkspaceLabels;
  initialSelection?: {
    candidates?: CandidateSummary[];
    batchType?: BatchType;
    customBatch?: { filters: CustomBatchFilters; count: number };
  };
}

interface ActiveCustomBatch {
  name: string;
  filters: CustomBatchFilters;
  count: number;
}

function applyCount(template: string, n: number): string {
  return template.replace('{n}', String(n));
}

function CountTemplate({ template, value }: { template: string; value: number }): JSX.Element {
  const [before, after] = template.split('{n}');
  return (
    <>
      {before}
      <CountUpNumber value={value} durationMs={450} />
      {after}
    </>
  );
}

function buildBatchName(filters: CustomBatchFilters, locale: Locale): string {
  if (filters.regions.length > 0) {
    const shown = filters.regions.slice(0, 2).join('، ');
    return filters.regions.length > 2 ? `${shown} +${filters.regions.length - 2}` : shown;
  }
  if (filters.readiness.length > 0) return filters.readiness.join(' / ');
  return messages.targetCustomBatch[locale];
}

export function TargetingWorkspace({
  locale,
  facets,
  batchTypeBatches,
  labels,
  initialSelection,
}: TargetingWorkspaceProps): JSX.Element {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [selectedCandidates, setSelectedCandidates] = useState<CandidateSummary[]>(
    () => initialSelection?.candidates ?? [],
  );
  const [selectedBatchType, setSelectedBatchType] = useState<BatchType | null>(
    () => initialSelection?.batchType ?? null,
  );
  const [activeCustomBatch, setActiveCustomBatch] = useState<ActiveCustomBatch | null>(
    () =>
      initialSelection?.customBatch
        ? {
            name: buildBatchName(initialSelection.customBatch.filters, locale),
            filters: initialSelection.customBatch.filters,
            count: initialSelection.customBatch.count,
          }
        : null,
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<CandidateSummary[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [draftFilters, setDraftFilters] = useState<CustomBatchFilters>(
    () => initialSelection?.customBatch?.filters ?? EMPTY_CUSTOM_BATCH_FILTERS,
  );
  const [previewCount, setPreviewCount] = useState<number | null>(
    () => initialSelection?.customBatch?.count ?? null,
  );

  useEffect(() => {
    const term = searchQuery.trim();
    if (!term) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }

    let cancelled = false;
    setSearchLoading(true);
    const timer = setTimeout(() => {
      searchCandidates(term)
        .then((data) => {
          if (!cancelled) {
            setSearchResults(data);
            setSearchLoading(false);
          }
        })
        .catch(() => {
          if (!cancelled) {
            setSearchLoading(false);
            toast.error(messages.targetSearchError[locale]);
          }
        });
    }, 300);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [searchQuery, locale]);

  useEffect(() => {
    if (!hasAnyCustomFilter(draftFilters)) {
      setPreviewCount(null);
      setActiveCustomBatch(null);
      return;
    }

    let cancelled = false;

    previewBatchCount(draftFilters)
      .then((count) => {
        if (cancelled) return;
        const data = { count };
        setPreviewCount(data.count);
        if (data.count > 0) {
          setActiveCustomBatch({
            name: buildBatchName(draftFilters, locale),
            filters: draftFilters,
            count: data.count,
          });
          setSelectedCandidates([]);
          setSelectedBatchType(null);
        } else {
          setActiveCustomBatch(null);
        }
      })
      .catch(() => {
        if (!cancelled) toast.error(messages.targetBatchSizeError[locale]);
      });

    return () => { cancelled = true; };
  }, [draftFilters, locale]);

  const batchTypeCount = useMemo(() => {
    if (!selectedBatchType) return null;
    return batchTypeBatches.find((b) => b.key === selectedBatchType)?.count ?? null;
  }, [selectedBatchType, batchTypeBatches]);

  const customTargetCount =
    activeCustomBatch?.count ?? (hasAnyCustomFilter(draftFilters) && previewCount ? previewCount : null);

  const canContinue =
    selectedCandidates.length > 0 || selectedBatchType !== null || activeCustomBatch !== null;

  async function handleContinue(): Promise<void> {
    if (!canContinue || saving) return;
    setSaving(true);
    try {
      if (selectedCandidates.length > 0) {
        await saveOutreachDraft({
          mode: 'candidates',
          nins: selectedCandidates.map((candidate) => candidate.nin),
          nin: '',
          batchType: '',
          levels: [],
          regions: [],
          customFilters: null,
          sel: [],
          jobsel: {},
          matchmap: {},
        }, true);
      } else if (selectedBatchType) {
        await saveOutreachDraft({
          mode: 'batchType',
          nins: [],
          nin: '',
          batchType: selectedBatchType,
          levels: [],
          regions: [],
          customFilters: null,
          sel: [],
          jobsel: {},
          matchmap: {},
        }, true);
      } else if (activeCustomBatch) {
        await saveOutreachDraft({
          mode: 'custom',
          nins: [],
          nin: '',
          batchType: '',
          levels: [],
          regions: activeCustomBatch.filters.regions,
          customFilters: activeCustomBatch.filters,
          sel: [],
          jobsel: {},
          matchmap: {},
        }, true);
      }
      router.push('/outreach/verification');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to continue');
      setSaving(false);
    }
  }

  function selectCandidate(candidate: CandidateSummary): void {
    setSelectedCandidates((prev) => (prev.some((c) => c.nin === candidate.nin) ? prev : [...prev, candidate]));
    setSearchQuery('');
    setSearchResults([]);
    setSelectedBatchType(null);
    setActiveCustomBatch(null);
  }

  function removeCandidate(nin: string): void {
    setSelectedCandidates((prev) => prev.filter((c) => c.nin !== nin));
  }

  function toggleBatchType(bt: BatchType): void {
    setSelectedBatchType((prev) => (prev === bt ? null : bt));
    setSelectedCandidates([]);
    setActiveCustomBatch(null);
  }

  function handleFilterChange(nextFilters: CustomBatchFilters): void {
    setDraftFilters(nextFilters);
    setSelectedCandidates([]);
    setSelectedBatchType(null);
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={cn(styles.blob, styles.blobTeal)} />
      </div>

      <div className={styles.layout}>
        {}
        <section className={styles.card}>
          <span className={cn(styles.cardGlow, styles.cardGlowBrand)} aria-hidden="true" />
          <div className={styles.campaignInfo}>
            <h3 className={styles.campaignInfoTitle}>{labels.campaignTitle}</h3>
            <p className={styles.campaignInfoDesc}>{labels.campaignDesc}</p>
          </div>

          <div className={styles.cardHeader}>
            <span className={styles.cardIcon}>
              <Crosshair size={16} strokeWidth={1.75} />
            </span>
            <h2 className={styles.cardTitle}>{labels.summaryTitle}</h2>
          </div>

          <dl className={styles.statList}>
            <div className={styles.statRow}>
              <dt className={styles.statLabel}>{labels.channelRowLabel}</dt>
              <dd className={styles.statValue}>{labels.channelEmail}</dd>
            </div>

            <div className={styles.statRow}>
              <dt className={styles.statLabel}>{labels.frequencyRowLabel}</dt>
              <dd className={styles.statCell}>
                <span className={styles.statValue}>{labels.frequencyValue}</span>
              </dd>
            </div>

            <div className={styles.statRow}>
              <dt className={styles.statLabel}>{labels.targetRowLabel}</dt>
              <dd className={styles.statCell}>
                {selectedCandidates.length > 0 && (
                  <span className={styles.statValue}>
                    <CountTemplate template={labels.targetCandidatesCountTemplate} value={selectedCandidates.length} />
                  </span>
                )}
                {selectedCandidates.length === 0 && batchTypeCount !== null && (
                  <>
                    <span className={styles.statValue}>
                      <CountTemplate template={labels.targetCandidatesCountTemplate} value={batchTypeCount} />
                    </span>
                    <span className={styles.statCaption}>{labels.targetBatchCaption}</span>
                  </>
                )}
                {selectedCandidates.length === 0 && batchTypeCount === null && customTargetCount !== null && (
                  <>
                    <span className={styles.statValue}>
                      <CountTemplate template={labels.targetCandidatesCountTemplate} value={customTargetCount} />
                    </span>
                    <span className={styles.statCaption}>{labels.targetBatchCaption}</span>
                  </>
                )}
                {selectedCandidates.length === 0 && batchTypeCount === null && customTargetCount === null && (
                  <span className={styles.statValue}>{labels.targetNoneSelected}</span>
                )}
              </dd>
            </div>
          </dl>

        </section>

        {}
        <section className={cn(styles.card, styles.rightCard)}>
          <span className={cn(styles.cardGlow, styles.cardGlowTeal)} aria-hidden="true" />
          <div className={styles.cardHeader}>
            <span className={styles.cardIcon}>
              <Search size={16} strokeWidth={2} />
            </span>
            <h2 className={styles.cardTitle}>{labels.findCandidatesTitle}</h2>
          </div>

          <div className={styles.searchField}>
            <Search size={15} strokeWidth={2} className={styles.searchFieldIcon} aria-hidden="true" />
            <input
              type="search"
              className={styles.searchInput}
              placeholder={labels.searchPlaceholder}
              aria-label={labels.searchPlaceholder}
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
            />
          </div>

          {searchQuery.trim().length > 0 && searchResults.length > 0 && (
            <ul className={styles.searchResults}>
              {searchResults.map((candidate) => (
                <li key={candidate.nin}>
                  <button type="button" className={styles.searchResultRow} onClick={() => selectCandidate(candidate)}>
                    <span className={styles.searchResultName}>{candidate.name}</span>
                    <span className={styles.searchResultMeta}>{candidate.nin}</span>
                    <span className={styles.searchResultMatches}>{applyCount(labels.jobMatchesCountTemplate, candidate.matchCount)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}

          {searchQuery.trim().length > 0 && searchResults.length === 0 && (
            <p className={styles.searchFeedback} role="status" aria-live="polite">
              {searchLoading
                ? messages.targetingSearchSearching[locale]
                : messages.targetingSearchNoResults[locale]}
            </p>
          )}

          {selectedCandidates.length > 0 && (
            <div className={styles.chipList}>
              {selectedCandidates.map((candidate) => (
                <span key={candidate.nin} className={styles.chip}>
                  <span className={styles.chipLabel}>
                    {candidate.name} · {candidate.nin}
                  </span>
                  <button
                    type="button"
                    className={styles.chipRemove}
                    onClick={() => removeCandidate(candidate.nin)}
                    aria-label={labels.removeChip}
                  >
                    <X size={12} strokeWidth={2.5} />
                  </button>
                </span>
              ))}
            </div>
          )}

          <div className={styles.divider}>{labels.orJobLevelDivider}</div>

          <div className={styles.batchTypeGrid}>
            {batchTypeBatches.map((batch) => {
              const isSelected = selectedBatchType === batch.key;
              const batchLabel = batch.key === 'octoberBatch' ? labels.batchTypeOctoberLabel : labels.batchTypeFreshGradLabel;
              return (
                <button
                  key={batch.key}
                  type="button"
                  className={cn(styles.batchTypeCard, isSelected && styles.batchTypeCardSelected)}
                  onClick={() => toggleBatchType(batch.key)}
                >
                  {isSelected && (
                    <span className={styles.levelCardBadge}>
                      <Check size={11} strokeWidth={3} />
                    </span>
                  )}
                  <span className={styles.levelCardLabel}>{batchLabel}</span>
                  <span className={styles.levelCardCount}>{batch.count}</span>
                </button>
              );
            })}
          </div>

          <div className={styles.divider}>{labels.orCustomBatchDivider}</div>

          <div className={styles.customBatch}>
            <CustomBatchFilterPanel
              locale={locale}
              facets={facets}
              filters={draftFilters}
              clearAllLabel={labels.customBatchClearAll}
              onChange={handleFilterChange}
            />

            <div className={styles.previewRow}>
              {!hasAnyCustomFilter(draftFilters) && (
                <span className={styles.previewNeutral}>{labels.previewSelectFilter}</span>
              )}
              {hasAnyCustomFilter(draftFilters) && previewCount === 0 && (
                <span className={styles.previewDead}>{labels.previewNoMatch}</span>
              )}
              {hasAnyCustomFilter(draftFilters) && previewCount !== null && previewCount > 0 && (
                <span className={styles.previewMatch}>
                  <span className={styles.previewCount}>{previewCount}</span> {labels.previewMatchSuffix}
                </span>
              )}
            </div>
          </div>

          <p className={styles.disclaimer}>
            <Info size={14} strokeWidth={2} className={styles.disclaimerIcon} aria-hidden="true" />
            <span>{labels.disclaimer}</span>
          </p>
        </section>
      </div>

      <div className={styles.footer}>
        {canContinue ? (
          <button type="button" className={styles.nextButton} onClick={() => void handleContinue()} disabled={saving}>
            {saving ? <Loader2 size={16} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" /> : null}
            {labels.nextButton}
            {!saving ? <ArrowRight size={16} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" /> : null}
          </button>
        ) : (
          <button type="button" className={cn(styles.nextButton, styles.nextButtonDisabled)} disabled>
            {labels.nextButton}
            <ArrowRight size={16} strokeWidth={2.25} className={styles.nextIcon} aria-hidden="true" />
          </button>
        )}
      </div>
    </div>
  );
}

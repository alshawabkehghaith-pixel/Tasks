'use client';

import { useMemo, useState } from 'react';
import { ChevronRight, X } from 'lucide-react';

import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import type { CandidateFacets, CustomBatchFilters, Readiness } from '@/types/domain';
import { cn } from '@/lib/utils';

import styles from './TargetingWorkspace.module.css';

type Bin = { min: number; max: number; en: string; ar: string };

const AGE_BINS: readonly Bin[] = [
  { en: 'Under 25', ar: 'أقل من 25', min: 0,  max: 24 },
  { en: '25–29',    ar: '25–29',    min: 25, max: 29 },
  { en: '30–34',    ar: '30–34',    min: 30, max: 34 },
  { en: '35–39',    ar: '35–39',    min: 35, max: 39 },
  { en: '40+',      ar: '40+',      min: 40, max: 99 },
];

const EXP_BINS: readonly Bin[] = [
  { en: '0–2 yrs',  ar: '0–2 سنوات',  min: 0,  max: 2  },
  { en: '3–5 yrs',  ar: '3–5 سنوات',  min: 3,  max: 5  },
  { en: '6–10 yrs', ar: '6–10 سنوات', min: 6,  max: 10 },
  { en: '11+ yrs',  ar: '11+ سنة',    min: 11, max: 99 },
];

function binLabel(bin: Bin, locale: Locale): string {
  return locale === 'ar' ? bin.ar : bin.en;
}

function readinessChipLabel(value: Readiness, locale: Locale): string {
  if (value === 'ready') return messages.candListReadinessReady[locale];
  if (value === 'partial') return messages.candListReadinessPartial[locale];
  return messages.candListReadinessIncomplete[locale];
}

export const EMPTY_CUSTOM_BATCH_FILTERS: CustomBatchFilters = {
  regions: [],
  cities: [],
  genders: [],
  ages: [],
  qualifications: [],
  occupationalFields: [],
  yearsExperience: [],
  statuses: [],
  readiness: [],
};

export function hasAnyCustomFilter(filters: CustomBatchFilters): boolean {
  return Object.values(filters).some((arr) => (arr as unknown[]).length > 0);
}

type SectionKey = keyof CustomBatchFilters;

const SECTION_KEYS: SectionKey[] = [
  'readiness',
  'regions',
  'cities',
  'genders',
  'ages',
  'qualifications',
  'occupationalFields',
  'yearsExperience',
  'statuses',
];

const DEFAULT_OPEN = new Set<SectionKey>();

function getSectionLabel(key: SectionKey, locale: Locale): string {
  switch (key) {
    case 'readiness':          return messages.colReadiness[locale];
    case 'regions':            return messages.colRegion[locale];
    case 'cities':             return messages.colCity[locale];
    case 'genders':            return messages.cand360Gender[locale];
    case 'ages':               return messages.cand360Age[locale];
    case 'qualifications':     return messages.cand360Qualification[locale];
    case 'occupationalFields': return messages.colOccupationalField[locale];
    case 'yearsExperience':    return messages.cand360YearsExp[locale];
    case 'statuses':           return messages.colEmploymentStatus[locale];
  }
}

function getSimpleOptions(
  key: SectionKey,
  facets: CandidateFacets,
  locale: Locale,
): Array<{ value: string; label: string }> {
  switch (key) {
    case 'readiness':
      return (facets.readiness as Readiness[]).map((v) => ({
        value: v,
        label: readinessChipLabel(v, locale),
      }));
    case 'regions':
      return facets.regions.map((v) => ({ value: v, label: v }));
    case 'cities':
      return facets.cities.map((v) => ({ value: v, label: v }));
    case 'genders':
      return facets.genders.map((v) => ({ value: v, label: v }));
    case 'qualifications':
      return facets.qualifications.map((v) => ({ value: v, label: v }));
    case 'occupationalFields':
      return facets.occupationalFields.map((v) => ({ value: v, label: v }));
    case 'statuses':
      return facets.statuses.map((v) => ({ value: v, label: v }));
    default:
      return [];
  }
}

function getActiveCount(
  key: SectionKey,
  filters: CustomBatchFilters,
  facets: CandidateFacets,
): number {
  if (key === 'ages') {
    const sel = filters.ages;
    return AGE_BINS.filter((bin) =>
      facets.ages.filter((v) => v >= bin.min && v <= bin.max).some((v) => sel.includes(v)),
    ).length;
  }
  if (key === 'yearsExperience') {
    const sel = filters.yearsExperience;
    return EXP_BINS.filter((bin) =>
      facets.yearsExperience.filter((v) => v >= bin.min && v <= bin.max).some((v) => sel.includes(v)),
    ).length;
  }
  return (filters[key] as string[]).length;
}

interface CustomBatchFilterPanelProps {
  locale: Locale;
  facets: CandidateFacets;
  filters: CustomBatchFilters;
  clearAllLabel: string;
  onChange: (filters: CustomBatchFilters) => void;
}

export function CustomBatchFilterPanel({
  locale,
  facets,
  filters,
  clearAllLabel,
  onChange,
}: CustomBatchFilterPanelProps): JSX.Element {
  const [openSections, setOpenSections] = useState<Set<SectionKey>>(DEFAULT_OPEN);

  const hasAny = useMemo(() => hasAnyCustomFilter(filters), [filters]);

  function toggleSection(key: SectionKey): void {
    setOpenSections((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleSimple(key: SectionKey, value: string): void {
    const current = filters[key] as string[];
    const isActive = current.includes(value);
    onChange({
      ...filters,
      [key]: isActive ? current.filter((v) => v !== value) : [...current, value],
    });
  }

  function toggleBucket(key: 'ages' | 'yearsExperience', binValues: number[]): void {
    const current = filters[key] as number[];
    const allSelected = binValues.every((v) => current.includes(v));
    onChange({
      ...filters,
      [key]: allSelected
        ? current.filter((v) => !binValues.includes(v))
        : [...current, ...binValues.filter((v) => !current.includes(v))],
    });
  }

  function clearAll(): void {
    onChange(EMPTY_CUSTOM_BATCH_FILTERS);
  }

  return (
    <div className={styles.cfp}>
      {(() => {
        const chips: Array<{ label: string; id: string; removeFn: () => void }> = [];
        const stringKeys = ['readiness', 'regions', 'cities', 'genders', 'qualifications', 'occupationalFields', 'statuses'] as SectionKey[];
        for (const key of stringKeys) {
          for (const val of filters[key] as string[]) {
            const label = key === 'readiness' ? readinessChipLabel(val as Readiness, locale) : val;
            chips.push({ label, id: `${key}:${val}`, removeFn: () => toggleSimple(key, val) });
          }
        }
        for (const bin of AGE_BINS) {
          const binVals = facets.ages.filter((v) => v >= bin.min && v <= bin.max);
          if (binVals.length > 0 && binVals.some((v) => filters.ages.includes(v))) {
            chips.push({ label: binLabel(bin, locale), id: `ages:${bin.min}`, removeFn: () => toggleBucket('ages', binVals) });
          }
        }
        for (const bin of EXP_BINS) {
          const binVals = facets.yearsExperience.filter((v) => v >= bin.min && v <= bin.max);
          if (binVals.length > 0 && binVals.some((v) => filters.yearsExperience.includes(v))) {
            chips.push({ label: binLabel(bin, locale), id: `exp:${bin.min}`, removeFn: () => toggleBucket('yearsExperience', binVals) });
          }
        }
        if (chips.length === 0) return null;
        return (
          <div className={styles.cfpSelectedChips}>
            {chips.map((chip) => (
              <button key={chip.id} type="button" className={styles.cfpSelectedChip} onClick={chip.removeFn}>
                <span>{chip.label}</span>
                <X size={10} strokeWidth={2.5} aria-hidden="true" />
              </button>
            ))}
          </div>
        );
      })()}
      {SECTION_KEYS.map((key) => {
        const isOpen = openSections.has(key);
        const count = getActiveCount(key, filters, facets);
        const isBucket = key === 'ages' || key === 'yearsExperience';
        const sectionLabel = getSectionLabel(key, locale);

        return (
          <div key={key} className={styles.cfpSection}>
            <button
              type="button"
              className={cn(styles.cfpHeader, count > 0 && styles.cfpHeaderActive)}
              onClick={() => toggleSection(key)}
            >
              <ChevronRight
                size={13}
                strokeWidth={2.5}
                className={cn(styles.cfpChevron, isOpen && styles.cfpChevronOpen)}
                aria-hidden="true"
              />
              <span className={styles.cfpTitle}>{sectionLabel}</span>
              {count > 0 && <span className={styles.cfpBadge}>{count}</span>}
            </button>

            {isOpen && (
              <div className={styles.cfpBody}>
                {isBucket ? (
                  (key === 'ages' ? AGE_BINS : EXP_BINS).map((bin) => {
                    const facetValues = (key === 'ages' ? facets.ages : facets.yearsExperience)
                      .filter((v) => v >= bin.min && v <= bin.max);
                    if (facetValues.length === 0) return null;
                    const isActive = facetValues.some((v) =>
                      (filters[key] as number[]).includes(v),
                    );
                    return (
                      <button
                        key={bin.min}
                        type="button"
                        className={cn(styles.filterChip, isActive && styles.filterChipSelected)}
                        onClick={() => toggleBucket(key, facetValues)}
                      >
                        {binLabel(bin, locale)}
                      </button>
                    );
                  })
                ) : (
                  getSimpleOptions(key, facets, locale).map((option) => {
                    const isActive = (filters[key] as string[]).includes(option.value);
                    return (
                      <button
                        key={option.value}
                        type="button"
                        className={cn(styles.filterChip, isActive && styles.filterChipSelected)}
                        onClick={() => toggleSimple(key, option.value)}
                      >
                        {option.label}
                      </button>
                    );
                  })
                )}
              </div>
            )}
          </div>
        );
      })}

      {hasAny && (
        <button type="button" className={styles.cfpClearAll} onClick={clearAll}>
          {clearAllLabel}
        </button>
      )}
    </div>
  );
}

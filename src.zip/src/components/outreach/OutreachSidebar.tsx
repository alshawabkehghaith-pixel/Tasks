'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { History, PlusCircle } from 'lucide-react';
import type { ReactNode } from 'react';

import styles from './OutreachSidebar.module.css';

interface OutreachSidebarLabels {
  newCampaign: string;
  campaignsLog: string;
  
  navLabel: string;
}

interface OutreachSidebarProps {
  newCampaignHref: string;
  campaignsLogHref: string;
  labels: OutreachSidebarLabels;
  children: ReactNode;
}

const STEPPER_PATHS = [
  '/outreach/targeting',
  '/outreach/verification',
  '/outreach/preparation',
  '/outreach/publishing',
];

export function OutreachSidebar({
  newCampaignHref,
  campaignsLogHref,
  labels,
  children,
}: OutreachSidebarProps): JSX.Element {
  const pathname = usePathname();

  const isStepperActive = STEPPER_PATHS.some((p) => pathname.startsWith(p));
  const isLogActive = pathname.startsWith('/outreach/campaigns');

  return (
    <div className={styles.wrapper}>
      <nav className={styles.sidebar} aria-label={labels.navLabel}>
        <Link
          href={newCampaignHref}
          className={`${styles.item} ${isStepperActive ? styles.active : ''}`}
          aria-current={isStepperActive ? 'page' : undefined}
        >
          <PlusCircle size={16} strokeWidth={2} aria-hidden="true" />
          <span>{labels.newCampaign}</span>
        </Link>

        <Link
          href={campaignsLogHref}
          className={`${styles.item} ${isLogActive ? styles.active : ''}`}
          aria-current={isLogActive ? 'page' : undefined}
        >
          <History size={16} strokeWidth={2} aria-hidden="true" />
          <span>{labels.campaignsLog}</span>
        </Link>
      </nav>

      <div className={styles.content}>{children}</div>
    </div>
  );
}

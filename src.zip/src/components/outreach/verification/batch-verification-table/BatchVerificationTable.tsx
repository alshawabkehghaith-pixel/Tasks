'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { ChevronLeft, ChevronRight, Loader2, Search } from 'lucide-react';
import { toast } from 'sonner';

import type { VerificationCandidateRow } from '@/types/domain';
import { saveOutreachDraft } from '@/lib/outreach/draft-client';
import { cn } from '@/lib/utils';

import styles from './BatchVerificationTable.module.css';

export interface BatchVerificationTableLabels {
  batchTotalTemplate: string;
  searchPlaceholder: string;
  regionAll: string;
  levelAll: string;
  levelLabel: string;
  regionLabel: string;
  apply: string;
  colSeeker: string;
  colRegion: string;
  colCity: string;
  colOccupationalField: string;
  colOctoberBatch: string;
  colFreshGraduate: string;
  colTopMatch: string;
  colJobMatches: string;
  selectAria: string;
  readyForPrep: string;
  totalJobMatchesTemplate: string;
  backToTargeting: string;
  pageTemplate: string;
  prev: string;
  next: string;
  noResults: string;
  verifyHere: string;
  yes: string;
  no: string;
}

interface BatchVerificationTableProps {
  batchTotal: number;
  rows: VerificationCandidateRow[];
  page: number;
  totalPages: number;
  filters: { search: string; region: string; level: string };
  initialSelected: string[];
  initialJobsel: Record<string, string>;
  initialMatchMap: Record<string, number>;
  backToTargetingHref: string;
  labels: BatchVerificationTableLabels;
}

function applyTemplate(template: string, key: string, value: string | number): string {
  return template.replace(`{${key}}`, String(value));
}

function formatBoolean(value: boolean, labels: Pick<BatchVerificationTableLabels, 'yes' | 'no'>): string {
  return value ? labels.yes : labels.no;
}

function toJobselRecord(map: Map<string, string>): Record<string, string> {
  return Object.fromEntries(map.entries());
}

function toMatchRecord(map: Map<string, number>): Record<string, number> {
  return Object.fromEntries(map.entries());
}

export function BatchVerificationTable({
  batchTotal,
  rows,
  page,
  totalPages,
  filters,
  initialSelected,
  initialJobsel,
  initialMatchMap,
  backToTargetingHref,
  labels,
}: BatchVerificationTableProps): JSX.Element {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [queryState, setQueryState] = useState(() => searchParams.toString());
  const [saving, setSaving] = useState(false);
  const draftTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const current = searchParams.toString();
    if (current !== queryState) {
      setQueryState(current);
    }
  }, [searchParams, queryState]);

  function buildQuery(overrides: Record<string, string | null>): string {
    const params = new URLSearchParams(queryState);
    // Selection lives in the outreach draft cookie — keep only UI filters here.
    params.delete('sel');
    params.delete('jobsel');
    params.delete('matchmap');
    params.delete('mode');
    params.delete('nins');
    params.delete('batchType');
    params.delete('regions');
    params.delete('cities');
    params.delete('genders');
    params.delete('ages');
    params.delete('qualifications');
    params.delete('occupationalFields');
    params.delete('yearsExperience');
    params.delete('statuses');
    params.delete('readiness');
    params.delete('levels');

    for (const [key, value] of Object.entries(overrides)) {
      if (value === null || value === '') {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    }

    return params.toString();
  }

  function navigate(nextQuery: string, method: 'push' | 'replace'): void {
    setQueryState(nextQuery);
    const href = nextQuery ? `${pathname}?${nextQuery}` : pathname;
    router[method](href, { scroll: false });
  }

  const [jobselMap, setJobselMap] = useState<Map<string, string>>(
    () => new Map(Object.entries(initialJobsel)),
  );

  const [selected, setSelected] = useState<Set<string>>(() => {
    const selSet = new Set<string>(initialSelected.filter(Boolean));
    for (const [nin, value] of Object.entries(initialJobsel)) {
      if (value === '') selSet.delete(nin);
      else selSet.add(nin);
    }
    return selSet;
  });

  const [matchMap, setMatchMap] = useState<Map<string, number>>(() => {
    const map = new Map<string, number>(Object.entries(initialMatchMap));
    for (const [nin, value] of Object.entries(initialJobsel)) {
      if (value === '*') {
        if (!map.has(nin)) {
          const row = rows.find((r) => r.nin === nin);
          if (row) map.set(nin, row.matchCount);
        }
      } else if (value === '') {
        map.delete(nin);
      } else {
        map.set(nin, value.split('+').filter(Boolean).length);
      }
    }
    return map;
  });

  const [searchInput, setSearchInput] = useState(filters.search);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  function buildHref(overrides: Record<string, string | null>): string {
    const qs = buildQuery(overrides);
    return qs ? `${pathname}?${qs}` : pathname;
  }

  function persistSelection(
    nextSel: Set<string>,
    nextMap: Map<string, number>,
    nextJobsel: Map<string, string>,
  ): void {
    if (draftTimer.current) clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => {
      void saveOutreachDraft({
        sel: Array.from(nextSel),
        matchmap: toMatchRecord(nextMap),
        jobsel: toJobselRecord(nextJobsel),
      }).catch((error) => {
        toast.error(error instanceof Error ? error.message : 'Failed to save selection');
      });
    }, 200);
  }

  function toggleSelect(nin: string, matchCount: number): void {
    const nextSel = new Set(selected);
    const nextMap = new Map(matchMap);
    const nextJobsel = new Map(jobselMap);

    if (nextSel.has(nin)) {
      nextSel.delete(nin);
      nextMap.delete(nin);
      nextJobsel.delete(nin);
    } else {
      nextSel.add(nin);
      nextMap.set(nin, matchCount);
      nextJobsel.set(nin, '*');
    }

    setSelected(nextSel);
    setMatchMap(nextMap);
    setJobselMap(nextJobsel);
    persistSelection(nextSel, nextMap, nextJobsel);
  }

  function applyFilters(overrides?: { search?: string }): void {
    const search = overrides?.search ?? searchInput;
    navigate(buildQuery({ q: search || null, region: null, level: null, page: null }), 'push');
  }

  useEffect(() => {
    if (searchInput === filters.search) {
      return;
    }
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
    debounceRef.current = setTimeout(() => applyFilters({ search: searchInput }), 300);
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [searchInput]);

  const selectedCount = selected.size;

  const totalJobMatches = Array.from(selected).reduce((sum, nin) => {
    const entry = jobselMap.get(nin);
    if (entry === undefined) return sum + (matchMap.get(nin) ?? 0);
    if (entry === '') return sum;
    if (entry === '*') return sum + (matchMap.get(nin) ?? 0);
    return sum + entry.split('+').filter(Boolean).length;
  }, 0);

  const allOnPageSelected = rows.length > 0 && rows.every((row) => selected.has(row.nin));
  const someOnPageSelected = rows.some((row) => selected.has(row.nin)) && !allOnPageSelected;

  function toggleSelectAll(): void {
    const nextSel = new Set(selected);
    const nextMap = new Map(matchMap);
    const nextJobsel = new Map(jobselMap);

    if (allOnPageSelected) {
      rows.forEach((row) => {
        nextSel.delete(row.nin);
        nextMap.delete(row.nin);
        nextJobsel.delete(row.nin);
      });
    } else {
      rows.forEach((row) => {
        nextSel.add(row.nin);
        nextMap.set(row.nin, row.matchCount);
        nextJobsel.set(row.nin, '*');
      });
    }

    setSelected(nextSel);
    setMatchMap(nextMap);
    setJobselMap(nextJobsel);
    persistSelection(nextSel, nextMap, nextJobsel);
  }

  async function continueToPrep(): Promise<void> {
    if (selectedCount === 0 || saving) return;
    setSaving(true);
    try {
      if (draftTimer.current) clearTimeout(draftTimer.current);
      await saveOutreachDraft({
        sel: Array.from(selected),
        matchmap: toMatchRecord(matchMap),
        jobsel: toJobselRecord(jobselMap),
      });
      router.push('/outreach/preparation');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to continue');
      setSaving(false);
    }
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      <section className={styles.card}>
        <span className={styles.cardGlow} aria-hidden="true" />

        <div className={styles.headerStat}>
          <span className={styles.headerStatValue}>{batchTotal}</span>
          <span className={styles.headerStatLabel}>
            {applyTemplate(labels.batchTotalTemplate, 'n', '').trim()}
          </span>
        </div>

        <div className={styles.filterRow}>
          <div className={styles.searchField}>
            <Search size={15} strokeWidth={2} className={styles.searchIcon} aria-hidden="true" />
            <input
              type="search"
              className={styles.searchInput}
              placeholder={labels.searchPlaceholder}
              aria-label={labels.searchPlaceholder}
              value={searchInput}
              onChange={(event) => setSearchInput(event.target.value)}
            />
          </div>
        </div>

        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th className={styles.thCheck}>
                  <input
                    type="checkbox"
                    className={styles.checkbox}
                    checked={allOnPageSelected}
                    ref={(el) => { if (el) el.indeterminate = someOnPageSelected; }}
                    aria-label={labels.selectAria}
                    onChange={toggleSelectAll}
                  />
                </th>
                <th>{labels.colSeeker}</th>
                <th>{labels.colRegion}</th>
                <th>{labels.colCity}</th>
                <th>{labels.colOccupationalField}</th>
                <th>{labels.colOctoberBatch}</th>
                <th>{labels.colFreshGraduate}</th>
                <th className={styles.thMatch}>{labels.colTopMatch}</th>
                <th className={styles.thNum}>{labels.colJobMatches}</th>
                <th className={styles.thChevron} aria-hidden="true" />
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td colSpan={10} className={styles.emptyCell}>
                    {labels.noResults}
                  </td>
                </tr>
              )}
              {rows.map((row) => (
                <tr key={row.nin} className={styles.row} onClick={() => router.push(buildHref({ drill: row.nin }))}>
                  <td className={styles.tdCheck}>
                    <input
                      type="checkbox"
                      className={styles.checkbox}
                      checked={selected.has(row.nin)}
                      aria-label={`${labels.selectAria}: ${row.name}`}
                      onClick={(event) => event.stopPropagation()}
                      onChange={() => toggleSelect(row.nin, row.matchCount)}
                    />
                  </td>
                  <td>
                    <div className={styles.seekerName}>{row.name}</div>
                    <div className={styles.seekerNin}>{row.nin}</div>
                  </td>
                  <td>{row.region}</td>
                  <td>{row.city}</td>
                  <td>{row.occupationalField}</td>
                  <td>{formatBoolean(row.octoberBatch, labels)}</td>
                  <td>{formatBoolean(row.freshGraduate, labels)}</td>
                  <td>
                    <div className={styles.matchCell}>
                      <span className={styles.matchBar} aria-hidden="true">
                        <span
                          className={styles.matchBarFill}
                          style={{ inlineSize: `${row.topMatchScore}%` }}
                        />
                      </span>
                      <span className={styles.matchPct}>{row.topMatchScore}%</span>
                    </div>
                  </td>
                  <td className={styles.tdNum}>{row.matchCount}</td>
                  <td className={styles.tdChevron}>
                    <span className={styles.verifyHint}>
                      <span>{labels.verifyHere}</span>
                      <ChevronRight size={16} strokeWidth={2} className={styles.rowChevron} aria-hidden="true" />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className={styles.pagination}>
          {page > 1 ? (
            <Link
              href={buildHref({ page: String(page - 1) })}
              className={styles.pageBtn}
              aria-label={labels.prev}
            >
              <ChevronLeft size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
            </Link>
          ) : (
            <span className={cn(styles.pageBtn, styles.pageBtnDisabled)} aria-hidden="true">
              <ChevronLeft size={16} strokeWidth={2} className={styles.pageIcon} />
            </span>
          )}
          <span className={styles.pageInfo}>
            {applyTemplate(applyTemplate(labels.pageTemplate, 'p', page), 't', totalPages)}
          </span>
          {page < totalPages ? (
            <Link
              href={buildHref({ page: String(page + 1) })}
              className={styles.pageBtn}
              aria-label={labels.next}
            >
              <ChevronRight size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
            </Link>
          ) : (
            <span className={cn(styles.pageBtn, styles.pageBtnDisabled)} aria-hidden="true">
              <ChevronRight size={16} strokeWidth={2} className={styles.pageIcon} />
            </span>
          )}
        </div>

        <div className={styles.footer}>
          <Link href={backToTargetingHref} className={styles.backLink}>
            <ChevronLeft size={15} strokeWidth={2.25} className={styles.backIcon} aria-hidden="true" />
            {labels.backToTargeting}
          </Link>

          <div className={styles.footerRight}>
            <span className={styles.selectedCount}>{applyTemplate(labels.totalJobMatchesTemplate, 'n', totalJobMatches)}</span>
            {selectedCount > 0 ? (
              <button type="button" className={styles.readyButton} onClick={() => void continueToPrep()} disabled={saving}>
                {saving ? <Loader2 size={16} strokeWidth={2} aria-hidden="true" /> : null}
                {labels.readyForPrep}
              </button>
            ) : (
              <button type="button" className={styles.readyButton} disabled>
                {labels.readyForPrep}
              </button>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

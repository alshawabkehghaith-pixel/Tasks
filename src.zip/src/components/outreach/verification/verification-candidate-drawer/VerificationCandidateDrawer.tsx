'use client';

import { useEffect, useRef, useState } from 'react';
import { AlertTriangle } from 'lucide-react';

import { Sheet, SheetClose, SheetContent, SheetFooter, SheetHeader } from '@/components/ui/Sheet';
import type { SuggestedJob } from '@/types/domain';
import { cn } from '@/lib/utils';

import styles from './VerificationCandidateDrawer.module.css';

const CLAMP_THRESHOLD = 90;

export interface VerificationCandidateBrief {
  name: string;
  nin: string;
  region: string;
  city: string;
  gender: string;
  age: number;
  occupationalField: string;
  qualification: string;
  yearsExperience: number;
  jobLevelLabel: string;
  octoberBatch: boolean;
  freshGraduate: boolean;
  status: string;
  strengths: string[];
  readinessLabel: string;
  matchCount: number;
}

export interface VerificationCandidateDrawerLabels {
  briefTitle: string;
  suggestedTitle: string;
  whySuggested: string;
  more: string;
  less: string;
  cancel: string;
  confirm: string;
  closeLabel: string;
  loadError: string;
  errorTitle: string;
  errorDesc: string;
  retry: string;
  ninLabel: string;
  locationLabel: string;
  cityLabel: string;
  readinessTitle: string;
  briefMatchesTemplate: string;
  genderLabel: string;
  ageLabel: string;
  occupationalFieldLabel: string;
  qualificationLabel: string;
  yearsExpLabel: string;
  jobLevelLabel: string;
  octoberBatchLabel: string;
  freshGraduateLabel: string;
  statusLabel: string;
  strengthsLabel: string;
  yesLabel: string;
  noLabel: string;
}

export interface VerificationConfirmPayload {
  nin: string;
  selectedJobIds: string[];
  matchCount: number;
}

interface VerificationCandidateDrawerProps {
  nin: string | null;
  locale: 'ar' | 'en';
  initialSelectedJobs: string[];
  labels: VerificationCandidateDrawerLabels;
  onClose: () => void;
  onConfirm: (payload: VerificationConfirmPayload) => void;
}

function applyTemplate(template: string, key: string, value: string | number): string {
  return template.replace(`{${key}}`, String(value));
}

export function VerificationCandidateDrawer({
  nin,
  locale,
  initialSelectedJobs,
  labels,
  onClose,
  onConfirm,
}: VerificationCandidateDrawerProps): JSX.Element {
  const open = Boolean(nin);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [candidate, setCandidate] = useState<VerificationCandidateBrief | null>(null);
  const [jobs, setJobs] = useState<SuggestedJob[]>([]);
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [loadKey, setLoadKey] = useState(0);
  const initialJobsRef = useRef(initialSelectedJobs);

  useEffect(() => {
    if (nin) {
      initialJobsRef.current = initialSelectedJobs;
    }
  }, [nin, initialSelectedJobs]);

  useEffect(() => {
    if (!nin) {
      setCandidate(null);
      setJobs([]);
      setSelectedJobs(new Set());
      setExpanded(new Set());
      setError(null);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    setCandidate(null);
    setJobs([]);
    setExpanded(new Set());

    void fetch(`/api/outreach/verification/candidate?nin=${encodeURIComponent(nin)}&lang=${locale}`)
      .then(async (response) => {
        if (!response.ok) {
          throw new Error(labels.loadError);
        }
        return response.json() as Promise<{ candidate: VerificationCandidateBrief; jobs: SuggestedJob[] }>;
      })
      .then((data) => {
        if (cancelled) return;
        setCandidate(data.candidate);
        setJobs(data.jobs);
        const initial = initialJobsRef.current;
        if (initial.includes('*')) {
          setSelectedJobs(new Set(data.jobs.map((job) => job.id)));
        } else {
          setSelectedJobs(new Set(initial.filter(Boolean)));
        }
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : labels.loadError);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [nin, locale, loadKey, labels.loadError]);

  function toggleJob(id: string): void {
    setSelectedJobs((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleExpand(id: string): void {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function handleCancel(): void {
    onClose();
  }

  function handleConfirm(): void {
    if (!nin || !candidate) return;
    const ids = Array.from(selectedJobs);
    onConfirm({
      nin,
      selectedJobIds: ids,
      matchCount: ids.length,
    });
  }

  const sheetSide = locale === 'ar' ? 'left' : 'right';

  return (
    <Sheet open={open} onOpenChange={(next) => { if (!next) onClose(); }}>
      <SheetContent
        className={cn(styles.sheet, sheetSide === 'left' ? styles.sheetFromLeft : styles.sheetFromRight)}
        closeLabel={labels.closeLabel}
        side={sheetSide}
      >
        <div className={styles.root} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
          <SheetHeader className={styles.headerBar}>
            <div className={styles.header}>
              <h2 className={styles.title}>
                {loading ? <span className={styles.skelTitle} aria-hidden="true" /> : (candidate?.name ?? labels.briefTitle)}
              </h2>
              {loading ? (
                <span className={styles.skelLine} aria-hidden="true" />
              ) : candidate ? (
                <p className={styles.subtitle}>{candidate.nin}</p>
              ) : error ? (
                <p className={styles.subtitle}>{labels.errorTitle}</p>
              ) : null}
            </div>
            <SheetClose label={labels.closeLabel} className={styles.closeBtn} />
          </SheetHeader>

          {loading ? (
            <div className={styles.sections} role="status" aria-busy="true" aria-label={labels.briefTitle}>
              <section className={styles.section}>
                <div className={styles.sectionTitle}>
                  <span className={styles.skelLineSm} />
                </div>
                <div className={styles.sectionBody}>
                  {Array.from({ length: 7 }).map((_, index) => (
                    <div key={`brief-skel-${index}`} className={styles.skelRow}>
                      <span className={styles.skelLineSm} />
                      <span className={styles.skelLine} />
                    </div>
                  ))}
                </div>
              </section>
              <section className={styles.section}>
                <div className={styles.sectionTitle}>
                  <span className={styles.skelLineSm} />
                </div>
                <div className={styles.sectionBody}>
                  {Array.from({ length: 3 }).map((_, index) => (
                    <div key={`job-skel-${index}`} className={styles.skelCard}>
                      <span className={styles.skelLine} />
                      <span className={styles.skelLineSm} />
                      <span className={styles.skelBlock} />
                    </div>
                  ))}
                </div>
              </section>
            </div>
          ) : null}

          {error && !loading ? (
            <div className={styles.errorPage} role="alert">
              <div className={styles.errorIconWrap} aria-hidden="true">
                <AlertTriangle size={28} strokeWidth={1.75} />
              </div>
              <h3 className={styles.errorTitle}>{labels.errorTitle}</h3>
              <p className={styles.errorText}>{labels.errorDesc || error}</p>
              <div className={styles.errorActions}>
                <button type="button" className={styles.retryBtn} onClick={() => setLoadKey((value) => value + 1)}>
                  {labels.retry}
                </button>
                <button type="button" className={styles.cancelBtn} onClick={handleCancel}>
                  {labels.cancel}
                </button>
              </div>
            </div>
          ) : null}

          {!loading && !error && candidate ? (
            <div className={styles.sections}>
              <section className={styles.section} aria-label={labels.briefTitle}>
                <h3 className={styles.sectionTitle}>{labels.briefTitle}</h3>
                <div className={styles.sectionBody}>
                  <dl className={styles.briefRows}>
                    <div className={styles.briefRow}>
                      <dt>{labels.readinessTitle}</dt>
                      <dd>{candidate.readinessLabel}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.genderLabel}</dt>
                      <dd>{candidate.gender}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.ageLabel}</dt>
                      <dd>{candidate.age}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.locationLabel}</dt>
                      <dd>{candidate.region}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.cityLabel}</dt>
                      <dd>{candidate.city}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.occupationalFieldLabel}</dt>
                      <dd>{candidate.occupationalField}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.qualificationLabel}</dt>
                      <dd>{candidate.qualification}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.yearsExpLabel}</dt>
                      <dd>{candidate.yearsExperience}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.jobLevelLabel}</dt>
                      <dd>{candidate.jobLevelLabel}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.octoberBatchLabel}</dt>
                      <dd>{candidate.octoberBatch ? labels.yesLabel : labels.noLabel}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.freshGraduateLabel}</dt>
                      <dd>{candidate.freshGraduate ? labels.yesLabel : labels.noLabel}</dd>
                    </div>
                    <div className={styles.briefRow}>
                      <dt>{labels.statusLabel}</dt>
                      <dd>{candidate.status}</dd>
                    </div>
                    {candidate.strengths.length > 0 ? (
                      <div className={styles.briefRow}>
                        <dt>{labels.strengthsLabel}</dt>
                        <dd>
                          <ul className={styles.strengthList}>
                            {candidate.strengths.map((strength) => (
                              <li key={strength}>{strength}</li>
                            ))}
                          </ul>
                        </dd>
                      </div>
                    ) : null}
                    <div className={styles.briefRow}>
                      <dt>{labels.suggestedTitle}</dt>
                      <dd>{applyTemplate(labels.briefMatchesTemplate, 'n', candidate.matchCount)}</dd>
                    </div>
                  </dl>
                </div>
              </section>

              <section className={styles.section} aria-label={labels.suggestedTitle}>
                <h3 className={styles.sectionTitle}>{labels.suggestedTitle}</h3>
                <div className={styles.sectionBody}>
                  <ul className={styles.jobList}>
                    {jobs.map((job) => {
                      const needsClamp = job.explanation.length > CLAMP_THRESHOLD;
                      const isExpanded = expanded.has(job.id);
                      return (
                        <li key={job.id} className={styles.jobItem}>
                          <label className={styles.jobHead}>
                            <input
                              type="checkbox"
                              className={styles.checkbox}
                              checked={selectedJobs.has(job.id)}
                              onChange={() => toggleJob(job.id)}
                            />
                            <span className={styles.jobHeadMain}>
                              <span className={styles.jobTitle}>{job.jobTitle}</span>
                              <span className={styles.jobMeta}>
                                {job.employer} · {job.location}
                              </span>
                            </span>
                            <span className={styles.jobPct}>{job.matchPct}%</span>
                          </label>
                          <div className={styles.whyBlock}>
                            <span className={styles.whyLabel}>{labels.whySuggested}</span>
                            <span className={cn(styles.whyText, needsClamp && !isExpanded && styles.whyClamped)}>
                              {job.explanation}
                            </span>
                            {needsClamp ? (
                              <button type="button" className={styles.whyToggle} onClick={() => toggleExpand(job.id)}>
                                {isExpanded ? labels.less : labels.more}
                              </button>
                            ) : null}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </section>
            </div>
          ) : null}

          {!error ? (
            <SheetFooter className={styles.footer}>
              <button type="button" className={styles.cancelBtn} onClick={handleCancel}>
                {labels.cancel}
              </button>
              <button
                type="button"
                className={styles.confirmBtn}
                onClick={handleConfirm}
                disabled={loading || !candidate}
              >
                {labels.confirm}
              </button>
            </SheetFooter>
          ) : null}
        </div>
      </SheetContent>
    </Sheet>
  );
}

'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { ChevronLeft, ChevronRight } from 'lucide-react';

import type { SuggestedJob } from '@/types/domain';
import { saveOutreachDraft } from '@/lib/outreach/draft-client';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

import styles from './SingleCandidateVerification.module.css';

const CLAMP_THRESHOLD = 90;

export interface SingleCandidateVerificationLabels {
  briefTitle: string;
  ninLabel: string;
  locationLabel: string;
  cityLabel: string;
  readinessTitle: string;
  briefMatchesTemplate: string;
  suggestedTitle: string;
  whySuggested: string;
  more: string;
  less: string;
  backToTargeting: string;
  prev: string;
  next: string;
  pageTemplate: string;
  genderLabel: string;
  ageLabel: string;
  occupationalFieldLabel: string;
  qualificationLabel: string;
  yearsExpLabel: string;
  jobLevelLabel: string;
  octoberBatchLabel: string;
  freshGraduateLabel: string;
  statusLabel: string;
  strengthsLabel: string;
  yesLabel: string;
  noLabel: string;
  breadcrumbLabel: string;
}

type Breadcrumb =
  | { kind: 'drill'; batchName: string; batchHref: string; candidateName: string }
  | { kind: 'direct'; backHref: string };

interface CandidateBrief {
  name: string;
  nin: string;
  region: string;
  city: string;
  gender: string;
  age: number;
  occupationalField: string;
  qualification: string;
  yearsExperience: number;
  jobLevelLabel: string;
  octoberBatch: boolean;
  freshGraduate: boolean;
  status: string;
  strengths: string[];
  readinessLabel: string;
  matchCount: number;
}

interface SingleCandidateVerificationProps {
  candidate: CandidateBrief;
  jobs: SuggestedJob[];
  jobsPage: number;
  jobsTotalPages: number;
  initialSelectedJobs: string[];
  initialSel: string[];
  initialMatchMap: Record<string, number>;
  initialJobsel: Record<string, string>;
  breadcrumb: Breadcrumb;
  labels: SingleCandidateVerificationLabels;
}

function applyTemplate(template: string, key: string, value: string | number): string {
  return template.replace(`{${key}}`, String(value));
}

export function SingleCandidateVerification({
  candidate,
  jobs,
  jobsPage,
  jobsTotalPages,
  initialSelectedJobs,
  initialSel,
  initialMatchMap,
  initialJobsel,
  breadcrumb,
  labels,
}: SingleCandidateVerificationProps): JSX.Element {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [queryState, setQueryState] = useState(() => searchParams.toString());
  const [sel, setSel] = useState(() => new Set(initialSel));
  const [matchMap, setMatchMap] = useState(() => new Map(Object.entries(initialMatchMap)));
  const [jobsel, setJobsel] = useState(() => ({ ...initialJobsel }));

  useEffect(() => {
    const current = searchParams.toString();
    if (current && current !== queryState) {
      setQueryState(current);
    }
  }, [searchParams, queryState]);

  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(() => {

    if (initialSelectedJobs.includes('*')) {
      return new Set(jobs.map((job) => job.id));
    }
    return new Set(initialSelectedJobs);
  });
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  function buildHref(overrides: Record<string, string | null>): string {
    const params = new URLSearchParams(queryState);
    for (const key of ['sel', 'jobsel', 'matchmap', 'mode', 'nins', 'batchType', 'regions', 'cities', 'genders', 'ages', 'qualifications', 'occupationalFields', 'yearsExperience', 'statuses', 'readiness', 'levels']) {
      params.delete(key);
    }
    for (const [key, value] of Object.entries(overrides)) {
      if (value === null || value === '') {
        params.delete(key);
      } else {
        params.set(key, value);
      }
    }
    const qs = params.toString();
    return qs ? `${pathname}?${qs}` : pathname;
  }

  function toggleJob(id: string): void {
    const next = new Set(selectedJobs);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }

    const nextSel = new Set(sel);
    const nextMatch = new Map(matchMap);
    const nextJobsel = { ...jobsel };

    if (next.size > 0) {
      nextSel.add(candidate.nin);
      nextMatch.set(candidate.nin, next.size);
      nextJobsel[candidate.nin] = Array.from(next).join('+');
    } else {
      nextSel.delete(candidate.nin);
      nextMatch.delete(candidate.nin);
      delete nextJobsel[candidate.nin];
    }

    setSelectedJobs(next);
    setSel(nextSel);
    setMatchMap(nextMatch);
    setJobsel(nextJobsel);

    void saveOutreachDraft({
      sel: Array.from(nextSel),
      matchmap: Object.fromEntries(nextMatch.entries()),
      jobsel: nextJobsel,
    }).catch((error) => {
      toast.error(error instanceof Error ? error.message : 'Failed to save selection');
    });
  }

  function toggleExpand(id: string): void {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.ambient} aria-hidden="true">
        <span className={styles.blob} />
      </div>

      {}
      <nav className={styles.breadcrumb} aria-label={labels.breadcrumbLabel}>
        {breadcrumb.kind === 'drill' ? (
          <>
            <Link href={breadcrumb.batchHref} className={styles.crumbLink}>
              {breadcrumb.batchName}
            </Link>
            <ChevronRight size={14} strokeWidth={2} className={styles.crumbSep} aria-hidden="true" />
            <span className={styles.crumbCurrent}>{breadcrumb.candidateName}</span>
          </>
        ) : (
          <Link href={breadcrumb.backHref} className={styles.crumbLink}>
            <ChevronLeft size={14} strokeWidth={2.25} className={styles.crumbBackIcon} aria-hidden="true" />
            {labels.backToTargeting}
          </Link>
        )}
      </nav>

      <div className={styles.layout}>
        {}
        <section className={cn(styles.card, styles.briefCard)}>
          <span className={styles.cardGlow} aria-hidden="true" />
          <h2 className={styles.cardTitle}>{labels.briefTitle}</h2>

          <div className={styles.briefName}>{candidate.name}</div>
          <div className={styles.briefNin}>{candidate.nin}</div>

          <dl className={styles.briefRows}>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.readinessTitle}</dt>
              <dd className={styles.briefValue}>{candidate.readinessLabel}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.genderLabel}</dt>
              <dd className={styles.briefValue}>{candidate.gender}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.ageLabel}</dt>
              <dd className={styles.briefValue}>{candidate.age}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.locationLabel}</dt>
              <dd className={styles.briefValue}>{candidate.region}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.cityLabel}</dt>
              <dd className={styles.briefValue}>{candidate.city}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.occupationalFieldLabel}</dt>
              <dd className={styles.briefValue}>{candidate.occupationalField}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.qualificationLabel}</dt>
              <dd className={styles.briefValue}>{candidate.qualification}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.yearsExpLabel}</dt>
              <dd className={styles.briefValue}>{candidate.yearsExperience}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.jobLevelLabel}</dt>
              <dd className={styles.briefValue}>{candidate.jobLevelLabel}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.octoberBatchLabel}</dt>
              <dd className={styles.briefValue}>{candidate.octoberBatch ? labels.yesLabel : labels.noLabel}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.freshGraduateLabel}</dt>
              <dd className={styles.briefValue}>{candidate.freshGraduate ? labels.yesLabel : labels.noLabel}</dd>
            </div>
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.statusLabel}</dt>
              <dd className={styles.briefValue}>{candidate.status}</dd>
            </div>
            {candidate.strengths.length > 0 && (
              <div className={cn(styles.briefRow, styles.briefRowStrengths)}>
                <dt className={styles.briefLabel}>{labels.strengthsLabel}</dt>
                <dd className={cn(styles.briefValue, styles.briefValueStrengths)}>
                  <ul className={styles.strengthList}>
                    {candidate.strengths.map((strength) => (
                      <li key={strength} className={styles.strengthItem}>
                        {strength}
                      </li>
                    ))}
                  </ul>
                </dd>
              </div>
            )}
            <div className={styles.briefRow}>
              <dt className={styles.briefLabel}>{labels.suggestedTitle}</dt>
              <dd className={styles.briefValue}>{applyTemplate(labels.briefMatchesTemplate, 'n', candidate.matchCount)}</dd>
            </div>
          </dl>
        </section>

        {}
        <section className={cn(styles.card, styles.jobsCard)}>
          <span className={cn(styles.cardGlow, styles.cardGlowTeal)} aria-hidden="true" />
          <h2 className={styles.cardTitle}>{labels.suggestedTitle}</h2>

          <ul className={styles.jobList}>
            {jobs.map((job) => {
              const explanation = job.explanation;
              const needsClamp = explanation.length > CLAMP_THRESHOLD;
              const isExpanded = expanded.has(job.id);
              return (
                <li key={job.id} className={styles.jobItem}>
                  <label className={styles.jobHead}>
                    <input
                      type="checkbox"
                      className={styles.checkbox}
                      checked={selectedJobs.has(job.id)}
                      onChange={() => toggleJob(job.id)}
                    />
                    <span className={styles.jobHeadMain}>
                      <span className={styles.jobTitle}>{job.jobTitle}</span>
                      <span className={styles.jobMeta}>
                        {job.employer} · {job.location}
                      </span>
                    </span>
                    <span className={styles.jobPct}>
                      {job.matchPct}%
                    </span>
                  </label>

                  <div className={styles.whyBlock}>
                    <span className={styles.whyLabel}>{labels.whySuggested}</span>
                    <span className={cn(styles.whyText, needsClamp && !isExpanded && styles.whyClamped)}>
                      {explanation}
                    </span>
                    {needsClamp && (
                      <button type="button" className={styles.whyToggle} onClick={() => toggleExpand(job.id)}>
                        {isExpanded ? labels.less : labels.more}
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>

          {jobsTotalPages > 1 && (
            <div className={styles.pagination}>
              {jobsPage <= 1 ? (
                <span
                  className={cn(styles.pageBtn, styles.pageBtnDisabled)}
                  aria-disabled="true"
                  aria-label={labels.prev}
                >
                  <ChevronLeft size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
                </span>
              ) : (
                <Link
                  href={buildHref({ jobsPage: String(jobsPage - 1) })}
                  className={styles.pageBtn}
                  aria-label={labels.prev}
                >
                  <ChevronLeft size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
                </Link>
              )}
              <span className={styles.pageInfo}>
                {applyTemplate(applyTemplate(labels.pageTemplate, 'p', jobsPage), 't', jobsTotalPages)}
              </span>
              {jobsPage >= jobsTotalPages ? (
                <span
                  className={cn(styles.pageBtn, styles.pageBtnDisabled)}
                  aria-disabled="true"
                  aria-label={labels.next}
                >
                  <ChevronRight size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
                </span>
              ) : (
                <Link
                  href={buildHref({ jobsPage: String(jobsPage + 1) })}
                  className={styles.pageBtn}
                  aria-label={labels.next}
                >
                  <ChevronRight size={16} strokeWidth={2} className={styles.pageIcon} aria-hidden="true" />
                </Link>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

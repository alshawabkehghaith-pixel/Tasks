import { HtmlAttrsSetter } from '@/components/i18n/HtmlAttrsSetter';
import { getAppSession } from '@/lib/server/auth';
import { buildHref } from '@/lib/routing';
import { redirect } from 'next/navigation';
import type { Locale, ThemeMode } from '@/types/jadarat';
import type { QueryInput } from '@/lib/routing';

import styles from './AppShellTemplate.module.css';

export interface AppShellTemplateProps {
  locale: Locale;
  theme: ThemeMode;
  pathname: string;
  query: QueryInput;
  title: string;
  children: React.ReactNode;
}

export async function AppShellTemplate({
  locale,
  theme,
  pathname,
  query,
  title,
  children,
}: AppShellTemplateProps): Promise<JSX.Element> {
  const session = await getAppSession();
  if (!session) {
    const login = new URLSearchParams();
    login.set('next', buildHref(pathname, query, {}));
    redirect(`/login?${login.toString()}`);
  }
  const currentYear = new Date().getFullYear();

  return (
    <>
      <HtmlAttrsSetter locale={locale} theme={theme} />

      <div className={styles.app}>
        <div className={styles.main}>
          <div className={styles.content}>
            <h1 className="sr-only">{title}</h1>
            {children}
          </div>
        </div>

        <footer className={styles.app_footer} role="contentinfo">
          {locale === 'ar'
            ? `جميع الحقوق محفوظة لصندوق تنمية الموارد البشرية © ${currentYear}`
            : `All Rights Reserved Human Resources Development Fund © ${currentYear}`}
        </footer>
      </div>
    </>
  );
}
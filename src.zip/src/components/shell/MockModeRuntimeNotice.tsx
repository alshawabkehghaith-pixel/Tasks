'use client';

import { useEffect } from 'react';

import { IS_PRODUCTION, USE_MOCK } from '@/lib/config/flags';

let mockModeNoticeShown = false;

export function MockModeRuntimeNotice(): null {
  useEffect(() => {
    if (!USE_MOCK || mockModeNoticeShown) {
      return;
    }

    mockModeNoticeShown = true;

    if (IS_PRODUCTION) {
      throw new Error(
        'NEXT_PUBLIC_USE_MOCK=true is not allowed in production builds. Disable mock mode before shipping.',
      );
    }

    console.warn('Demo mode is enabled. The app is serving mock data because NEXT_PUBLIC_USE_MOCK=true.');
  }, []);

  return null;
}

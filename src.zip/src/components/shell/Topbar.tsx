'use client';

import { useEffect, useId, useRef, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ChevronDown, Menu, X } from 'lucide-react';

import { DemoModeBadge } from '@/components/shell/DemoModeBadge';
import { messages } from '@/i18n/catalog';
import { buildHref, type QueryInput } from '@/lib/routing';
import { cn } from '@/lib/utils';
import type { Locale, NavigationGroup, ThemeMode } from '@/types/jadarat';

import styles from './app-shell-template/AppShellTemplate.module.css';

const SUN_SVG = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
    <circle cx="12" cy="12" r="4.5" />
    <path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19" strokeLinecap="round" />
  </svg>
);

const MOON_SVG = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
  </svg>
);

const LANG_SVG = (
  <svg width="14" height="14" viewBox="0 -960 960 960" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="m582.3-164.78-28.95 73.13q-4.13 11.39-14.18 18.59-10.04 7.19-22.43 7.19-21.09 0-32.91-16.67-11.83-16.68-4.7-36.76l154.35-412.18q5.13-14.95 18.02-24.28 12.89-9.33 28.98-9.33h38.04q15.52 0 28.7 9.33 13.17 9.33 18.3 24.28L919.3-120.43q7.7 20.65-4.41 37.6-12.11 16.96-33.76 16.96-12.83 0-23.43-7.48-10.61-7.48-14.74-19.3l-28.39-72.13H582.3ZM352.83-380.09 183-210.7q-12.39 11.4-28.07 11.61-15.67.22-27.5-12.17-12.39-11.83-12.39-27.78 0-15.96 12.39-27.79l170.39-170.39q-54.95-57.52-90.58-112.58-35.63-55.07-51.94-105.11h89.31q12.61 36.21 39.82 75.95 27.22 39.74 70.53 84.61 44.87-48 82.17-114.39 37.3-66.39 52.61-126.17H62.65q-16.95 0-28.28-11.33-11.33-11.33-11.33-28.28 0-16.96 11.33-28.57t28.28-11.61h250.39v-39.82q0-16.96 11.33-28.57t28.28-11.61q16.96 0 28.57 11.61t11.61 28.57v39.82h249.82q16.96 0 28.57 11.61t11.61 28.57q0 16.95-11.61 28.28-11.61 11.33-28.57 11.33h-67.17q-17.57 75.74-62.91 156.95-45.35 81.22-102.61 141.18l81.65 83.08-31.35 85.05-107.43-111.44Zm256.69 140.53h177.83l-88.92-236.7-88.91 236.7Z" fill="currentColor" />
  </svg>
);

export interface TopbarProps {
  pathname: string;
  query: QueryInput;
  locale: Locale;
  theme: ThemeMode;
  brandTitle: string;
  navGroups: NavigationGroup[];
  userName: string;
  userRole: string;
  logoutHref: string;
  onLogoutClick?: () => void;
}

export function Topbar({
  pathname,
  query,
  locale,
  theme,
  brandTitle,
  navGroups,
  userName,
  userRole,
  logoutHref,
  onLogoutClick,
}: TopbarProps): JSX.Element {
  const themeHref = buildHref(pathname, query, { theme: theme === 'dark' ? 'light' : 'dark' });
  const langHref = buildHref(pathname, query, { lang: locale === 'ar' ? 'en' : 'ar' });
  const navItems = navGroups.flatMap((group) => group.items);
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [navStickyVisible, setNavStickyVisible] = useState(false);
  const menuId = useId();
  const userMenuId = useId();
  const userMenuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const updateStickyNav = (): void => {
      const utility = document.querySelector<HTMLElement>('[data-shell-utility]');
      if (!utility) {
        setNavStickyVisible(window.scrollY > 8);
        return;
      }
      setNavStickyVisible(utility.getBoundingClientRect().bottom <= 0);
    };

    updateStickyNav();
    window.addEventListener('scroll', updateStickyNav, { passive: true });
    window.addEventListener('resize', updateStickyNav);
    return () => {
      window.removeEventListener('scroll', updateStickyNav);
      window.removeEventListener('resize', updateStickyNav);
    };
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setUserMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [menuOpen]);

  useEffect(() => {
    if (!menuOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previous;
    };
  }, [menuOpen]);

  useEffect(() => {
    if (!userMenuOpen) return;

    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setUserMenuOpen(false);
    };

    const onPointerDown = (event: MouseEvent): void => {
      if (!userMenuRef.current?.contains(event.target as Node)) {
        setUserMenuOpen(false);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('mousedown', onPointerDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('mousedown', onPointerDown);
    };
  }, [userMenuOpen]);

  const renderNavLinks = (): JSX.Element[] =>
    navItems.map((item) => {
      const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
      return (
        <Link
          key={item.href}
          className={active ? styles.on : undefined}
          href={item.href}
          aria-current={active ? 'page' : undefined}
          onClick={() => setMenuOpen(false)}
        >
          {item.label[locale] ?? item.label.ar}
        </Link>
      );
    });

  const renderMenuToggle = (): JSX.Element => (
    <button
      type="button"
      className={cn(styles.icon_btn, styles.menu_toggle)}
      aria-expanded={menuOpen}
      aria-controls={menuId}
      aria-label={menuOpen ? messages.topbarCloseMenu[locale] : messages.topbarOpenMenu[locale]}
      onClick={() => setMenuOpen((open) => !open)}
    >
      {menuOpen ? <X size={18} strokeWidth={1.75} aria-hidden="true" /> : <Menu size={18} strokeWidth={1.75} aria-hidden="true" />}
    </button>
  );

  return (
    <div className={styles.chrome}>
      <header className={styles.utility_bar} role="banner" data-shell-utility>
        <div className={styles.utility_start}>
          <Link href="/dashboard" className={styles.brand_mark_link} aria-label={brandTitle}>
            <Image
              src="/logo-white.svg"
              alt=""
              width={33}
              height={72}
              className={styles.brand_mark}
              priority
              unoptimized
            />
          </Link>
          <span className={styles.v_rule} aria-hidden="true" />
          <div className={cn(styles.utility_controls, 'ui-scale-target')}>
            <DemoModeBadge locale={locale} className={styles.demo_badge} />

            <Link
              className={styles.icon_btn}
              href={themeHref}
              title={theme === 'dark' ? messages.topbarThemeToLight[locale] : messages.topbarThemeToDark[locale]}
              aria-label={theme === 'dark' ? messages.topbarThemeToLight[locale] : messages.topbarThemeToDark[locale]}
            >
              {theme === 'dark' ? SUN_SVG : MOON_SVG}
            </Link>

            <Link
              className={styles.icon_btn}
              href={langHref}
              title={locale === 'ar' ? 'English' : 'العربية'}
              aria-label={locale === 'ar' ? 'English' : 'العربية'}
            >
              {LANG_SVG}
            </Link>

            <div className={styles.user_menu} ref={userMenuRef}>
              <button
                type="button"
                className={styles.user_chip}
                aria-label={messages.topbarUserMenu[locale]}
                aria-expanded={userMenuOpen}
                aria-controls={userMenuId}
                aria-haspopup="menu"
                onClick={() => setUserMenuOpen((open) => !open)}
              >
                <span className={styles.user_chip_av} aria-hidden="true">
                  {userName.charAt(0).toUpperCase()}
                </span>
                <span className={styles.user_chip_meta}>
                  <span className={styles.user_chip_name}>{userName}</span>
                  <span className={styles.user_chip_role}>{userRole}</span>
                </span>
                <ChevronDown
                  size={16}
                  strokeWidth={1.75}
                  className={cn(styles.user_chip_caret, userMenuOpen && styles.user_chip_caret_open)}
                  aria-hidden="true"
                />
              </button>

              {userMenuOpen ? (
                <div id={userMenuId} className={styles.user_menu_panel} role="menu">
                  <Link
                    role="menuitem"
                    className={styles.user_menu_item}
                    href="/my-workspace"
                    onClick={() => setUserMenuOpen(false)}
                  >
                    {messages.topbarMyActivities[locale]}
                  </Link>
                  <Link
                    role="menuitem"
                    className={styles.user_menu_item}
                    href={logoutHref}
                    prefetch={false}
                    onClick={() => {
                      setUserMenuOpen(false);
                      onLogoutClick?.();
                    }}
                  >
                    {messages.topbarSignOut[locale]}
                  </Link>
                </div>
              ) : null}
            </div>

            {renderMenuToggle()}
          </div>
        </div>

        <nav
          className={cn(styles.page_picker, styles.utility_page_picker, 'ui-scale-target')}
          aria-label={messages.topbarNavLabel[locale]}
        >
          {renderNavLinks()}
        </nav>

        <div className={styles.utility_end}>
          <Image
            src="/jme-transparent.png"
            alt=""
            width={132}
            height={44}
            className={styles.jme_logo}
            priority
            unoptimized
          />
          <span className={styles.v_rule} aria-hidden="true" />
          <Image
            src="/jadarat_transparent.png"
            alt=""
            width={148}
            height={44}
            className={styles.partner_logo}
            priority
            unoptimized
          />
        </div>
      </header>

      <div
        className={cn(styles.nav_bar, navStickyVisible && styles.nav_bar_visible)}
        aria-hidden={!navStickyVisible}
      >
        <div className={styles.nav_bar_start} aria-hidden="true" />

        <nav
          className={cn(styles.page_picker, 'ui-scale-target')}
          aria-label={messages.topbarNavLabel[locale]}
          inert={!navStickyVisible ? true : undefined}
        >
          {renderNavLinks()}
        </nav>

        <div className={styles.nav_bar_end}>
          <Image
            src="/jme_nav_transparent.png"
            alt=""
            width={132}
            height={44}
            className={styles.nav_jme_logo}
            aria-hidden="true"
            priority
            unoptimized
          />
          {renderMenuToggle()}
        </div>
      </div>

      {menuOpen ? (
        <div className={styles.mobile_nav_layer}>
          <button
            type="button"
            className={styles.mobile_nav_backdrop}
            aria-label={messages.topbarCloseMenu[locale]}
            onClick={() => setMenuOpen(false)}
          />
          <nav
            id={menuId}
            className={styles.mobile_nav_panel}
            aria-label={messages.topbarNavLabel[locale]}
          >
            {renderNavLinks()}
          </nav>
        </div>
      ) : null}
    </div>
  );
}

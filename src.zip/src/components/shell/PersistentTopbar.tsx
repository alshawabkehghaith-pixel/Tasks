'use client';

import { useEffect, useMemo, useState } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';

import { Topbar } from '@/components/shell/Topbar';
import { messages } from '@/i18n/catalog';
import { buildLogoutHref } from '@/lib/auth-routes';
import { clearDashboardHeroIntroSeen } from '@/lib/hero-intro-storage';
import type { QueryInput } from '@/lib/routing';
import type { Locale, NavigationGroup, ThemeMode } from '@/types/jadarat';

export interface PersistentTopbarProps {
  initialLocale: Locale;
  initialTheme: ThemeMode;
  userName: string | null;
  userRole: 'admin' | 'user' | null;
}

const NAV_GROUPS: NavigationGroup[] = [
  {
    label: messages.grpWorkspace,
    items: [
      { href: '/dashboard', label: messages.navDashboard, icon: 'dashboard' },
      { href: '/candidates', label: messages.navCandidates, icon: 'candidate' },
      { href: '/employers', label: messages.navEmployers, icon: 'employer' },
    ],
  },
  {
    label: messages.grpEngage,
    items: [
      { href: '/outreach', label: messages.navOutreach, icon: 'queue' },
      { href: '/my-workspace', label: messages.navMyWorkspace, icon: 'workspace' },
    ],
  },
];

function resolveLocale(value: string | null, fallback: Locale): Locale {
  if (value === 'ar' || value === 'en') {
    return value;
  }

  return fallback;
}

function resolveTheme(value: string | null, fallback: ThemeMode): ThemeMode {
  if (value === 'light' || value === 'dark') {
    return value;
  }

  return fallback;
}

function shouldHideTopbar(pathname: string): boolean {
  return pathname === '/login' || pathname.startsWith('/saml');
}

function queryFromSearchParams(searchParams: URLSearchParams): QueryInput {
  const query: QueryInput = {};

  for (const [key, value] of searchParams.entries()) {
    query[key] = value;
  }

  return query;
}

export function PersistentTopbar({
  initialLocale,
  initialTheme,
  userName,
  userRole,
}: PersistentTopbarProps): JSX.Element | null {
  const pathname = usePathname() ?? '/';
  const searchParams = useSearchParams();

  const [locale, setLocale] = useState<Locale>(initialLocale);
  const [theme, setTheme] = useState<ThemeMode>(initialTheme);

  useEffect(() => {
    const syncFromHtml = (): void => {
      const root = document.documentElement;
      setLocale((current) => resolveLocale(root.getAttribute('lang'), current));
      setTheme((current) => resolveTheme(root.getAttribute('data-theme'), current));
    };

    syncFromHtml();

    const observer = new MutationObserver(syncFromHtml);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['lang', 'data-theme'],
    });

    return () => observer.disconnect();
  }, []);

  const query = useMemo(() => queryFromSearchParams(searchParams), [searchParams]);

  if (!userName || !userRole || shouldHideTopbar(pathname)) {
    return null;
  }

  const roleLabel = userRole === 'admin' ? messages.roleAdmin : messages.roleReviewer;

  return (
    <Topbar
      pathname={pathname}
      query={query}
      locale={locale}
      theme={theme}
      brandTitle={messages.appName[locale] ?? messages.appName.ar}
      navGroups={NAV_GROUPS}
      userName={userName}
      userRole={roleLabel[locale] ?? roleLabel.ar}
      logoutHref={buildLogoutHref(locale, query)}
      onLogoutClick={clearDashboardHeroIntroSeen}
    />
  );
}

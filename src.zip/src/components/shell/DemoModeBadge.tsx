import { USE_MOCK } from '@/lib/config/flags';
import { cn } from '@/lib/utils';
import type { Locale } from '@/types/jadarat';

interface DemoModeBadgeProps {
  locale: Locale;
  className?: string;
}

export function DemoModeBadge({ locale, className }: DemoModeBadgeProps): JSX.Element | null {
  if (!USE_MOCK) {
    return null;
  }

  const label = locale === 'ar' ? 'وضع تجريبي' : 'Demo Mode';
  const description = locale === 'ar' ? 'التطبيق يعرض بيانات تجريبية حالياً' : 'The app is currently using mock data';

  return (
    <span className={cn(className)} role="status" aria-label={description}>
      {label}
    </span>
  );
}

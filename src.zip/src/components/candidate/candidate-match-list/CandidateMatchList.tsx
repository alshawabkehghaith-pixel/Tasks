'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Check } from 'lucide-react';
import { toast } from 'sonner';

import { cn } from '@/lib/utils';
import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import { SCORE_TIER } from '@/lib/score-tiers';
import type { CandidateMatch, MatchVerdict } from '@/types/domain';

import styles from './CandidateMatchList.module.css';

interface CandidateMatchListProps {
  matches: CandidateMatch[];
  locale: Locale;
  candidateNin: string;
}

const VISIBLE_LIMIT = 5;

const REJECT_REASONS = [
  'cand360ReasonWrongField',
  'cand360ReasonExpMismatch',
  'cand360ReasonLocation',
  'cand360ReasonSkillsGap',
  'cand360ReasonOther',
] as const satisfies readonly (keyof typeof messages)[];

function scoreTier(score: number): string {
  if (score >= SCORE_TIER.STRONG_MIN) return styles.sHi ?? '';
  if (score >= SCORE_TIER.GOOD_MIN) return styles.sMid ?? '';
  return styles.sLo ?? '';
}

export function CandidateMatchList({ matches, locale, candidateNin }: CandidateMatchListProps): JSX.Element {
  const router = useRouter();
  const [verdicts, setVerdicts] = useState<Record<string, MatchVerdict | null>>(() =>
    Object.fromEntries(matches.map((match) => [match.jobId, match.verdict])),
  );
  const [openReasons, setOpenReasons] = useState<Record<string, boolean>>({});
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState<Record<string, boolean>>({});

  const m = (key: keyof typeof messages): string => messages[key][locale];

  const [redirectingJobId, setRedirectingJobId] = useState<string | null>(null);

  if (matches.length === 0) {
    return (
      <div className={styles.emptyState}>
        <p className={styles.emptyTitle}>{m('emptyNoMatches')}</p>
        <p className={styles.emptyDesc}>{m('emptyNoMatchesDesc')}</p>
      </div>
    );
  }

  const setVerdict = (jobId: string, verdict: MatchVerdict): void => {
    setVerdicts((prev) => ({ ...prev, [jobId]: verdict }));
    setOpenReasons((prev) => ({ ...prev, [jobId]: false }));
  };

  const handleReject = async (jobId: string, reasonKey: string): Promise<void> => {
    setSaving((prev) => ({ ...prev, [jobId]: true }));
    try {
      const res = await fetch('/api/actions/decision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nin: candidateNin, jobId, verdict: 'rejected', reasonKey }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setVerdict(jobId, 'rejected');
    } catch {
      toast.error(m('cand360RejectErrorTitle'), { description: m('cand360RejectErrorBody') });
    } finally {
      setSaving((prev) => ({ ...prev, [jobId]: false }));
    }
  };

  const handleApprove = (jobId: string): void => {
    setRedirectingJobId(jobId);
    router.push(`/outreach/targeting?mode=candidate&nin=${encodeURIComponent(candidateNin)}`);
  };

  const toggleReasons = (jobId: string): void => {
    setOpenReasons((prev) => ({ ...prev, [jobId]: !prev[jobId] }));
  };

  const hasOverflow = matches.length > VISIBLE_LIMIT;
  const visible = expanded ? matches : matches.slice(0, VISIBLE_LIMIT);

  return (
    <div className={styles.matchlist}>
      {visible.map((match) => {
        const verdict = verdicts[match.jobId] ?? null;
        const isAutoNotified = match.score >= SCORE_TIER.STRONG_MIN;
        return (
          <article key={match.jobId} className={styles.match}>
            <div className={styles.scoreWrap}>
              <div
                className={cn(styles.score, scoreTier(match.score))}
                dir="ltr"
                lang="en"
                aria-label={`${m('cand360Score')}: ${match.score}%`}
              >
                <span className={styles.scoreValue}>{match.score}</span>
                <span className={styles.scorePct}>%</span>
              </div>
              <div className={styles.scoreLabel}>{m('cand360JobMatchCaption')}</div>
            </div>
            <div className={styles.body}>
              <div className={styles.jt}>{match.jobTitle}</div>
              <div className={styles.jmeta}>
                {match.employer} · {match.usoc}
              </div>
              <p className={styles.exp}>{match.explanation}</p>

              <div className={styles.mverdict}>
                {isAutoNotified ? (
                  <span className={cn(styles.mvDone, styles.notified)}>
                    <Check size={14} strokeWidth={2.6} aria-hidden="true" />
                    {m('cand360Notified')}
                  </span>
                ) : redirectingJobId === match.jobId ? (
                  <button
                    type="button"
                    className={cn(styles.mvBtn, styles.approve, styles.approveRedirecting)}
                    disabled
                  >
                    <span className={styles.spinner} aria-hidden="true" />
                    {m('cand360Redirecting')}
                  </button>
                ) : verdict === 'approved' ? (
                  <span className={styles.mvDone}>
                    <Check size={14} strokeWidth={2.6} aria-hidden="true" />
                    {m('cand360Approved')}
                  </span>
                ) : verdict === 'rejected' ? (
                  <span className={cn(styles.mvDone, styles.rej)}>{m('cand360Rejected')}</span>
                ) : (
                  <>
                    <button
                      type="button"
                      className={cn(styles.mvBtn, styles.approve)}
                      onClick={() => handleApprove(match.jobId)}
                    >
                      <Check size={14} strokeWidth={2.6} aria-hidden="true" />
                      {m('cand360Approve')}
                    </button>
                    <button
                      type="button"
                      className={cn(styles.mvBtn, styles.reject)}
                      aria-expanded={Boolean(openReasons[match.jobId])}
                      onClick={() => toggleReasons(match.jobId)}
                    >
                      {m('cand360Reject')}
                    </button>
                    <div className={cn(styles.mvReasons, openReasons[match.jobId] && styles.open)}>
                      <div className={styles.mvLab}>{m('cand360RejectReasonLabel')}</div>
                      {REJECT_REASONS.map((reasonKey) => (
                        <button
                          key={reasonKey}
                          type="button"
                          className={styles.mvRchip}
                          disabled={saving[match.jobId]}
                          onClick={() => void handleReject(match.jobId, reasonKey)}
                        >
                          {m(reasonKey)}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          </article>
        );
      })}

      {hasOverflow ? (
        <button
          type="button"
          className={styles.matchesMore}
          aria-expanded={expanded}
          onClick={() => setExpanded((value) => !value)}
        >
          {expanded ? m('cand360ShowLess') : m('cand360ShowMore')}
        </button>
      ) : null}
    </div>
  );
}

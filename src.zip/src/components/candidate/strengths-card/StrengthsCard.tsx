'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Star } from 'lucide-react';

import styles from './StrengthsCard.module.css';
import { messages } from '@/i18n/catalog';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import type { Locale } from '@/i18n/config';
import { ReadinessInfoTooltip } from '@/components/dashboard/readiness-info-tooltip/ReadinessInfoTooltip';

interface StrengthsCardProps {
  title: string;
  strengths: string[];
  locale: Locale;
  tooltipLabel?: string;
  tooltipText?: string;
}

const VISIBLE_STRENGTHS = 4;

export function StrengthsCard({ title, strengths, locale, tooltipLabel, tooltipText }: StrengthsCardProps): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const [overflowHeight, setOverflowHeight] = useState(0);
  const overflowRef = useRef<HTMLDivElement>(null);
  const overflowId = useId();

  const hasOverflow = strengths.length > VISIBLE_STRENGTHS;
  const visibleStrengths = hasOverflow ? strengths.slice(0, VISIBLE_STRENGTHS) : strengths;
  const hiddenStrengths = hasOverflow ? strengths.slice(VISIBLE_STRENGTHS) : [];

  useEffect(() => {
    if (!overflowRef.current) {
      return;
    }

    setOverflowHeight(overflowRef.current.scrollHeight);
  }, [hiddenStrengths.length]);

  const toggleLabel = expanded
    ? messages.strengthsShowLess[locale]
    : messages.strengthsShowMore[locale];

  return (
    <SurfaceCard className={`card ${styles.strengths_card}`}>
      <div className={styles.strengths_titleRow}>
        <h2 className={styles.strengths_title}>
          <span className={styles.strengths_titleBadge} aria-hidden="true">
            <Star size={15} strokeWidth={2.3} />
          </span>
          <span>{title}</span>
        </h2>
        {tooltipLabel && tooltipText ? <ReadinessInfoTooltip label={tooltipLabel} text={tooltipText} /> : null}
      </div>

      {strengths.length === 0 ? (
        <div className={styles.emptyState}>
          <p className={styles.emptyTitle}>{messages.emptyNoStrengths[locale]}</p>
          <p className={styles.emptyDesc}>{messages.emptyNoStrengthsDesc[locale]}</p>
        </div>
      ) : (
        <>
          <div className={styles.skill_set}>
            {visibleStrengths.map((strength, index) => (
              <span key={`visible-${index}`} className={styles.skill_tag}>{strength}</span>
            ))}
          </div>

          {hasOverflow ? (
            <>
              <div
                id={overflowId}
                className={styles.overflowWrap}
                style={{ maxHeight: expanded ? `${overflowHeight}px` : '0px' }}
                aria-hidden={!expanded}
              >
                <div ref={overflowRef} className={styles.overflowInner}>
                  <div className={styles.skill_set}>
                    {hiddenStrengths.map((strength, index) => (
                      <span key={`hidden-${index}`} className={styles.skill_tag}>{strength}</span>
                    ))}
                  </div>
                </div>
              </div>

              <button
                type="button"
                className={styles.toggleBtn}
                onClick={() => setExpanded((prev) => !prev)}
                aria-expanded={expanded}
                aria-controls={overflowId}
              >
                {expanded ? <ChevronUp size={14} strokeWidth={2.2} aria-hidden="true" /> : <ChevronDown size={14} strokeWidth={2.2} aria-hidden="true" />}
                <span>{toggleLabel}</span>
              </button>
            </>
          ) : null}
        </>
      )}
    </SurfaceCard>
  );
}

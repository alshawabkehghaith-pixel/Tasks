'use client';

import { useEffect, useState } from 'react';

import { CountUpNumber } from '@/components/dashboard/count-up-number/CountUpNumber';
import { SCORE_TIER } from '@/lib/score-tiers';

import styles from './candidate-profile-view/CandidateProfileView.module.css';

interface CandidateReadinessDonutProps {
  score: number;
}

function getTone(score: number): { stroke: string; labelClassName?: string } {
  if (score >= SCORE_TIER.STRONG_MIN) {
    return { stroke: 'var(--status-green)', labelClassName: styles.score_valueGood };
  }

  if (score >= SCORE_TIER.GOOD_MIN) {
    return { stroke: 'var(--status-yellow)', labelClassName: styles.score_valueWarn };
  }

  return { stroke: 'var(--status-red)', labelClassName: styles.score_valueRisk };
}

export function CandidateReadinessDonut({ score }: CandidateReadinessDonutProps): JSX.Element {
  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));
  const [ringDrawn, setRingDrawn] = useState(false);

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (reduceMotion) {
      setRingDrawn(true);
      return;
    }

    const frameId = window.requestAnimationFrame(() => setRingDrawn(true));
    return () => window.cancelAnimationFrame(frameId);
  }, []);

  const donutSize = 164;
  const radius = 60;
  const center = donutSize / 2;
  const { stroke, labelClassName } = getTone(clampedScore);

  return (
    <div className={`${styles.score_donut_wrap} ${ringDrawn ? styles.score_donut_wrapVisible : ''}`}>
      <svg className={styles.score_donut} viewBox={`0 0 ${donutSize} ${donutSize}`} aria-hidden="true">
        <circle
          className={styles.score_track}
          cx={center}
          cy={center}
          r={radius}
          pathLength={100}
        />
        <circle
          className={styles.score_arc}
          cx={center}
          cy={center}
          r={radius}
          pathLength={100}
          stroke={stroke}
          style={{
            strokeDasharray: ringDrawn ? `${clampedScore} ${100 - clampedScore}` : '0 100',
          }}
        />
      </svg>

      <div className={styles.score_center}>
        <div className={`${styles.score_value} ${labelClassName}`} dir="ltr" lang="en">
          <CountUpNumber value={clampedScore} durationMs={1100} className={styles.score_valueNumber} />
          <span className={styles.score_symbol}>%</span>
        </div>
      </div>
    </div>
  );
}
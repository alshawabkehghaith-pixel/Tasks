'use client';

import { useMemo, useState } from 'react';
import { Check, Filter, Search } from 'lucide-react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';

import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { FilterActiveChipRow, FilterMultiSelectSection } from '@/components/filters/FilterControls';
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from '@/components/ui/Sheet';
import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import { cn } from '@/lib/utils';
import type { CandidateFacets, CandidateQuery, Readiness } from '@/types/domain';

type FilterState = Omit<CandidateQuery, 'page' | 'pageSize'> & { search?: string };

interface CandidatesFilterToolbarProps {
  locale: Locale;
  facets: CandidateFacets;
  initialFilters: FilterState;
}

function cloneFilters(filters: FilterState): FilterState {
  return {
    search: filters.search ?? '',
    readiness: [...(filters.readiness ?? [])],
    region: [...(filters.region ?? [])],
    city: [...(filters.city ?? [])],
    gender: [...(filters.gender ?? [])],
    age: [...(filters.age ?? [])],
    qualification: [...(filters.qualification ?? [])],
    occupationalField: [...(filters.occupationalField ?? [])],
    yearsExperience: [...(filters.yearsExperience ?? [])],
    status: [...(filters.status ?? [])],
    octoberBatch: [...(filters.octoberBatch ?? [])],
    freshGraduate: [...(filters.freshGraduate ?? [])],
  };
}

function asStrings(values: Array<string | number | boolean> | undefined): string[] {
  return (values ?? []).map((value) => String(value));
}

function formatBoolean(value: boolean, locale: Locale): string {
  return value ? messages.commonYes[locale] : messages.commonNo[locale];
}

function readinessLabel(value: Readiness, locale: Locale): string {
  if (value === 'ready') return messages.candListReadinessReady[locale];
  if (value === 'partial') return messages.candListReadinessPartial[locale];
  return messages.candListReadinessIncomplete[locale];
}

type Bin = { readonly en: string; readonly ar: string; readonly min: number; readonly max: number };

const AGE_BINS: readonly Bin[] = [
  { en: 'Under 25', ar: 'أقل من 25', min: 0, max: 24 },
  { en: '25–29',    ar: '25–29',    min: 25, max: 29 },
  { en: '30–34',    ar: '30–34',    min: 30, max: 34 },
  { en: '35–39',    ar: '35–39',    min: 35, max: 39 },
  { en: '40+',      ar: '40+',      min: 40, max: 99 },
];

const EXP_BINS: readonly Bin[] = [
  { en: '0–2 yrs',  ar: '0–2 سنوات',  min: 0,  max: 2  },
  { en: '3–5 yrs',  ar: '3–5 سنوات',  min: 3,  max: 5  },
  { en: '6–10 yrs', ar: '6–10 سنوات', min: 6,  max: 10 },
  { en: '11+ yrs',  ar: '11+ سنة',    min: 11, max: 99 },
];

function binLabel(bin: Bin, locale: Locale): string {
  return locale === 'ar' ? bin.ar : bin.en;
}

function bucketChipValue(bin: Bin): string {
  return `bucket:${bin.min}:${bin.max}`;
}

function RangeBucketSection({
  label,
  bins,
  facetValues,
  selectedValues,
  locale,
  onToggle,
}: {
  label: string;
  bins: readonly Bin[];
  facetValues: number[];
  selectedValues: number[];
  locale: Locale;
  onToggle: (values: number[]) => void;
}): JSX.Element {

  const activeBins = useMemo(
    () =>
      bins
        .map((bin) => ({ bin, values: facetValues.filter((v) => v >= bin.min && v <= bin.max) }))
        .filter((entry) => entry.values.length > 0),
    [bins, facetValues],
  );

  const selectedLookup = useMemo(() => new Set(selectedValues), [selectedValues]);
  const rows = activeBins.map((entry) => ({
    ...entry,
    isActive: entry.values.some((value) => selectedLookup.has(value)),
  }));
  const selectedCount = rows.filter((row) => row.isActive).length;

  return (
    <section className="filter-drawer-section space-y-1 rounded-[18px] border border-black/6 bg-white/45 p-3 shadow-[0_12px_32px_rgba(15,23,42,0.06)] backdrop-blur-sm dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-3 pb-1">
        <h3 className="text-sm font-semibold text-ink dark:text-white">{label}</h3>
        {selectedCount > 0 ? <span className="text-xs font-medium text-ink3">{selectedCount}</span> : null}
      </div>
      <div className="space-y-0.5">
        {rows.map(({ bin, values, isActive }) => {
          return (
            <button
              key={bin.min}
              type="button"
              aria-pressed={isActive}
              onClick={() => onToggle(values)}
              className={cn(
                'filter-drawer-option flex w-full items-center gap-3 rounded-xl px-3 py-2 text-start text-sm text-ink transition hover:bg-black/5 dark:text-ink dark:hover:bg-white/[0.07]',
                isActive && 'bg-[color:rgb(var(--green-ch)/0.10)] text-greenDark dark:text-[#B9F3D5]',
              )}
            >
              <span className={cn('filter-drawer-check flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-black/10 bg-white/80 dark:border-white/10 dark:bg-white/[0.08]', isActive && 'border-green/30 bg-[color:rgb(var(--green-ch)/0.12)] dark:bg-[color:rgb(var(--green-ch)/0.20)]')}>
                {isActive ? <Check size={12} strokeWidth={3} /> : null}
              </span>
              <span>{binLabel(bin, locale)}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

export function CandidatesFilterToolbar({ locale, facets, initialFilters }: CandidatesFilterToolbarProps): JSX.Element {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState(initialFilters.search ?? '');
  const [draftFilters, setDraftFilters] = useState<FilterState>(() => cloneFilters(initialFilters));

  const labels = {
    filters: messages.filtersTitle[locale],
    clearAll: messages.filtersClearAll[locale],
    apply: messages.filtersApply[locale],
    activeFilters: messages.filtersActive[locale],
  };

  function updateArrayField<K extends keyof FilterState>(key: K, values: FilterState[K]): void {
    setDraftFilters((prev) => ({ ...prev, [key]: values }));
  }

  function toggleValue<K extends keyof FilterState>(key: K, value: string): void {
    setDraftFilters((prev) => {
      const current = asStrings(prev[key] as Array<string | number | boolean> | undefined);
      const nextStrings = current.includes(value)
        ? current.filter((item) => item !== value)
        : [...current, value];

      const nextValue = (() => {
        if (key === 'age' || key === 'yearsExperience') return nextStrings.map((item) => Number(item));
        if (key === 'octoberBatch' || key === 'freshGraduate') return nextStrings.map((item) => item === 'true');
        return nextStrings;
      })();

      return { ...prev, [key]: nextValue };
    });
  }

  function toggleRangeValues(key: 'age' | 'yearsExperience', binValues: number[]): void {
    setDraftFilters((prev) => {
      const current = (prev[key] as number[] | undefined) ?? [];
      const allSelected = binValues.every((v) => current.includes(v));
      const next = allSelected
        ? current.filter((v) => !binValues.includes(v))
        : [...current, ...binValues.filter((v) => !current.includes(v))];
      return { ...prev, [key]: next };
    });
  }

  function writeParams(nextFilters: FilterState): void {
    const params = new URLSearchParams(searchParams.toString());
    const mapping: Array<[string, Array<string | number | boolean> | undefined]> = [
      ['tier', nextFilters.readiness],
      ['region', nextFilters.region],
      ['city', nextFilters.city],
      ['gender', nextFilters.gender],
      ['age', nextFilters.age],
      ['qualification', nextFilters.qualification],
      ['occupationalField', nextFilters.occupationalField],
      ['yearsExperience', nextFilters.yearsExperience],
      ['status', nextFilters.status],
      ['octoberBatch', nextFilters.octoberBatch],
      ['freshGraduate', nextFilters.freshGraduate],
    ];

    if (nextFilters.search?.trim()) params.set('q', nextFilters.search.trim());
    else params.delete('q');

    for (const [key, values] of mapping) {
      if (values && values.length > 0) params.set(key, values.join(','));
      else params.delete(key);
    }

    params.delete('page');
    const query = params.toString();
    router.push(query ? `${pathname}?${query}` : pathname, { scroll: false });
  }

  function submitSearch(event: React.FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    writeParams({ ...initialFilters, ...draftFilters, search: searchValue });
  }

  function applyFilters(): void {
    writeParams({ ...draftFilters, search: searchValue });
    setOpen(false);
  }

  function clearAll(): void {
    const cleared = cloneFilters({ search: searchValue });
    setDraftFilters(cleared);
    writeParams(cleared);
    setOpen(false);
  }

  function clearOne(key: keyof FilterState, value: string): void {
    const next = cloneFilters(draftFilters);
    if (key === 'search') {
      setSearchValue('');
      writeParams({ ...next, search: '' });
      return;
    }
    const current = asStrings(next[key] as Array<string | number | boolean> | undefined);
    const remaining = current.filter((item) => item !== value);

    if ((key === 'age' || key === 'yearsExperience') && value.startsWith('bucket:')) {
      const parts = value.split(':');
      const min = Number(parts[1]);
      const max = Number(parts[2]);
      const numericRemaining = ((next[key] as number[] | undefined) ?? []).filter((v) => v < min || v > max);
      updateArrayField(key, numericRemaining as FilterState[typeof key]);
      writeParams({ ...next, [key]: numericRemaining, search: searchValue });
      return;
    }
    if (key === 'age' || key === 'yearsExperience') updateArrayField(key, remaining.map((item) => Number(item)) as FilterState[typeof key]);
    else if (key === 'octoberBatch' || key === 'freshGraduate') updateArrayField(key, remaining.map((item) => item === 'true') as FilterState[typeof key]);
    else updateArrayField(key, remaining as FilterState[typeof key]);
    writeParams({
      ...next,
      [key]: key === 'age' || key === 'yearsExperience'
        ? remaining.map((item) => Number(item))
        : key === 'octoberBatch' || key === 'freshGraduate'
          ? remaining.map((item) => item === 'true')
          : remaining,
      search: searchValue,
    });
  }

  const activeChips = useMemo(() => {
    const chips: Array<{ key: keyof FilterState; value: string; label: string }> = [];
    for (const value of initialFilters.readiness ?? []) chips.push({ key: 'readiness', value, label: `${messages.colReadiness[locale]}: ${readinessLabel(value, locale)}` });
    for (const value of initialFilters.region ?? []) chips.push({ key: 'region', value, label: `${messages.colRegion[locale]}: ${value}` });
    for (const value of initialFilters.city ?? []) chips.push({ key: 'city', value, label: `${messages.colCity[locale]}: ${value}` });
    for (const value of initialFilters.gender ?? []) chips.push({ key: 'gender', value, label: `${messages.cand360Gender[locale]}: ${value}` });

    const seenAge = new Set<number>();
    for (const v of initialFilters.age ?? []) {
      const bin = AGE_BINS.find((b) => v >= b.min && v <= b.max);
      if (bin && !seenAge.has(bin.min)) {
        seenAge.add(bin.min);
        chips.push({ key: 'age', value: bucketChipValue(bin), label: `${messages.cand360Age[locale]}: ${binLabel(bin, locale)}` });
      }
    }
    for (const value of initialFilters.qualification ?? []) chips.push({ key: 'qualification', value, label: `${messages.cand360Qualification[locale]}: ${value}` });
    for (const value of initialFilters.occupationalField ?? []) chips.push({ key: 'occupationalField', value, label: `${messages.colOccupationalField[locale]}: ${value}` });

    const seenExp = new Set<number>();
    for (const v of initialFilters.yearsExperience ?? []) {
      const bin = EXP_BINS.find((b) => v >= b.min && v <= b.max);
      if (bin && !seenExp.has(bin.min)) {
        seenExp.add(bin.min);
        chips.push({ key: 'yearsExperience', value: bucketChipValue(bin), label: `${messages.cand360YearsExp[locale]}: ${binLabel(bin, locale)}` });
      }
    }
    for (const value of initialFilters.status ?? []) chips.push({ key: 'status', value, label: `${messages.colEmploymentStatus[locale]}: ${value}` });
    for (const value of initialFilters.octoberBatch ?? []) chips.push({ key: 'octoberBatch', value: String(value), label: `${messages.colOctoberBatch[locale]}: ${formatBoolean(value, locale)}` });
    for (const value of initialFilters.freshGraduate ?? []) chips.push({ key: 'freshGraduate', value: String(value), label: `${messages.colFreshGraduate[locale]}: ${formatBoolean(value, locale)}` });
    return chips;
  }, [initialFilters, locale]);

  type SectionDef =
    | { kind?: never; key: keyof FilterState; label: string; hint?: string; options: Array<{ value: string; label: string }> }
    | { kind: 'bucket'; key: 'age' | 'yearsExperience'; label: string };

  const sections: SectionDef[] = useMemo(() => [
    { key: 'readiness', label: messages.colReadiness[locale], options: facets.readiness.map((value) => ({ value, label: readinessLabel(value, locale) })) },
    { key: 'region', label: messages.colRegion[locale], options: facets.regions.map((value) => ({ value, label: value })) },
    { key: 'city', label: messages.colCity[locale], options: facets.cities.map((value) => ({ value, label: value })) },
    { key: 'gender', label: messages.cand360Gender[locale], options: facets.genders.map((value) => ({ value, label: value })) },
    { kind: 'bucket', key: 'age', label: messages.cand360Age[locale] },
    { key: 'qualification', label: messages.cand360Qualification[locale], options: facets.qualifications.map((value) => ({ value, label: value })) },
    {
      key: 'occupationalField',
      label: messages.colOccupationalField[locale],
      hint: messages.colOccupationalFieldHint[locale],
      options: facets.occupationalFields.map((value) => ({ value, label: value })),
    },
    { kind: 'bucket', key: 'yearsExperience', label: messages.cand360YearsExp[locale] },
    { key: 'status', label: messages.colEmploymentStatus[locale], options: facets.statuses.map((value) => ({ value, label: value })) },
    { key: 'octoberBatch', label: messages.colOctoberBatch[locale], options: facets.octoberBatch.map((value) => ({ value: String(value), label: formatBoolean(value, locale) })) },
    { key: 'freshGraduate', label: messages.colFreshGraduate[locale], options: facets.freshGraduate.map((value) => ({ value: String(value), label: formatBoolean(value, locale) })) },
  ], [facets, locale]);

  const hasActiveFilters = activeChips.length > 0;

  return (
    <div className="space-y-4">
      <form onSubmit={submitSearch} className="flex flex-col gap-3 md:flex-row md:items-center">
        <label className="relative flex-1">
          <Search className="pointer-events-none absolute inset-y-0 left-4 my-auto h-4 w-4 text-ink3 rtl:left-auto rtl:right-4" />
          <input
            type="search"
            value={searchValue}
            onChange={(event) => setSearchValue(event.target.value)}
            placeholder={messages.searchCandidates[locale]}
            aria-label={messages.searchCandidates[locale]}
            className="filter-field h-14 w-full rounded-2xl border border-white/50 bg-white/75 px-12 text-sm text-ink outline-none transition placeholder:text-ink3 focus:border-green focus:ring-2 focus:ring-green/15"
          />
        </label>
        <div className="flex items-center gap-3">
          <Button type="button" tone="secondary" className="filter-field h-14 gap-2 rounded-2xl px-5 shadow-[0_16px_34px_rgba(15,23,42,0.08)] backdrop-blur-md" onClick={() => setOpen(true)}>
            <Filter size={16} strokeWidth={2.2} />
            <span>{labels.filters}</span>
            {hasActiveFilters ? <Badge tone="active" className="px-2 py-0.5 text-xs">{activeChips.length}</Badge> : null}
          </Button>
          <Button type="submit" className="h-14 gap-2 rounded-2xl px-5">
            <Search size={16} strokeWidth={2.2} />
            <span>{messages.filterApply[locale]}</span>
          </Button>
        </div>
      </form>

      {hasActiveFilters ? (
        <FilterActiveChipRow
          chips={activeChips}
          locale={locale}
          onClearOne={clearOne}
          onClearAll={clearAll}
          onShowMore={() => setOpen(true)}
        />
      ) : null}

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent closeLabel={messages.commonClose[locale]}>
          <SheetHeader>
            <div>
              <SheetTitle>{labels.filters}</SheetTitle>
              <SheetDescription>{labels.activeFilters}</SheetDescription>
            </div>
            <SheetClose label={messages.commonClose[locale]} />
          </SheetHeader>

          <div className="filter-drawer-body flex-1 min-h-0 space-y-4 overflow-y-auto overscroll-contain pe-1">
            {sections.map((section) =>
              section.kind === 'bucket' ? (
                <RangeBucketSection
                  key={section.key}
                  label={section.label}
                  bins={section.key === 'age' ? AGE_BINS : EXP_BINS}
                  facetValues={section.key === 'age' ? facets.ages : facets.yearsExperience}
                  selectedValues={(draftFilters[section.key] ?? []) as number[]}
                  locale={locale}
                  onToggle={(values) => toggleRangeValues(section.key, values)}
                />
              ) : (
                <FilterMultiSelectSection
                  key={section.key}
                  label={section.label}
                  hint={section.hint}
                  options={section.options}
                  selected={asStrings(draftFilters[section.key] as Array<string | number | boolean> | undefined)}
                  onToggle={(value) => toggleValue(section.key, value)}
                  locale={locale}
                />
              )
            )}
          </div>

          <SheetFooter>
            <div className="flex items-center gap-3">
              <Button type="button" tone="secondary" className="filter-drawer-close rounded-2xl" onClick={clearAll}>{labels.clearAll}</Button>
              <Button type="button" className="rounded-2xl" onClick={applyFilters}>{labels.apply}</Button>
            </div>
          </SheetFooter>
        </SheetContent>
      </Sheet>
    </div>
  );
}
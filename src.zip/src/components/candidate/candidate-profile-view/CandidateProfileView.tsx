import { CandidateMatchList } from '@/components/candidate/candidate-match-list/CandidateMatchList';
import { CandidateReadinessDonut } from '@/components/candidate/CandidateReadinessDonut';
import { Activity, BadgeCheck, BriefcaseBusiness, CalendarDays, CircleGauge, Clock3, GraduationCap, IdCard, MapPinned, TrendingUp, UserRound } from 'lucide-react';
import { StrengthsCard } from '../strengths-card/StrengthsCard';

import styles from './CandidateProfileView.module.css';
import { ProfileHeader, type ProfileChip } from '@/components/profile/profile-header/ProfileHeader';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import { ReadinessInfoTooltip } from '@/components/dashboard/readiness-info-tooltip/ReadinessInfoTooltip';
import { ICON_STROKE } from '@/lib/icons';
import type { CandidateProfile, ImpactLevel, JobLevel, Readiness } from '@/types/domain';

interface CandidateProfileViewProps {
  profile: CandidateProfile;
  locale: Locale;
}

const READINESS_LABEL: Record<Readiness, keyof typeof messages> = {
  ready: 'cand360ReadinessReady',
  partial: 'cand360ReadinessPartial',
  incomplete: 'cand360ReadinessIncomplete',
};

const IMPACT_LABEL: Record<ImpactLevel, keyof typeof messages> = {
  high: 'cand360ImpactHigh',
  medium: 'cand360ImpactMedium',
  low: 'cand360ImpactLow',
};

const JOB_LEVEL_LABEL: Record<JobLevel, keyof typeof messages> = {
  entry: 'cand360JobLevelEntry',
  mid: 'cand360JobLevelMid',
  senior: 'cand360JobLevelSenior',
};

const IMPACT_PILL_CLASS: Record<ImpactLevel, string> = {
  high: styles.impact_high ?? '',
  medium: styles.impact_medium ?? '',
  low: styles.impact_low ?? '',
};

export function CandidateProfileView({ profile, locale }: CandidateProfileViewProps): JSX.Element {
  const m = (key: keyof typeof messages): string => messages[key][locale];
  const jobLevelLabel = m(JOB_LEVEL_LABEL[profile.jobLevel]);
  const formatBoolean = (value: boolean): string => value ? m('commonYes') : m('commonNo');

  const chips: ProfileChip[] = [
    { label: m(READINESS_LABEL[profile.readiness]), tone: profile.readiness, dot: true },
    { label: jobLevelLabel },
    { label: profile.region },
    { label: profile.city },
  ];

  const facts = [
    { label: m('cand360Gender'), value: profile.gender, icon: UserRound },
    { label: m('cand360Age'), value: String(profile.age), icon: CalendarDays },
    { label: m('colRegion'), value: profile.region, icon: MapPinned },
    { label: m('colCity'), value: profile.city, icon: MapPinned },
    { label: m('cand360OccupationalField'), value: profile.occupationalField, icon: BriefcaseBusiness },
    { label: m('cand360Qualification'), value: profile.qualification, icon: GraduationCap },
    { label: m('cand360YearsExp'), value: String(profile.yearsExperience), icon: Clock3 },
    { label: m('cand360JobLevel'), value: jobLevelLabel, icon: TrendingUp },
    { label: m('cand360OctoberBatch'), value: formatBoolean(profile.octoberBatch), icon: IdCard },
    { label: m('cand360FreshGraduate'), value: formatBoolean(profile.freshGraduate), icon: BadgeCheck },
    { label: m('cand360Status'), value: profile.status, icon: Activity, isStatus: true },
  ];

  return (
    <>
      <ProfileHeader
        name={profile.name}
        subtitle={profile.nin}
        chips={chips}
        className={styles.headerPlain}
        metadataIcons={[BriefcaseBusiness, MapPinned, MapPinned]}
      />

      <div className="duo">
        <SurfaceCard className={`card ${styles.profile_card}`}>
          <h2 className={styles.profile_title}>
            <span className={styles.profile_titleBadge} aria-hidden="true">
              <UserRound size={15} strokeWidth={ICON_STROKE} />
            </span>
            <span>{m('cand360ProfileData')}</span>
          </h2>
          <dl className={styles.data_grid}>
            {facts.map(({ label, value, icon: Icon, isStatus }) => {
              return (
                <div key={label} className={`${styles.fact_item}${isStatus ? ` ${styles.fact_itemStatus}` : ''}`}>
                  <span className={styles.fact_iconChip} aria-hidden="true">
                    <Icon size={14} strokeWidth={ICON_STROKE} />
                  </span>
                  <div className={styles.fact_content}>
                    <dt className={styles.fact_key}>{label}</dt>
                    <dd className={styles.fact_val}>{value}</dd>
                  </div>
                </div>
              );
            })}
          </dl>
        </SurfaceCard>

        <SurfaceCard className={`card ${styles.readiness_card}`}>
          <div className={styles.readiness_titleRow}>
            <h2 className={styles.readiness_title}>
              <span className={styles.readiness_titleBadge} aria-hidden="true">
                <CircleGauge size={16} strokeWidth={ICON_STROKE} />
              </span>
              <span>{m('cand360ReadinessTitle')}</span>
            </h2>
            <ReadinessInfoTooltip
              label={m('cand360ReadinessInfoLabel')}
              text={m('cand360ReadinessInfoTooltip')}
            />
          </div>
          <div className={styles.score_wrap}>
            <CandidateReadinessDonut score={profile.readinessScore} />
          </div>
          {profile.readinessDrivers.length > 0 ? (
            <>
              <div className={styles.readiness_sectionHeader}>
                <div className={styles.readiness_label}>{m('cand360WhatRaises')}</div>
                <ReadinessInfoTooltip
                  label={m('cand360GapsInfoLabel')}
                  text={m('cand360GapsInfoTooltip')}
                />
              </div>
              <div className={styles.readiness_sectionDivider} aria-hidden="true" />
              {profile.readinessDrivers.map((driver, index) => (
                <div key={index} className={`${styles.readiness_item}${index === 0 ? ` ${styles.readiness_itemFirst}` : ''}`}>
                  <div className={styles.readiness_itemMain}>
                    <span className={styles.readiness_itemField}>
                      <span className={styles.readiness_itemNumber}>{index + 1}.</span>
                      <span>{driver.field}</span>
                    </span>
                    <span className={styles.readiness_itemMeta}>
                      <span className={`${styles.impact_pill} ${IMPACT_PILL_CLASS[driver.impact]}`}>
                        {m(IMPACT_LABEL[driver.impact])}
                      </span>
                      <span>{`+${driver.points} ${m('cand360Points')}`}</span>
                    </span>
                  </div>
                </div>
              ))}
            </>
          ) : null}
        </SurfaceCard>
      </div>

      <StrengthsCard
        title={m('cand360Strengths')}
        strengths={profile.strengths.map((strength) => strength.label)}
        locale={locale}
        tooltipLabel={m('cand360StrengthsInfoLabel')}
        tooltipText={m('cand360StrengthsInfoTooltip')}
      />

      <SurfaceCard className={`card ${styles.matches_card}`}>
        <h2 className={styles.matches_title}>
          <span className={styles.matches_titleBadge} aria-hidden="true">
            <BadgeCheck size={15} strokeWidth={ICON_STROKE} />
          </span>
          <span>{m('cand360BestMatches')}</span>
        </h2>
        <CandidateMatchList matches={profile.matches} locale={locale} candidateNin={profile.nin} />
      </SurfaceCard>
    </>
  );
}

'use client';

import { createContext, useContext, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

import { cn } from '@/lib/utils';

interface SheetContextValue {
  open: boolean;
  onOpenChange: (next: boolean) => void;
}

const SheetContext = createContext<SheetContextValue | null>(null);

function useSheetContext(): SheetContextValue {
  const value = useContext(SheetContext);
  if (!value) throw new Error('Sheet components must be used within Sheet');
  return value;
}

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

export function Sheet({ open, onOpenChange, children }: { open: boolean; onOpenChange: (next: boolean) => void; children: React.ReactNode }): JSX.Element {
  const triggerRef = useRef<Element | null>(null);

  useEffect(() => {
    if (!open) return;
    triggerRef.current = document.activeElement;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onOpenChange(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener('keydown', onKeyDown);
      if (triggerRef.current instanceof HTMLElement) triggerRef.current.focus();
    };
  }, [open, onOpenChange]);

  return <SheetContext.Provider value={{ open, onOpenChange }}>{children}</SheetContext.Provider>;
}

export function SheetContent({
  className,
  children,
  closeLabel = 'Close',
  side = 'end',
}: {
  className?: string;
  children: React.ReactNode;
  closeLabel?: string;
  /** Physical side. Prefer explicit left/right when locale should drive placement. */
  side?: 'left' | 'right' | 'start' | 'end';
}): JSX.Element | null {
  const { open, onOpenChange } = useSheetContext();
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const panel = panelRef.current;
    if (!panel) return;

    const firstFocusable = panel.querySelector<HTMLElement>(FOCUSABLE_SELECTOR);
    (firstFocusable ?? panel).focus();

    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key !== 'Tab') return;
      const focusable = Array.from(panel.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR));
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    panel.addEventListener('keydown', onKeyDown);
    return () => panel.removeEventListener('keydown', onKeyDown);
  }, [open]);

  if (!open || typeof document === 'undefined') return null;

  const sideClass =
    side === 'left'
      ? 'left-0 right-auto border-r border-l-0'
      : side === 'right'
        ? 'right-0 left-auto border-l border-r-0'
        : side === 'start'
          ? 'inset-inline-start-0 inset-inline-end-auto border-inline-end border-inline-start-0'
          : 'inset-inline-end-0 inset-inline-start-auto border-inline-start border-inline-end-0';

  return createPortal(
    <div className="fixed inset-0 z-[70]">
      <button
        type="button"
        aria-label={closeLabel}
        className="absolute inset-0 bg-[rgba(12,18,28,0.42)] backdrop-blur-[3px]"
        onClick={() => onOpenChange(false)}
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        tabIndex={-1}
        data-sheet-side={side}
        className={cn(
          'filter-drawer-panel absolute inset-y-0 flex min-h-0 w-full max-w-[min(92vw,30rem)] flex-col overflow-hidden border-black/10 bg-[linear-gradient(180deg,rgba(248,250,252,0.97),rgba(240,244,248,0.95))] p-5 shadow-[0_24px_80px_rgba(15,23,42,0.28)] backdrop-blur-2xl dark:border-white/10 dark:bg-white/[0.06]',
          sideClass,
          className,
        )}
      >
        {children}
      </div>
    </div>,
    document.body,
  );
}

export function SheetHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>): JSX.Element {
  return <div className={cn('mb-4 flex items-start justify-between gap-4', className)} {...props} />;
}

export function SheetTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>): JSX.Element {
  return <h2 className={cn('text-xl font-semibold tracking-tight text-ink dark:text-white', className)} {...props} />;
}

export function SheetDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>): JSX.Element {
  return <p className={cn('text-sm text-ink2 dark:text-ink3', className)} {...props} />;
}

export function SheetFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>): JSX.Element {
  return <div className={cn('filter-drawer-footer mt-auto flex items-center justify-between gap-3 border-t border-black/6 pt-4 dark:border-white/10', className)} {...props} />;
}

export function SheetClose({ className, label = 'Close' }: { className?: string; label?: string }): JSX.Element {
  const { onOpenChange } = useSheetContext();
  return (
    <button
      type="button"
      aria-label={label}
      className={cn('filter-drawer-close inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-black/8 bg-white/65 text-ink transition hover:bg-white dark:border-white/10 dark:bg-white/5 dark:text-ink dark:hover:bg-white/[0.08]', className)}
      onClick={() => onOpenChange(false)}
    >
      <X size={16} strokeWidth={2.3} />
    </button>
  );
}
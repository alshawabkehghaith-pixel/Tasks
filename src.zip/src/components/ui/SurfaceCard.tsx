import type { HTMLAttributes } from 'react';

import { cn } from '@/lib/utils';
import styles from './SurfaceCard.module.css';

export interface SurfaceCardProps extends HTMLAttributes<HTMLDivElement> {
  /** Hover lens shimmer. Defaults to true. */
  interactive?: boolean;
}

export function SurfaceCard({
  className,
  children,
  interactive = true,
  ...props
}: SurfaceCardProps): JSX.Element {
  return (
    <div
      className={cn(
        'surface-card relative isolate overflow-hidden p-5',
        styles.root,
        interactive && styles.interactive,
        className,
      )}
      {...props}
    >
      {interactive ? (
        <span className={cn(styles.shimmer, 'surface-card-shimmer')} aria-hidden="true" />
      ) : null}
      {children}
    </div>
  );
}

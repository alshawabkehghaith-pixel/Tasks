'use client';

import type { KeyboardEvent, ReactNode } from 'react';
import { useRouter } from 'next/navigation';

interface ClickableRowProps {
  href: string;
  children: ReactNode;
  className?: string;
}

function startNavProgress(): void {
  (window as Window & { __startNavProgress?: () => void }).__startNavProgress?.();
}

export function ClickableRow({ href, children, className }: ClickableRowProps): JSX.Element {
  const router = useRouter();

  function navigate(): void {
    startNavProgress();
    router.push(href);
  }

  function handleClick(e: React.MouseEvent<HTMLTableRowElement>): void {
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if ((e.target as Element).closest('a, button, input, select, textarea, label')) return;
    navigate();
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTableRowElement>): void {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    if ((e.target as Element).closest('a, button, input, select, textarea, label')) return;
    e.preventDefault();
    navigate();
  }

  return (
    <tr
      className={className}
      style={{ cursor: 'pointer' }}
      tabIndex={0}
      role="link"
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      {children}
    </tr>
  );
}

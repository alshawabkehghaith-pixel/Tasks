import { cn } from '@/lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  tone?: 'primary' | 'secondary' | 'ghost';
}

const toneClasses: Record<NonNullable<ButtonProps['tone']>, string> = {
  primary: 'bg-green text-white shadow-soft hover:bg-greenDark',
  secondary: 'border border-white/70 bg-white/80 text-ink hover:bg-white dark:border-white/10 dark:bg-white/5 dark:text-ink dark:hover:bg-white/[0.08]',
  ghost: 'bg-transparent text-ink2 hover:bg-black/5',
};

export function Button({ className, tone = 'primary', type = 'button', ...props }: ButtonProps): JSX.Element {
  return (
    <button
      type={type}
      className={cn(
        'inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-green focus:ring-offset-2 focus:ring-offset-transparent disabled:cursor-not-allowed disabled:opacity-60',
        toneClasses[tone],
        className,
      )}
      {...props}
    />
  );
}
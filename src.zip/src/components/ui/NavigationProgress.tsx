'use client';

import { useEffect, useRef, useState } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';

const NAVIGATION_FAILSAFE_MS = 8000;

export function NavigationProgress(): JSX.Element | null {
  const [width, setWidth] = useState(0);
  const [phase, setPhase] = useState<'idle' | 'running' | 'finishing'>('idle');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const failsafeRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isFirstMount = useRef(true);
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function finish() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    if (failsafeRef.current) clearTimeout(failsafeRef.current);
    failsafeRef.current = null;
    document.documentElement.removeAttribute('data-navigating');
    setWidth(100);
    setPhase('finishing');
    hideTimerRef.current = setTimeout(() => {
      setPhase('idle');
      setWidth(0);
    }, 380);
  }

  function begin() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    if (failsafeRef.current) clearTimeout(failsafeRef.current);
    document.documentElement.setAttribute('data-navigating', 'true');
    let w = 12;
    setWidth(w);
    setPhase('running');
    intervalRef.current = setInterval(() => {
      w += (88 - w) * 0.08;
      setWidth(Math.min(w, 88));
    }, 80);

    failsafeRef.current = setTimeout(finish, NAVIGATION_FAILSAFE_MS);
  }

  useEffect(() => {
    (window as Window & { __startNavProgress?: () => void }).__startNavProgress = begin;
    return () => {
      delete (window as Window & { __startNavProgress?: () => void }).__startNavProgress;
    };

  }, []);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    finish();

  }, [pathname, searchParams]);

  useEffect(() => {
    function onCapture(e: MouseEvent): void {
      if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
      const target = e.target as Element | null;
      const anchor = target?.closest('a[href]') as HTMLAnchorElement | null;
      if (!anchor) return;
      if (anchor.hasAttribute('data-no-nav-progress')) return;
      if (anchor.target && anchor.target !== '_self') return;
      if (anchor.hasAttribute('download')) return;
      const href = anchor.getAttribute('href') ?? '';
      if (!href || href.startsWith('#') || /^[a-z][a-z\d+\-.]*:/i.test(href)) return;

      const destination = new URL(anchor.href, window.location.href);
      if (destination.origin !== window.location.origin) return;

      if (destination.pathname + destination.search === window.location.pathname + window.location.search) return;

      begin();
    }

    function onBubble(e: MouseEvent): void {
      if (!e.defaultPrevented) return;
      if (!(e.target as Element | null)?.closest('a[href]')) return;
      if (!document.documentElement.hasAttribute('data-navigating')) return;
      finish();
    }

    document.addEventListener('click', onCapture, true);
    document.addEventListener('click', onBubble, false);
    return () => {
      document.removeEventListener('click', onCapture, true);
      document.removeEventListener('click', onBubble, false);
    };
  }, []);

  useEffect(() => () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    if (failsafeRef.current) clearTimeout(failsafeRef.current);
    document.documentElement.removeAttribute('data-navigating');
  }, []);

  if (phase === 'idle') return null;

  return (
    <div
      aria-hidden="true"
      style={{
        position: 'fixed',
        top: 0,
        insetInlineStart: 0,
        insetInlineEnd: 0,
        height: 3,
        zIndex: 9999,
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          height: '100%',
          width: `${width}%`,
          background: 'var(--brand)',
          boxShadow: '0 0 8px var(--brand), 0 0 2px var(--brand)',
          borderRadius: '0 2px 2px 0',
          transition:
            phase === 'finishing'
              ? 'width 0.15s ease-out, opacity 0.25s ease 0.15s'
              : 'width 0.12s linear',
          opacity: phase === 'finishing' ? 0 : 1,
        }}
      />
    </div>
  );
}

'use client';

import { Suspense, useEffect, useRef, useState } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';

import styles from './NavigationProgress.module.css';

const NAVIGATION_FAILSAFE_MS = 8000;
const FINISH_HOLD_MS = 280;
const HIDE_MS = 220;

function NavigationProgressInner(): JSX.Element | null {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'idle' | 'running' | 'finishing'>('idle');
  const progressRef = useRef(0);
  const phaseRef = useRef<'idle' | 'running' | 'finishing'>('idle');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const failsafeRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const finishTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startedAtRef = useRef(0);
  const isFirstMount = useRef(true);
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function setPhaseSafe(next: 'idle' | 'running' | 'finishing'): void {
    phaseRef.current = next;
    setPhase(next);
  }

  function setProgressSafe(next: number): void {
    progressRef.current = next;
    setProgress(next);
  }

  function clearTimers(): void {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    if (failsafeRef.current) clearTimeout(failsafeRef.current);
    failsafeRef.current = null;
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = null;
    if (finishTimerRef.current) clearTimeout(finishTimerRef.current);
    finishTimerRef.current = null;
  }

  function finish(): void {
    if (phaseRef.current === 'idle' || phaseRef.current === 'finishing') return;

    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    if (failsafeRef.current) clearTimeout(failsafeRef.current);
    failsafeRef.current = null;

    document.documentElement.removeAttribute('data-navigating');

    const elapsed = Date.now() - startedAtRef.current;
    const wait = Math.max(0, 180 - elapsed);

    finishTimerRef.current = setTimeout(() => {
      setProgressSafe(100);
      setPhaseSafe('finishing');
      hideTimerRef.current = setTimeout(() => {
        setPhaseSafe('idle');
        setProgressSafe(0);
      }, FINISH_HOLD_MS + HIDE_MS);
    }, wait);
  }

  function begin(): void {
    if (phaseRef.current === 'running') return;

    clearTimers();
    document.documentElement.setAttribute('data-navigating', 'true');
    startedAtRef.current = Date.now();
    setProgressSafe(0);
    setPhaseSafe('running');

    // One smooth ramp after paint — avoids 0→jump flicker.
    requestAnimationFrame(() => {
      if (phaseRef.current !== 'running') return;
      setProgressSafe(22);
    });

    intervalRef.current = setInterval(() => {
      if (phaseRef.current !== 'running') return;
      const current = progressRef.current;
      const next =
        current < 45 ? current + 4.5 :
        current < 70 ? current + 2.2 :
        current < 85 ? current + 0.9 :
        Math.min(current + 0.35, 92);
      setProgressSafe(Math.min(next, 92));
    }, 160);

    failsafeRef.current = setTimeout(finish, NAVIGATION_FAILSAFE_MS);
  }

  useEffect(() => {
    (window as Window & { __startNavProgress?: () => void }).__startNavProgress = begin;
    return () => {
      delete (window as Window & { __startNavProgress?: () => void }).__startNavProgress;
    };
  }, []);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    finish();
  }, [pathname, searchParams]);

  useEffect(() => {
    function onCapture(e: MouseEvent): void {
      if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
      const target = e.target as Element | null;
      const anchor = target?.closest('a[href]') as HTMLAnchorElement | null;
      if (!anchor) return;
      if (anchor.hasAttribute('data-no-nav-progress')) return;
      if (anchor.target && anchor.target !== '_self') return;
      if (anchor.hasAttribute('download')) return;
      const href = anchor.getAttribute('href') ?? '';
      if (!href || href.startsWith('#') || /^[a-z][a-z\d+\-.]*:/i.test(href)) return;

      const destination = new URL(anchor.href, window.location.href);
      if (destination.origin !== window.location.origin) return;
      if (destination.pathname + destination.search === window.location.pathname + window.location.search) return;

      begin();
    }

    function onBubble(e: MouseEvent): void {
      if (!e.defaultPrevented) return;
      if (!(e.target as Element | null)?.closest('a[href]')) return;
      if (!document.documentElement.hasAttribute('data-navigating')) return;
      finish();
    }

    function onPopState(): void {
      begin();
    }

    document.addEventListener('click', onCapture, true);
    document.addEventListener('click', onBubble, false);
    window.addEventListener('popstate', onPopState);
    return () => {
      document.removeEventListener('click', onCapture, true);
      document.removeEventListener('click', onBubble, false);
      window.removeEventListener('popstate', onPopState);
    };
  }, []);

  useEffect(() => () => {
    clearTimers();
    document.documentElement.removeAttribute('data-navigating');
  }, []);

  if (phase === 'idle') return null;

  return (
    <div className={styles.track} aria-hidden="true" data-phase={phase}>
      <div
        className={styles.bar}
        style={{ transform: `scaleX(${Math.max(progress, 0) / 100})` }}
      />
    </div>
  );
}

export function NavigationProgress(): JSX.Element {
  return (
    <Suspense fallback={null}>
      <NavigationProgressInner />
    </Suspense>
  );
}

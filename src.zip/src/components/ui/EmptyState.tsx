import Link from 'next/link';

import { SurfaceCard } from '@/components/ui/SurfaceCard';

export interface EmptyStateProps {
  title: string;
  description?: string;
  className?: string;
  ctaHref?: string;
  ctaLabel?: string;
  carded?: boolean;
}

const EMPTY_ICON = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
    <path d="M3 7l9-4 9 4-9 4-9-4z" strokeLinejoin="round" />
    <path d="M3 7v10l9 4 9-4V7" strokeLinejoin="round" />
    <path d="M12 11v10" />
  </svg>
);

export function EmptyState({
  title,
  description,
  className,
  ctaHref,
  ctaLabel,
  carded = true,
}: EmptyStateProps): JSX.Element {
  const body = (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-black/5 text-ink3 dark:bg-white/5">
        <span className="h-7 w-7">{EMPTY_ICON}</span>
      </span>
      <p className="text-base font-semibold text-ink dark:text-ink">{title}</p>
      {description ? <p className="max-w-md text-sm text-ink3">{description}</p> : null}
      {ctaHref && ctaLabel ? (
        <Link
          href={ctaHref}
          className="mt-2 rounded-[10px] bg-[var(--brand)] px-5 py-2.5 text-[13px] font-semibold text-white no-underline transition-[background,transform] duration-150 hover:bg-[var(--green-dark)] active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--green)]"
        >
          {ctaLabel}
        </Link>
      ) : null}
    </div>
  );

  if (!carded) {
    return <div className={className}>{body}</div>;
  }

  return (
    <SurfaceCard className={className}>
      {body}
    </SurfaceCard>
  );
}

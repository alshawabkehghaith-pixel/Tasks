'use client';

import { cn } from '@/lib/utils';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: 'neutral' | 'active';
}

const toneClasses: Record<NonNullable<BadgeProps['tone']>, string> = {
  neutral: 'border border-white/55 bg-white/70 text-ink shadow-[0_8px_24px_rgba(15,23,42,0.08)] backdrop-blur-md dark:border-white/10 dark:bg-white/8',
  active: 'border border-green/25 bg-[color:rgb(var(--green-ch)/0.12)] text-greenDark shadow-[0_8px_24px_rgba(20,145,92,0.18)] backdrop-blur-md dark:border-green/20 dark:bg-[color:rgb(var(--green-ch)/0.16)] dark:text-[#B9F3D5]',
};

export function Badge({ className, tone = 'neutral', ...props }: BadgeProps): JSX.Element {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 rounded-2xl px-3 py-1.5 text-sm font-medium transition',
        toneClasses[tone],
        className,
      )}
      {...props}
    />
  );
}
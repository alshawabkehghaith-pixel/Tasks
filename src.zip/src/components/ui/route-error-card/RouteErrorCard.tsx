'use client';

import { useEffect } from 'react';

import styles from './RouteErrorCard.module.css';

interface RouteErrorCardProps {
  scope: string;
  titleAr: string;
  titleEn: string;
  error: Error & { digest?: string };
  reset: () => void;
}

export function RouteErrorCard({ scope, titleAr, titleEn, error, reset }: RouteErrorCardProps): JSX.Element {
  useEffect(() => {
    console.error(`[${scope}] page error:`, error);
  }, [scope, error]);

  function handleRetry(): void {
    reset();
    window.location.reload();
  }

  return (
    <div className={styles.wrap}>
      <div className={styles.card} role="alert">
        <p className={styles.eyebrow}>خطأ / Error</p>
        <h2 className={styles.title}>
          {titleAr}
          <span className={styles.titleAlt} dir="ltr" lang="en">{titleEn}</span>
        </h2>
        <p className={styles.body}>
          حدث خطأ أثناء جلب البيانات. يمكنك المحاولة مجدداً.
          <span className={styles.titleAlt} dir="ltr" lang="en">
            Something went wrong while loading this data. You can try again.
          </span>
        </p>
        {error.digest ? (
          <p className={styles.digest} dir="ltr">
            Reference: {error.digest}
          </p>
        ) : null}
        <button type="button" className={styles.retry} onClick={handleRetry}>
          حاول مجدداً / Try again
        </button>
      </div>
    </div>
  );
}

import type { ReactNode } from 'react';
import { AlertCircle, Briefcase, CheckCircle2, MapPin, TrendingUp, XCircle } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

import { SurfaceCard } from '@/components/ui/SurfaceCard';

import styles from './ProfileHeader.module.css';

export type ChipTone = 'neutral' | 'ready' | 'partial' | 'incomplete';

export interface ProfileChip {
  label: string;
  tone?: ChipTone;
  
  dot?: boolean;
}

type Avatar =
  | { kind: 'initial'; text: string }
  | { kind: 'icon'; node: ReactNode };

interface ProfileHeaderProps {
  avatar?: Avatar;
  name: string;
  subtitle: string;
  
  subtitleDir?: 'ltr' | 'rtl';
  chips: ProfileChip[];
  className?: string;
  metadataIcons?: readonly LucideIcon[];
}

const STATUS_ICON: Record<ChipTone, typeof CheckCircle2> = {
  ready: CheckCircle2,
  partial: AlertCircle,
  incomplete: XCircle,
  neutral: CheckCircle2,
};

const STATUS_CLASS: Record<ChipTone, string> = {
  ready: styles.statusTagReady ?? '',
  partial: styles.statusTagPartial ?? '',
  incomplete: styles.statusTagIncomplete ?? '',
  neutral: styles.statusTagReady ?? '',
};

const DEFAULT_METADATA_ICONS = [Briefcase, TrendingUp, MapPin] as const;

export function ProfileHeader({ avatar, name, subtitle, subtitleDir, chips, className, metadataIcons }: ProfileHeaderProps): JSX.Element {
  const statusChip = chips[0];
  const metadataChips = chips.slice(1);
  const statusTone = statusChip?.tone ?? 'neutral';
  const StatusIcon = STATUS_ICON[statusTone];
  const isStatusMode = Boolean(statusChip?.tone);

  return (
    <SurfaceCard className={`card ${styles.header}${className ? ` ${className}` : ''}`}>
      {avatar ? (
        <div
          className={`${styles.avatar} ${avatar.kind === 'initial' ? styles.avatarInitial : styles.avatarIcon}`}
          aria-hidden="true"
        >
          {avatar.kind === 'initial' ? avatar.text : avatar.node}
        </div>
      ) : null}
      <div className={styles.info}>
        <h2 className={styles.name}>{name}</h2>
        <div className={styles.subtitle} dir={subtitleDir}>{subtitle}</div>
        <div className={styles.chips}>
          {isStatusMode ? (
            <>
              {statusChip ? (
                <span className={`${styles.statusTag} ${STATUS_CLASS[statusTone]}`}>
                      <StatusIcon size={14} strokeWidth={1.75} aria-hidden="true" />
                      <span>{statusChip.label}</span>
                    </span>
                  ) : null}
                  {metadataChips.map((chip, index) => {
                    const Icon = metadataIcons?.[index] ?? DEFAULT_METADATA_ICONS[index];
                    return (
                      <span key={`${chip.label}-${index}`} className={styles.metaGroup}>
                        <span className={styles.divider} aria-hidden="true" />
                        <span className={styles.metaTag}>
                          {Icon ? <Icon size={13} strokeWidth={1.75} aria-hidden="true" /> : null}
                          <span>{chip.label}</span>
                        </span>
                      </span>
                    );
                  })}
                </>
              ) : (
                chips.map((chip, index) => {
                  const Icon = metadataIcons?.[index];
                  return (
                    <span key={`${chip.label}-${index}`} className={styles.metaGroup}>
                      {index > 0 ? <span className={styles.divider} aria-hidden="true" /> : null}
                      <span className={styles.metaTag}>
                        {Icon ? <Icon size={13} strokeWidth={1.75} aria-hidden="true" /> : null}
                        <span>{chip.label}</span>
                      </span>
                    </span>
                  );
                })
              )}
        </div>
      </div>
    </SurfaceCard>
  );
}

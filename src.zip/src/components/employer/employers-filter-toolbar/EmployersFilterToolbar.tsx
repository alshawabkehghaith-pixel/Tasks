'use client';

import { useMemo, useState } from 'react';
import { Check, Filter, Search } from 'lucide-react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';

import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { FilterActiveChipRow, FilterMultiSelectSection } from '@/components/filters/FilterControls';
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from '@/components/ui/Sheet';
import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';
import { cn } from '@/lib/utils';
import type { EmployerFacets } from '@/types/domain';

type FilterState = {
  search: string;
  sector: string[];
  size: string[];
  region: string[];
  hasJobs: boolean;
};

interface EmployersFilterToolbarProps {
  locale: Locale;
  facets: EmployerFacets;
  initialFilters: FilterState;
}

function cloneFilters(filters: Partial<FilterState>): FilterState {
  return {
    search: filters.search ?? '',
    sector: [...(filters.sector ?? [])],
    size: [...(filters.size ?? [])],
    region: [...(filters.region ?? [])],
    hasJobs: filters.hasJobs ?? false,
  };
}

function BooleanSection({
  label,
  checked,
  onToggle,
}: {
  label: string;
  checked: boolean;
  onToggle: () => void;
}): JSX.Element {
  return (
    <section className="filter-drawer-section space-y-1 rounded-[18px] border border-black/6 bg-white/45 p-3 shadow-[0_12px_32px_rgba(15,23,42,0.06)] backdrop-blur-sm dark:border-white/10 dark:bg-white/5">
      <button
        type="button"
        aria-pressed={checked}
        onClick={onToggle}
        className={cn(
          'filter-drawer-option flex w-full items-center gap-3 rounded-xl px-3 py-2 text-start text-sm text-ink transition hover:bg-black/5 dark:text-ink dark:hover:bg-white/[0.07]',
          checked && 'bg-[color:rgb(var(--green-ch)/0.10)] text-greenDark dark:text-[#B9F3D5]',
        )}
      >
        <span className={cn('filter-drawer-check flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-black/10 bg-white/80 dark:border-white/10 dark:bg-white/[0.08]', checked && 'border-green/30 bg-[color:rgb(var(--green-ch)/0.12)] dark:bg-[color:rgb(var(--green-ch)/0.20)]')}>
          {checked ? <Check size={12} strokeWidth={3} /> : null}
        </span>
        <span>{label}</span>
      </button>
    </section>
  );
}

export function EmployersFilterToolbar({ locale, facets, initialFilters }: EmployersFilterToolbarProps): JSX.Element {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState(initialFilters.search);
  const [draftFilters, setDraftFilters] = useState<FilterState>(() => cloneFilters(initialFilters));

  const m = (key: keyof typeof messages): string => messages[key][locale];
  const hasJobsLabel = m('filtersHasActiveJobs');

  const sections = useMemo(
    () => [
      { key: 'sector' as const, label: m('colSector'), options: facets.sectors },
      { key: 'size' as const, label: m('colSize'), options: facets.sizes },
      { key: 'region' as const, label: m('colRegion'), options: facets.regions },
    ],
    [facets, locale],
  );

  function toggleValue(key: 'sector' | 'size' | 'region', value: string): void {
    setDraftFilters((prev) => {
      const current = prev[key];
      const next = current.includes(value)
        ? current.filter((item) => item !== value)
        : [...current, value];
      return { ...prev, [key]: next };
    });
  }

  function writeParams(nextFilters: FilterState): void {
    const params = new URLSearchParams(searchParams.toString());

    if (nextFilters.search.trim()) params.set('q', nextFilters.search.trim());
    else params.delete('q');

    if (nextFilters.sector.length > 0) params.set('sector', nextFilters.sector.join(','));
    else params.delete('sector');

    if (nextFilters.size.length > 0) params.set('size', nextFilters.size.join(','));
    else params.delete('size');

    if (nextFilters.region.length > 0) params.set('region', nextFilters.region.join(','));
    else params.delete('region');

    if (nextFilters.hasJobs) params.set('has_jobs', '1');
    else params.delete('has_jobs');

    params.delete('page');
    const query = params.toString();
    router.push(query ? `${pathname}?${query}` : pathname, { scroll: false });
  }

  function submitSearch(event: React.FormEvent<HTMLFormElement>): void {
    event.preventDefault();
    writeParams({ ...draftFilters, search: searchValue });
  }

  function applyFilters(): void {
    writeParams({ ...draftFilters, search: searchValue });
    setOpen(false);
  }

  function clearAll(): void {
    const cleared = cloneFilters({ search: searchValue });
    setDraftFilters(cleared);
    writeParams(cleared);
    setOpen(false);
  }

  function clearChip(key: keyof FilterState, value: string): void {
    const next = cloneFilters(draftFilters);
    if (key === 'search') {
      setSearchValue('');
      writeParams({ ...next, search: '' });
      return;
    }
    if (key === 'hasJobs') {
      const updated = { ...next, hasJobs: false };
      setDraftFilters(updated);
      writeParams(updated);
      return;
    }
    const arr = next[key as 'sector' | 'size' | 'region'].filter((item) => item !== value);
    const updated = { ...next, [key]: arr };
    setDraftFilters(updated);
    writeParams({ ...updated, search: searchValue });
  }

  const activeChips = useMemo(() => {
    const chips: Array<{ key: keyof FilterState; value: string; label: string }> = [];
    for (const value of initialFilters.sector) chips.push({ key: 'sector', value, label: `${m('colSector')}: ${value}` });
    for (const value of initialFilters.size) chips.push({ key: 'size', value, label: `${m('colSize')}: ${value}` });
    for (const value of initialFilters.region) chips.push({ key: 'region', value, label: `${m('colRegion')}: ${value}` });
    if (initialFilters.hasJobs) chips.push({ key: 'hasJobs', value: 'true', label: hasJobsLabel });
    return chips;
  }, [initialFilters, locale, hasJobsLabel]);

  const hasActiveFilters = activeChips.length > 0;

  return (
    <div className="space-y-4">
      <form onSubmit={submitSearch} className="flex flex-col gap-3 md:flex-row md:items-center">
        <label className="relative flex-1">
          <Search className="pointer-events-none absolute inset-y-0 left-4 my-auto h-4 w-4 text-ink3 rtl:left-auto rtl:right-4" />
          <input
            type="search"
            value={searchValue}
            onChange={(event) => setSearchValue(event.target.value)}
            placeholder={m('searchEmployers')}
            aria-label={m('searchEmployers')}
            className="filter-field h-14 w-full rounded-2xl border border-white/50 bg-white/75 px-12 text-sm text-ink outline-none transition placeholder:text-ink3 focus:border-green focus:ring-2 focus:ring-green/15"
          />
        </label>
        <div className="flex items-center gap-3">
          <Button type="button" tone="secondary" className="filter-field h-14 gap-2 rounded-2xl px-5 shadow-[0_16px_34px_rgba(15,23,42,0.08)] backdrop-blur-md" onClick={() => setOpen(true)}>
            <Filter size={16} strokeWidth={2.2} />
            <span>{m('filtersTitle')}</span>
            {hasActiveFilters ? <Badge tone="active" className="px-2 py-0.5 text-xs">{activeChips.length}</Badge> : null}
          </Button>
          <Button type="submit" className="h-14 gap-2 rounded-2xl px-5">
            <Search size={16} strokeWidth={2.2} />
            <span>{m('filterApply')}</span>
          </Button>
        </div>
      </form>

      {hasActiveFilters ? (
        <FilterActiveChipRow
          chips={activeChips}
          locale={locale}
          onClearOne={clearChip}
          onClearAll={clearAll}
          onShowMore={() => setOpen(true)}
        />
      ) : null}

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent closeLabel={m('commonClose')}>
          <SheetHeader>
            <div>
              <SheetTitle>{m('filtersTitle')}</SheetTitle>
              <SheetDescription>{m('filtersActive')}</SheetDescription>
            </div>
            <SheetClose label={m('commonClose')} />
          </SheetHeader>

          <div className="filter-drawer-body flex-1 min-h-0 space-y-4 overflow-y-auto overscroll-contain pe-1">
            {sections.map((section) => (
              section.options.length > 0 ? (
                <FilterMultiSelectSection
                  key={section.key}
                  label={section.label}
                  options={section.options.map((value) => ({ value, label: value }))}
                  selected={draftFilters[section.key]}
                  onToggle={(value) => toggleValue(section.key, value)}
                  locale={locale}
                />
              ) : null
            ))}
            <BooleanSection
              label={hasJobsLabel}
              checked={draftFilters.hasJobs}
              onToggle={() => setDraftFilters((prev) => ({ ...prev, hasJobs: !prev.hasJobs }))}
            />
          </div>

          <SheetFooter>
            <div className="flex items-center gap-3">
              <Button type="button" tone="secondary" className="filter-drawer-close rounded-2xl" onClick={clearAll}>{m('filtersClearAll')}</Button>
              <Button type="button" className="rounded-2xl" onClick={applyFilters}>{m('filtersApply')}</Button>
            </div>
          </SheetFooter>
        </SheetContent>
      </Sheet>
    </div>
  );
}

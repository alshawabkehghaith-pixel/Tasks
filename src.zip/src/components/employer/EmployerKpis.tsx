'use client';

import { CountUpNumber } from '@/components/dashboard/count-up-number/CountUpNumber';

interface EmployerKpi {
  label: string;
  value: number;
  sub?: string;
  green?: boolean;
}

interface EmployerKpisProps {
  items: readonly EmployerKpi[];
}

export function EmployerKpis({ items }: EmployerKpisProps): JSX.Element {
  return (
    <div className="kpis">
      {items.map((kpi) => (
        <div key={kpi.label} className="kpi plain">
          <div className="lbl">{kpi.label}</div>
          <CountUpNumber
            value={kpi.value}
            durationMs={1000}
            className={`big${kpi.green ? ' green' : ''}`}
          />
          <div className="sub" aria-hidden={!kpi.sub}>
            {kpi.sub ?? '\u00A0'}
          </div>
        </div>
      ))}
    </div>
  );
}

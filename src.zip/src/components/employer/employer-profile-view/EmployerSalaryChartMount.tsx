'use client';

import dynamic from 'next/dynamic';

import type { Locale } from '@/i18n/config';
import type { DistributionBar } from '@/types/domain';

import styles from './EmployerProfileView.module.css';

const EmployerSalaryChart = dynamic(
  () => import('./EmployerSalaryChart').then((m) => m.EmployerSalaryChart),
  { ssr: false, loading: () => <div className={styles.chart_placeholder} /> },
);

interface EmployerSalaryChartMountProps {
  bars: DistributionBar[];
  locale: Locale;
}

export function EmployerSalaryChartMount({ bars, locale }: EmployerSalaryChartMountProps): JSX.Element {
  return <EmployerSalaryChart bars={bars} locale={locale} />;
}

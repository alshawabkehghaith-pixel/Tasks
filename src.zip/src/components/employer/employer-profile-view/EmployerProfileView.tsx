import { Briefcase, Building2, ChevronLeft, ChevronRight, MapPin, Tag, Users } from 'lucide-react';
import Link from 'next/link';

import styles from './EmployerProfileView.module.css';
import { EmployerKpis } from '@/components/employer/EmployerKpis';
import { EmployerSalaryChartMount } from './EmployerSalaryChartMount';
import { ProfileHeader, type ProfileChip } from '@/components/profile/profile-header/ProfileHeader';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import type { EmployerProfile } from '@/types/domain';

export interface JobsPager {
  page: number;
  totalPages: number;
  prevHref: string | null;
  nextHref: string | null;
}

interface EmployerProfileViewProps {
  profile: EmployerProfile;
  locale: Locale;
  jobsPager: JobsPager;
}

const JOB_COLUMNS = [
  { labelKey: 'emp360ColRole', align: 'start' },
  { labelKey: 'emp360ColStatus', align: 'center' },
  { labelKey: 'emp360ColOpen', align: 'end' },
  { labelKey: 'emp360ColApps', align: 'end' },
  { labelKey: 'emp360ColSalary', align: 'start' },
] as const satisfies readonly {
  labelKey: keyof typeof messages;
  align: 'start' | 'end' | 'center';
}[];

const ALIGN_CLASS = { start: '', end: styles.taEnd ?? '', center: styles.taCenter ?? '' } as const;

export function EmployerProfileView({ profile, locale, jobsPager }: EmployerProfileViewProps): JSX.Element {
  const m = (key: keyof typeof messages): string => messages[key][locale];

  const locationLabel = profile.region
    ? (profile.city && profile.city !== profile.region ? `${profile.region} · ${profile.city}` : profile.region)
    : null;

  const chips: ProfileChip[] = [
    { label: `${m('colSize')} · ${profile.sizeLabel}` },
    { label: profile.sector },
    ...(locationLabel ? [{ label: locationLabel }] : []),
  ];

  const kpis = [
    { label: m('dashKpiActiveJobs'), value: profile.activeJobs },
    { label: m('emp360OpenPositions'), value: profile.openPositions },
    { label: m('emp360MatchedCandidates'), value: profile.matchedCandidates, green: true },
  ] as const;

  return (
    <>
      <ProfileHeader
        avatar={{ kind: 'icon', node: <Building2 size={32} strokeWidth={2.05} /> }}
        name={profile.name}
        subtitle={profile.id}
        subtitleDir="ltr"
        chips={chips}
        metadataIcons={[Users, Tag, MapPin]}
      />

      <SurfaceCard className={`card ${styles.kpis_card}`}>
        <EmployerKpis items={kpis} />
      </SurfaceCard>

      <SurfaceCard className={`card ${styles.salary_card}`}>
        <h2 className={styles.salary_title}>
          <span className={styles.salary_titleBadge} aria-hidden="true">$</span>
          <span>{m('emp360BySalary')}</span>
        </h2>
        <EmployerSalaryChartMount bars={profile.bySalary} locale={locale} />
      </SurfaceCard>

      <SurfaceCard className={`card ${styles.jobs_card}`}>
        <h2 className={styles.jobs_title}>
          <span className={styles.jobs_titleBadge} aria-hidden="true">
            <Briefcase size={15} strokeWidth={2.3} />
          </span>
          <span>{m('emp360PostedJobs')}</span>
        </h2>
        <div className="overflow-x-auto">
          <table className={styles.table}>
            <thead>
              <tr>
                {JOB_COLUMNS.map(({ labelKey, align }) => (
                  <th key={labelKey} scope="col" className={ALIGN_CLASS[align]}>
                    {m(labelKey)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {profile.postedJobs.rows.length ? (
                profile.postedJobs.rows.map((job) => (
                  <tr key={job.title}>
                    <td className={styles.job_title}>{job.title}</td>
                    <td className={styles.statusCell}>
                      <span className={job.status === 'active' ? styles.status_on : styles.status_off}>
                        {job.status === 'active' ? m('emp360StatusActive') : m('emp360StatusInactive')}
                      </span>
                    </td>
                    <td className={styles.taEnd}>{job.openings}</td>
                    <td className={styles.taEnd}>{job.matchedCandidates}</td>
                    <td>
                      <span className={styles.salary_band}>
                        <span className={styles.salary_riyal} aria-hidden="true">﷼</span>
                        <span>{job.salaryBand}</span>
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className={styles.empty} colSpan={JOB_COLUMNS.length}>
                    <div className={styles.emptyCopy}>
                      <p className={styles.emptyTitle}>{m('emptyNoJobs')}</p>
                      <p className={styles.emptyDesc}>{m('emptyNoJobsDesc')}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
            {profile.postedJobs.rows.length ? (
              <tfoot>
                <tr className={styles.tfoot_row}>
                  <td colSpan={2} />
                  <td className={`${styles.tfoot_value} ${styles.taEnd}`}>{profile.openPositions}</td>
                  <td className={`${styles.tfoot_value} ${styles.taEnd}`}>{profile.matchedCandidates}</td>
                  <td />
                </tr>
              </tfoot>
            ) : null}
          </table>
        </div>

        {jobsPager.totalPages > 1 ? (
          <nav className={`pager ${styles.jobsPager}`} aria-label={m('pagerNavLabel')}>
            {jobsPager.prevHref ? (
              <Link href={jobsPager.prevHref} aria-label={m('pagerPrevPage')}>
                <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronLeft size={14} strokeWidth={2.2} />
              </span>
            )}
            <span className="cur" aria-current="page">{jobsPager.page}</span>
            <span className={styles.pagerTotal}>/ {jobsPager.totalPages}</span>
            {jobsPager.nextHref ? (
              <Link href={jobsPager.nextHref} aria-label={m('pagerNextPage')}>
                <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronRight size={14} strokeWidth={2.2} />
              </span>
            )}
          </nav>
        ) : null}
      </SurfaceCard>
    </>
  );
}

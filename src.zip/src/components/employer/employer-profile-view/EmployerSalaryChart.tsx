'use client';

import { Bar, BarChart, CartesianGrid, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

import { useInViewOnce } from '@/hooks/useInViewOnce';
import type { Locale } from '@/i18n/config';
import { messages } from '@/i18n/catalog';
import { formatChartLabel, formatSalaryBandLabel } from '@/lib/chart-format';
import type { DistributionBar } from '@/types/domain';

import styles from './EmployerProfileView.module.css';

interface EmployerSalaryChartProps {
  bars: DistributionBar[];
  locale: Locale;
}

interface TooltipProps {
  active?: boolean;
  payload?: { value?: number }[];
  label?: string;
}

function ChartTooltip({ active, payload, label }: TooltipProps): JSX.Element | null {
  if (!active || !payload?.length) return null;
  const value = payload[0]?.value ?? 0;
  return (
    <div className={styles.chart_tooltip}>
      <div className={styles.chart_tooltipLabel} dir="ltr">
        {label ? formatSalaryBandLabel(label) : label}
      </div>
      <div className={styles.chart_tooltipValueRow}>
        <span className={styles.chart_tooltipDot} aria-hidden="true" />
        <span className={styles.chart_tooltipValue}>{value.toLocaleString()}</span>
      </div>
    </div>
  );
}

function getSalaryBandStart(label: string): number {
  const numericParts = label.match(/\d+/g);
  if (!numericParts?.length) return Number.MAX_SAFE_INTEGER;
  return Number.parseInt(numericParts[0], 10);
}

export function EmployerSalaryChart({ bars, locale }: EmployerSalaryChartProps): JSX.Element {
  const { ref, visible } = useInViewOnce<HTMLDivElement>();
  const sorted = [...bars].sort((a, b) => getSalaryBandStart(a.label) - getSalaryBandStart(b.label));

  return (
    <div ref={ref} className={styles.chart_mount}>
      {!visible ? (
        <div className={styles.chart_placeholder} />
      ) : (
        <div className={styles.chart_frame}>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={sorted} margin={{ top: 24, right: 6, left: 10, bottom: 36 }}>
              <CartesianGrid vertical={false} stroke="var(--line)" />
              <XAxis
                dataKey="label"
                axisLine={false}
                tickLine={false}
                tickFormatter={formatSalaryBandLabel}
                tick={{ fontSize: 11, fill: 'var(--text-faint)' }}
                label={{
                  value: messages.dashJobsBySalaryXAxis[locale],
                  position: 'insideBottom',
                  offset: -20,
                  fontSize: 12,
                  fill: 'var(--text-soft)',
                  fontWeight: 600,
                }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: 'var(--text-faint)' }}
                width={52}
                label={{
                  value: messages.dashJobsBySalaryYAxis[locale],
                  angle: -90,
                  position: 'insideLeft',
                  offset: 10,
                  fontSize: 12,
                  fill: 'var(--text-soft)',
                  fontWeight: 600,
                }}
              />
              <Tooltip
                cursor={{ fill: 'color-mix(in srgb, var(--brand) 6%, transparent)' }}
                content={<ChartTooltip />}
              />
              <Bar
                dataKey="count"
                fill="var(--teal)"
                radius={[6, 6, 0, 0]}
                maxBarSize={48}
                isAnimationActive
                animationDuration={700}
                animationEasing="ease-out"
              >
                <LabelList dataKey="count" position="top" style={{ fontSize: 11, fill: 'var(--text-soft)', fontWeight: 600 }} formatter={formatChartLabel} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

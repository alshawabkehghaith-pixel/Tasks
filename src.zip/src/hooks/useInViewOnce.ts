'use client';

import { useEffect, useRef, useState } from 'react';

interface UseInViewOnceOptions {
  delayMs?: number;
  threshold?: number;
  rootMargin?: string;
}

export function useInViewOnce<T extends HTMLElement>({
  delayMs = 0,
  threshold = 0.18,
  rootMargin = '0px 0px -10% 0px',
}: UseInViewOnceOptions = {}): { ref: React.RefObject<T | null>; visible: boolean } {
  const [visible, setVisible] = useState(false);
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) {
      return;
    }

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || typeof window.IntersectionObserver === 'undefined') {
      setVisible(true);
      return;
    }

    let timeoutId: number | undefined;

    const observer = new window.IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry?.isIntersecting) {
          return;
        }

        timeoutId = window.setTimeout(() => setVisible(true), delayMs);
        observer.disconnect();
      },
      {
        threshold,
        rootMargin,
      },
    );

    observer.observe(node);

    return () => {
      observer.disconnect();
      if (timeoutId !== undefined) {
        window.clearTimeout(timeoutId);
      }
    };
  }, [delayMs, rootMargin, threshold]);

  return { ref, visible };
}
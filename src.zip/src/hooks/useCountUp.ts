'use client';

import { useEffect, useMemo, useState } from 'react';

interface UseCountUpOptions {
  durationMs?: number;
}

export function useCountUp(target: number, options: UseCountUpOptions = {}): number {
  const { durationMs = 900 } = options;
  const safeTarget = useMemo(() => Math.max(0, Math.floor(target)), [target]);
  const [value, setValue] = useState<number>(safeTarget);

  useEffect(() => {
    if (typeof window === 'undefined') {
      setValue(safeTarget);
      return;
    }

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion || durationMs <= 0) {
      setValue(safeTarget);
      return;
    }

    const startValue = 0;
    const startAt = window.performance.now();
    let rafId = 0;

    const frame = (now: number): void => {
      const elapsed = now - startAt;
      const progress = Math.min(1, elapsed / durationMs);
      const eased = 1 - (1 - progress) * (1 - progress);
      const next = Math.round(startValue + (safeTarget - startValue) * eased);
      setValue(next);

      if (progress < 1) {
        rafId = window.requestAnimationFrame(frame);
      }
    };

    setValue(startValue);
    rafId = window.requestAnimationFrame(frame);

    return () => {
      window.cancelAnimationFrame(rafId);
    };
  }, [safeTarget, durationMs]);

  return value;
}

import 'server-only';

import { z } from 'zod';

const ServerEnvSchema = z.object({
  API_BASE_URL: z.string().url('API_BASE_URL must be an absolute URL, e.g. https://api.example.com'),
  DEV_AUTH_ENABLED: z
    .enum(['true', 'false'])
    .default('false')
    .transform((value) => value === 'true'),
  LOG_FILE: z.string().min(1).optional(),
});

export type ServerEnv = z.infer<typeof ServerEnvSchema>;

let cached: ServerEnv | null = null;

export function getServerEnv(): ServerEnv {
  if (cached) return cached;

  const result = ServerEnvSchema.safeParse({

    API_BASE_URL: process.env.API_BASE_URL ?? process.env.MOCK_API_URL,
    DEV_AUTH_ENABLED: process.env.DEV_AUTH_ENABLED,
    LOG_FILE: process.env.LOG_FILE,
  });

  if (!result.success) {
    const issues = result.error.issues.map((issue) => `${issue.path.join('.')}: ${issue.message}`).join('; ');
    throw new Error(`Invalid server environment configuration — ${issues}`);
  }

  cached = result.data;
  return cached;
}



export const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === 'true';

export const IS_PRODUCTION = process.env.NODE_ENV === 'production';

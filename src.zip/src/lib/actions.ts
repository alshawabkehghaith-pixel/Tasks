'use server';

import { request as apiRequest } from '@/lib/server/api-client';
import {
  CandidateBatchPreviewSchema,
  CandidateOutreachSearchSchema,
} from '@/lib/api/schemas';
import type { CandidateSummary, CustomBatchFilters } from '@/types/domain';

export async function searchCandidates(q: string): Promise<CandidateSummary[]> {
  if (!q.trim()) return [];
  return apiRequest<CandidateSummary[]>(
    `/candidates/outreach-search?q=${encodeURIComponent(q)}`,
    { cache: 'no-store' },
    CandidateOutreachSearchSchema,
  );
}

export async function previewBatchCount(filters: CustomBatchFilters): Promise<number> {
  const params = new URLSearchParams();
  filters.regions.forEach((r) => params.append('region', r));
  filters.cities.forEach((c) => params.append('city', c));
  filters.genders.forEach((g) => params.append('gender', g));
  filters.ages.forEach((a) => params.append('age', String(a)));
  filters.qualifications.forEach((q) => params.append('qualification', q));
  filters.occupationalFields.forEach((o) => params.append('occupationalField', o));
  filters.yearsExperience.forEach((y) => params.append('yearsExperience', String(y)));
  filters.statuses.forEach((s) => params.append('status', s));
  filters.readiness.forEach((r) => params.append('readiness', r));

  const payload = await apiRequest<{ count: number }>(
    `/candidates/batch-preview?${params.toString()}`,
    { cache: 'no-store' },
    CandidateBatchPreviewSchema,
  );
  return payload.count;
}



import type { CampaignPurpose } from '@/types/domain';

export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function substituteVariables(
  template: string,
  vars: Record<string, string>,
): string {
  return template.replace(/\{([^}]+)\}/g, (_match, key: string) => {
    const value = vars[key.trim()];
    return value !== undefined ? escapeHtml(value) : `{${key}}`;
  });
}

export function countVariableTokens(body: string): number {
  const matches = body.match(/\{[A-Za-z ]+\}/g);
  return new Set(matches ?? []).size;
}

export function buildCampaignSessionKey(sel: string, mode: string): string {
  const sorted = sel.split(',').filter(Boolean).sort().join('-');
  return `campaignDraftV1_${mode}_${sorted}`;
}

export const PURPOSE_DEFAULTS: Record<
  CampaignPurpose,
  { en: { subject: string; body: string }; ar: { subject: string; body: string } }
> = {
  vacancy: {
    en: {
      subject: 'فرص عمل جديدة تتناسب مع ملفك الشخصي',
      body: 'مرحباً {Candidate Name},\n\nوجدنا فرص عمل تتناسب مع ملفك الشخصي:\n\n{Job List}\n\nللتقديم: https://jadarat.sa/',
    },
    ar: {
      subject: 'فرص عمل جديدة تتناسب مع ملفك الشخصي',
      body: 'مرحباً {Candidate Name},\n\nوجدنا فرص عمل تتناسب مع ملفك الشخصي:\n\n{Job List}\n\nللتقديم: https://jadarat.sa/',
    },
  },
  completeness: {
    en: {
      subject: 'حدّث معلوماتك على بوابة جدارات',
      body: 'مرحباً {Candidate Name},\n\nفي ملفك الشخصي أقسام غير مكتملة يمكن أن تحسّن نتائج المطابقة:\n\n{Missing Sections}\n\nحدّث معلوماتك على بوابة جدارات: https://jadarat.sa/',
    },
    ar: {
      subject: 'حدّث معلوماتك على بوابة جدارات',
      body: 'مرحباً {Candidate Name},\n\nفي ملفك الشخصي أقسام غير مكتملة يمكن أن تحسّن نتائج المطابقة:\n\n{Missing Sections}\n\nحدّث معلوماتك على بوابة جدارات: https://jadarat.sa/',
    },
  },
};

export const PURPOSE_VARIABLES: Record<CampaignPurpose, string[]> = {
  vacancy: ['{Candidate Name}', '{Job List}', '{Application Link}'],
  completeness: ['{Candidate Name}', '{Missing Sections}', '{Profile Link}'],
};

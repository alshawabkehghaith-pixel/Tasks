import type { Locale, ThemeMode } from '@/types/jadarat';

export type QueryInput = Record<string, string | string[] | undefined>;

export function getQueryValue(value: string | string[] | undefined): string {
  if (Array.isArray(value)) {
    return value[0] ?? '';
  }

  return value ?? '';
}

export function buildHref(
  pathname: string,
  current: QueryInput,
  overrides: Record<string, string | undefined>,
): string {
  const params = new URLSearchParams();

  for (const [key, value] of Object.entries(current)) {
    if (key === 'lang' || key === 'theme') continue;
    const selected = getQueryValue(value);
    if (selected) {
      params.set(key, selected);
    }
  }

  for (const [key, value] of Object.entries(overrides)) {
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
  }

  const query = params.toString();
  return query ? `${pathname}?${query}` : pathname;
}

export function getLocaleFromQuery(current: QueryInput): Locale {
  return getQueryValue(current.lang) === 'en' ? 'en' : 'ar';
}

export function getThemeFromQuery(current: QueryInput): ThemeMode {
  return getQueryValue(current.theme) === 'light' ? 'light' : 'dark';
}
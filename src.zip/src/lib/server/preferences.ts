import { cookies } from 'next/headers';

import { localeDirection } from '@/i18n/config';
import { DEFAULT_LOCALE, DEFAULT_THEME, resolveLocale, resolveTheme } from '@/lib/api/jadarat';
import type { AppPreferences } from '@/types/jadarat';

type SearchParamValue = string | string[] | undefined;

export async function getServerAppPreferences(
  searchParams: Record<string, SearchParamValue>,
): Promise<AppPreferences> {
  const cookieStore = await cookies();

  const locale = resolveLocale(searchParams.lang ?? cookieStore.get('locale')?.value ?? DEFAULT_LOCALE);
  const theme = resolveTheme(searchParams.theme ?? cookieStore.get('theme')?.value ?? DEFAULT_THEME);

  return {
    locale,
    theme,
    direction: localeDirection[locale],
  };
}
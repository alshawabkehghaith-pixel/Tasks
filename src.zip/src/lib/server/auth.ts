import "server-only";

import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

import { getServerEnv } from "@/lib/config/env";

export const SESSION_COOKIE = "ai_assistant_session";
export const ROLE_COOKIE = "ai_assistant_role";
export const USER_NAME_COOKIE = "ai_assistant_user_name";
export const USER_EMAIL_COOKIE = "ai_assistant_user_email";
export const USER_USERNAME_COOKIE = "ai_assistant_username";

const DEV_AUTH_ENABLED = process.env.DEV_AUTH_ENABLED === "true";

export type AppUser = {
  displayName: string;
  username: string;
  email: string;
  role: "admin" | "user";
};

export type AppSession = {
  token: string;
  role: "admin" | "user";
  user: AppUser;
};

export const getAppSession = cache(async (): Promise<AppSession | null> => {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  const role = cookieStore.get(ROLE_COOKIE)?.value;
  const displayName = cookieStore.get(USER_NAME_COOKIE)?.value;
  const username = cookieStore.get(USER_USERNAME_COOKIE)?.value;
  const email = cookieStore.get(USER_EMAIL_COOKIE)?.value;

  if (!token) return null;

  try {
    const response = await fetch(new URL("/auth/me", getServerEnv().API_BASE_URL), {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    if (response.ok) {
      const user = (await response.json()) as AppUser;
      return { token, role: user.role, user };
    }
    if (response.status === 401) {
      if (DEV_AUTH_ENABLED && token.startsWith("dev-")) {
        const fallbackRole = role === "admin" ? "admin" : "user";
        return {
          token,
          role: fallbackRole,
          user: {
            displayName: displayName || email || "Job Matching User",
            username: username || email || "",
            email: email || "",
            role: fallbackRole,
          },
        };
      }
      return null;
    }

    // Non-401 upstream failure: do not trust cookie claims alone.
    return null;
  } catch {
    // Network / parse errors: fail closed except for explicit local dev tokens.
    if (DEV_AUTH_ENABLED && token.startsWith("dev-")) {
      const fallbackRole = role === "admin" ? "admin" : "user";
      return {
        token,
        role: fallbackRole,
        user: {
          displayName: displayName || email || "Job Matching User",
          username: username || email || "",
          email: email || "",
          role: fallbackRole,
        },
      };
    }
    return null;
  }
});

export async function requireAppSession(locale: string): Promise<AppSession> {
  void locale;
  const session = await getAppSession();
  if (!session) redirect('/login');
  return session;
}

export async function requireAdminSession(locale: string): Promise<AppSession> {
  const session = await requireAppSession(locale);
  if (session.role !== "admin") redirect('/dashboard');
  return session;
}
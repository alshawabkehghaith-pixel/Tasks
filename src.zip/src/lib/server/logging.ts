import "server-only";

import { appendFile, mkdir } from "node:fs/promises";
import path from "node:path";

type LogLevel = "INFO" | "WARNING" | "ERROR";
type LogFields = Record<string, boolean | number | string | null | undefined>;

const logFile = process.env.LOG_FILE ? path.resolve(process.env.LOG_FILE) : null;

const CONSOLE_BY_LEVEL: Record<LogLevel, (message: string, payload: unknown) => void> = {
  INFO: (message, payload) => console.info(message, payload),
  WARNING: (message, payload) => console.warn(message, payload),
  ERROR: (message, payload) => console.error(message, payload),
};

export async function logServerEvent(level: LogLevel, event: string, fields: LogFields = {}): Promise<void> {
  const payload = {
    timestamp: new Date().toISOString(),
    severity: level,
    service: "Job Matching Engine Frontend",
    event,
    ...fields,
  };

  CONSOLE_BY_LEVEL[level](`[frontend:${level}] ${event}`, payload);

  if (!logFile) return;

  try {
    await mkdir(path.dirname(logFile), { recursive: true });
    await appendFile(logFile, `${JSON.stringify(payload)}\n`, "utf8");
  } catch (error) {
    console.error("Unable to write frontend operational log.", error);
  }
}

import "server-only";

import type { NextRequest } from "next/server";
import { getServerEnv } from "@/lib/config/env";
import { logServerEvent } from "@/lib/server/logging";

function forwardedHeaders(request: NextRequest, contentType?: string) {
  const proto = request.headers.get("x-forwarded-proto") ?? request.nextUrl.protocol.replace(":", "");
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? request.nextUrl.host;
  const headers = new Headers({
    "x-forwarded-proto": proto,
    "x-forwarded-host": host,
    "x-forwarded-port": request.headers.get("x-forwarded-port") ?? (proto === "https" ? "443" : "80"),
    host,
  });
  if (contentType) headers.set("content-type", contentType);
  return headers;
}

async function proxy(request: NextRequest, path: string, method: "GET" | "POST") {
  const forwarded = forwardedHeaders(request, method === "POST" ? request.headers.get("content-type") ?? undefined : undefined);
  const apiBase = getServerEnv().API_BASE_URL.replace(/\/$/, "");
  const upstreamUrl = new URL(path + (method === "GET" ? request.nextUrl.search : ""), apiBase);
  const requestDetails = {
    path,
    method,
    upstreamUrl: upstreamUrl.toString(),
  };
  await logServerEvent("INFO", "auth.saml_proxy.forwarding", requestDetails);
  const upstream = await fetch(upstreamUrl, {
    method,
    headers: forwarded,
    body: method === "POST" ? await request.text() : undefined,
    cache: "no-store",
    redirect: "manual",
  });
  const location = upstream.headers.get("location");
  if (location) {
    await logServerEvent("INFO", "auth.saml_proxy.redirect", {
      ...requestDetails,
      upstreamStatus: upstream.status,
    });
    return new Response(null, { status: upstream.status, headers: { Location: location } });
  }
  await logServerEvent("INFO", "auth.saml_proxy.response", {
    ...requestDetails,
    upstreamStatus: upstream.status,
  });
  return new Response(await upstream.text(), {
    status: upstream.status,
    headers: { "Content-Type": upstream.headers.get("content-type") ?? "text/plain" },
  });
}

export const proxySamlGet = (request: NextRequest, path: string) => proxy(request, path, "GET");
export const proxySamlPost = (request: NextRequest, path: string) => proxy(request, path, "POST");

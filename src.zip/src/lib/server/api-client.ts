
import { z } from 'zod';

import { getServerEnv } from '@/lib/config/env';

const DEFAULT_TIMEOUT_MS = 10_000;

function baseUrl(): string {
  return getServerEnv().API_BASE_URL.replace(/\/$/, '');
}

export class ApiError extends Error {
  public readonly status: number;
  public readonly url: string;

  constructor(status: number, message: string, url: string) {
    super(`[${status}] ${message} — ${url}`);
    this.name = 'ApiError';
    this.status = status;
    this.url = url;
  }
}

export async function request<T>(
  path: string,
  init?: Omit<RequestInit, 'signal'>,
  schema?: z.ZodType,
  timeoutMs: number = DEFAULT_TIMEOUT_MS,
): Promise<T> {
  const url = `${baseUrl()}${path}`;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  let response: Response;
  try {
    response = await fetch(url, { ...init, signal: controller.signal });
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new ApiError(504, `Request timed out after ${timeoutMs}ms`, url);
    }
    throw new ApiError(503, error instanceof Error ? error.message : 'Upstream request failed', url);
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {

    let message = response.statusText || 'Request failed';
    try {
      const body = (await response.json()) as Record<string, unknown>;
      if (typeof body.detail === 'string') message = body.detail;
      else if (typeof body.message === 'string') message = body.message;
    } catch {

    }
    throw new ApiError(response.status, message, url);
  }

  const data: unknown = await response.json();

  if (schema) {
    const result = schema.safeParse(data);
    if (!result.success) {
      const detail = result.error.message;
      console.error(`[api-client] Schema validation failed for ${path}`, result.error);
      throw new ApiError(502, `Schema validation failed for ${path}: ${detail}`, url);
    }
    return result.data as T;
  }

  return data as T;
}

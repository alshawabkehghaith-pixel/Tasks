/** Shared Lucide stroke weight — keep icons stylistically consistent app-wide. */
export const ICON_STROKE = 1.75;
export const ICON_STROKE_BOLD = 2.1;

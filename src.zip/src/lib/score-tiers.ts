
export const SCORE_TIER = {
  STRONG_MIN: 80,
  GOOD_MIN: 60,
} as const;

export type ScoreTierName = 'strong' | 'good' | 'fair';

export function getScoreTier(score: number): ScoreTierName {
  if (score >= SCORE_TIER.STRONG_MIN) return 'strong';
  if (score >= SCORE_TIER.GOOD_MIN) return 'good';
  return 'fair';
}

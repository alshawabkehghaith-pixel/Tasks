import type { ReportPeriod } from '@/types/domain';
import { DASHBOARD_PERIOD_COOKIE } from '@/lib/auth-state';
import { resolvePeriod } from '@/lib/api/jadarat';

const PERIOD_COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;

export function readDashboardPeriodCookie(value: string | undefined | null): ReportPeriod {
  return resolvePeriod(value ?? undefined);
}

export function writeDashboardPeriodCookie(period: ReportPeriod): void {
  if (typeof window === 'undefined') {
    return;
  }

  const secure = window.location.protocol === 'https:' ? '; secure' : '';
  document.cookie =
    `${DASHBOARD_PERIOD_COOKIE}=${encodeURIComponent(period)}; path=/; max-age=${PERIOD_COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;
}

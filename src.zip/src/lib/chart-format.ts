
export function formatChartLabel(value: unknown): string {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value.toLocaleString();
  }

  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed.toLocaleString() : value;
  }

  return '';
}

/** Append ﷼ after the band so RTL currency glyphs don't land between Latin numerals. */
export function formatSalaryBandLabel(label: string): string {
  const trimmed = label.trim();
  if (!trimmed || trimmed.includes('﷼')) return trimmed;
  // LRM keeps the whole tick in a stable LTR order (e.g. "8k-12k ﷼").
  return `\u200E${trimmed}\u00A0﷼`;
}

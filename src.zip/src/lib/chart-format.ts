export function formatChartLabel(value: unknown): string {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value.toLocaleString();
  }

  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed.toLocaleString() : value;
  }

  return '';
}

export function formatSalaryBandLabel(label: string): string {
  const trimmed = label.trim();
  if (!trimmed || trimmed.includes('﷼')) return trimmed;
  return `\u200E${trimmed}\u00A0﷼`;
}

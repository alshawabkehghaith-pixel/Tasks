export const LOCALE_COOKIE = 'locale';
export const THEME_COOKIE = 'theme';
export const LOGIN_RETURN_TO_COOKIE = 'jme_return_to';
export const DASHBOARD_PERIOD_COOKIE = 'jme_dash_period';

export function sanitizeReturnTo(target: string | null | undefined, fallback = '/dashboard'): string {
  if (!target) return fallback;
  return target.startsWith('/') && !target.startsWith('//') ? target : fallback;
}
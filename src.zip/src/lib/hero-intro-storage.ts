const DASHBOARD_HERO_INTRO_STORAGE_KEY = 'jme.dashboardHeroIntroSeen';

/** Readable on the server via `cookies()` so return visits never SSR the full intro. */
export const DASHBOARD_HERO_INTRO_COOKIE = 'jme_dash_hero_intro';

const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 400;

function isBrowser(): boolean {
  return typeof window !== 'undefined';
}

function readCookie(name: string): string | null {
  if (!isBrowser()) {
    return null;
  }

  const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

function writeCookie(name: string, value: string): void {
  if (!isBrowser()) {
    return;
  }

  const secure = window.location.protocol === 'https:' ? '; secure' : '';
  document.cookie =
    `${name}=${encodeURIComponent(value)}; path=/; max-age=${COOKIE_MAX_AGE_SECONDS}; samesite=lax${secure}`;
}

function clearCookie(name: string): void {
  if (!isBrowser()) {
    return;
  }

  const secure = window.location.protocol === 'https:' ? '; secure' : '';
  document.cookie = `${name}=; path=/; max-age=0; samesite=lax${secure}`;
}

export function hasSeenDashboardHeroIntroCookie(value: string | undefined | null): boolean {
  return value === '1';
}

export function hasSeenDashboardHeroIntro(): boolean {
  if (!isBrowser()) {
    return false;
  }

  try {
    if (window.localStorage.getItem(DASHBOARD_HERO_INTRO_STORAGE_KEY) === '1') {
      return true;
    }
  } catch {
    // ignore storage failures
  }

  return hasSeenDashboardHeroIntroCookie(readCookie(DASHBOARD_HERO_INTRO_COOKIE));
}

export function markDashboardHeroIntroSeen(): void {
  if (!isBrowser()) {
    return;
  }

  try {
    window.localStorage.setItem(DASHBOARD_HERO_INTRO_STORAGE_KEY, '1');
  } catch {
    // ignore storage failures
  }

  writeCookie(DASHBOARD_HERO_INTRO_COOKIE, '1');
}

export function clearDashboardHeroIntroSeen(): void {
  if (!isBrowser()) {
    return;
  }

  try {
    window.localStorage.removeItem(DASHBOARD_HERO_INTRO_STORAGE_KEY);
  } catch {
    // ignore storage failures
  }

  clearCookie(DASHBOARD_HERO_INTRO_COOKIE);
}

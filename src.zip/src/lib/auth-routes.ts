import type { QueryInput } from '@/lib/routing';

function configured(value: string | undefined, fallback: string): string {
  const trimmed = value?.trim();
  return trimmed ? trimmed : fallback;
}

export const DEV_AUTH_ENABLED = process.env.DEV_AUTH_ENABLED === 'true';
export function getAuthLoginEndpoint(): string {
  return configured(process.env.AUTH_LOGIN_ENDPOINT, '/api/auth/login');
}

export function getAuthDevLoginEndpoint(): string {
  return configured(process.env.AUTH_DEV_LOGIN_ENDPOINT, '/api/auth/dev-login');
}

export function getAuthLogoutEndpoint(): string {
  return configured(process.env.AUTH_LOGOUT_ENDPOINT, '/api/auth/logout');
}

export function buildDevLoginHref(locale: 'ar' | 'en', returnTo: string): string {
  void locale;
  void returnTo;
  return getAuthDevLoginEndpoint();
}

export function buildSsoLoginHref(locale: 'ar' | 'en', returnTo: string): string {
  void locale;
  void returnTo;
  return getAuthLoginEndpoint();
}

export function buildLogoutHref(locale: 'ar' | 'en', current: QueryInput): string {
  void locale;
  void current;
  return getAuthLogoutEndpoint();
}

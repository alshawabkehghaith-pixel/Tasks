export type PagerToken = number | 'gap';

export function buildPagerTokens(current: number, total: number, siblingCount = 1): PagerToken[] {
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1);
  }

  const left = Math.max(2, current - siblingCount);
  const right = Math.min(total - 1, current + siblingCount);
  const tokens: PagerToken[] = [1];

  if (left > 2) {
    tokens.push('gap');
  }

  for (let n = left; n <= right; n += 1) {
    tokens.push(n);
  }

  if (right < total - 1) {
    tokens.push('gap');
  }

  tokens.push(total);
  return tokens;
}

export function parsePositivePage(raw: string | undefined, fallback = 1): number {
  const parsed = Number.parseInt(raw || String(fallback), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}


import { z } from 'zod';

function looseObject<T extends z.ZodRawShape>(shape: T) {
  return z.object(shape).passthrough();
}

const readiness = z.enum(['ready', 'partial', 'incomplete']);
const jobLevel = z.enum(['entry', 'mid', 'senior']);
const impactLevel = z.enum(['high', 'medium', 'low']);
const queueBand = z.enum(['priority', 'secondary']);
const notificationChannel = z.enum(['email']);
const activityStatus = z.enum(['sent', 'not_sent']);
const matchVerdict = z.enum(['approved', 'rejected']);
const coverageLevel = z.enum(['good', 'moderate', 'gap', 'surplus']);

const CandidateIdentitySchema = looseObject({
  nin: z.string(),
  name: z.string(),
  region: z.string(),
});

const CandidateHeadlineSchema = CandidateIdentitySchema.extend({
  city: z.string(),
  occupationalField: z.string(),
  octoberBatch: z.boolean(),
  freshGraduate: z.boolean(),
  readiness,
}).passthrough();

const LabelCountSchema = looseObject({
  label: z.string(),
  count: z.number(),
});

const LabelValueSchema = looseObject({
  label: z.string(),
  value: z.number(),
});

const DateSchema = looseObject({
  date: z.string(),
});

const TimelinePointSchema = DateSchema.extend({
  reviews: z.number(),
  approvals: z.number(),
  notifications: z.number(),
}).passthrough();

function paginated<T extends z.ZodTypeAny>(itemSchema: T) {
  return looseObject({
    rows: z.array(itemSchema),
    total: z.number(),
    page: z.number(),
    pageSize: z.number(),
  });
}

export const DashboardKPIsSchema = looseObject({
  candidates: z.number(),
  employers: z.number(),
  activeJobs: z.number(),
  openPositions: z.number(),
  matchesCreated: z.number(),
  strongMatches: z.number(),
  avgMatchScore: z.number(),
});

export const ReadinessBreakdownSchema = looseObject({
  readyPct: z.number(),
  ready: z.number(),
  partial: z.number(),
  incomplete: z.number(),
  recentGrads: z.number(),
});

export const DashboardSnapshotSchema = looseObject({
  period: z.enum(['7', '30', '90']),
  kpis: DashboardKPIsSchema,
  readiness: ReadinessBreakdownSchema,
  followUp: z.array(looseObject({ field: z.string(), count: z.number() })),
  funnel: z.array(LabelCountSchema.extend({ conversionPct: z.number().optional() }).passthrough()),
  talentPipeline: looseObject({
    matched: z.number(),
    highMatch: z.number(),
    reviewed: z.number(),
    approved: z.number(),
    notified: z.number(),
  }),
  supplyDemand: z.array(looseObject({ category: z.string(), demand: z.number(), supply: z.number(), coverage: coverageLevel })),
  scoreBands: z.array(looseObject({ range: z.string(), count: z.number() })),
  timeline: z.array(TimelinePointSchema),
  jobsBySalary: z.array(LabelValueSchema),
});

export const CandidateSummarySchema = CandidateHeadlineSchema.extend({
  qualification: z.string(),
  yearsExperience: z.number(),
  jobLevel,
  status: z.string(),
  age: z.number(),
  gender: z.string(),
  score: z.number(),
  topMatchScore: z.number(),
  updatedAt: z.string(),
  matchCount: z.number(),
}).passthrough();

export const PaginatedCandidateSummarySchema = paginated(CandidateSummarySchema);

export const CandidateOutreachSearchSchema = CandidateSummarySchema.array();

export const CandidateRegionsSchema = looseObject({
  regions: z.array(z.string()),
});

export const CandidateFacetsSchema = looseObject({
  readiness: z.array(readiness),
  regions: z.array(z.string()),
  cities: z.array(z.string()),
  genders: z.array(z.string()),
  ages: z.array(z.number()),
  qualifications: z.array(z.string()),
  occupationalFields: z.array(z.string()),
  yearsExperience: z.array(z.number()),
  statuses: z.array(z.string()),
  octoberBatch: z.array(z.boolean()),
  freshGraduate: z.array(z.boolean()),
});

export const EmployerFacetsSchema = looseObject({
  sectors: z.array(z.string()),
  sizes: z.array(z.string()),
  regions: z.array(z.string()),
});

export const JobLevelBatchSchema = looseObject({
  key: jobLevel,
  label: z.string(),
  count: z.number(),
});

export const JobLevelBatchesSchema = JobLevelBatchSchema.array();

const batchType = z.enum(['octoberBatch', 'freshGraduate']);

export const BatchTypeBatchSchema = looseObject({
  key: batchType,
  label: z.string(),
  count: z.number(),
});

export const BatchTypeBatchesSchema = BatchTypeBatchSchema.array();

export const CandidateBatchPreviewSchema = looseObject({
  count: z.number(),
});

export const VerificationCandidateRowSchema = CandidateIdentitySchema.extend({
  city: z.string(),
  occupationalField: z.string(),
  octoberBatch: z.boolean(),
  freshGraduate: z.boolean(),
  topMatchScore: z.number(),
  matchCount: z.number(),
}).passthrough();

export const VerificationBatchResultSchema = looseObject({
  batchTotal: z.number(),
  rows: paginated(VerificationCandidateRowSchema),
});

export const VerificationFacetsSchema = looseObject({
  regions: z.array(z.string()),
  levels: JobLevelBatchesSchema,
});

export const SuggestedJobSchema = looseObject({
  id: z.string(),
  jobTitle: z.string(),
  employer: z.string(),
  location: z.string(),
  matchPct: z.number(),
  explanation: z.string(),
});

export const PaginatedSuggestedJobSchema = paginated(SuggestedJobSchema);

export const CandidateProfileSchema = CandidateHeadlineSchema.extend({
  age: z.number(),
  readinessScore: z.number(),
  yearsExperience: z.number(),
  gender: z.string(),
  qualification: z.string(),
  jobLevel,
  status: z.string(),
  topMatchScore: z.number(),
  updatedAt: z.string(),
  readinessDrivers: z.array(looseObject({
    id: z.string(),
    field: z.string(),
    impact: impactLevel,
    points: z.number(),
    updatedAt: z.string(),
  })),
  strengths: z.array(looseObject({
    id: z.string(),
    label: z.string(),
    updatedAt: z.string(),
  })),
  matches: z.array(looseObject({
    id: z.string(),
    candidateNin: z.string(),
    jobId: z.string(),
    jobTitle: z.string(),
    employer: z.string(),
    usoc: z.string(),
    score: z.number(),
    explanation: z.string(),
    verdict: matchVerdict.nullable(),
    createdAt: z.string(),
  })),
}).passthrough();

export const EmployerSummarySchema = looseObject({
  id: z.string(),
  name: z.string(),
  sector: z.string(),
  size: z.string(),
  region: z.string(),
  city: z.string(),
  jobs: z.number(),
  activeJobs: z.number(),
  openPositions: z.number(),
});

export const PaginatedEmployerSummarySchema = paginated(EmployerSummarySchema);

export const EmployerJobSchema = looseObject({
  id: z.string(),
  employerId: z.string(),
  title: z.string(),
  status: z.enum(['active', 'inactive']),
  openings: z.number(),
  matchedCandidates: z.number(),
  salaryBand: z.string(),
  updatedAt: z.string(),
  closedAt: z.string().nullable(),
});

export const EmployerProfileSchema = looseObject({
  id: z.string(),
  name: z.string(),
  sector: z.string(),
  size: z.string(),
  region: z.string(),
  city: z.string(),
  jobs: z.number(),
  sizeLabel: z.string(),
  updatedAt: z.string(),
  jobsPosted: z.number(),
  activeJobs: z.number(),
  openPositions: z.number(),
  matchedCandidates: z.number(),
  bySalary: z.array(LabelCountSchema),
  postedJobs: paginated(EmployerJobSchema),
});

export const QueueEntrySchema = looseObject({
  nin: z.string(),
  jobId: z.string(),
  candidateName: z.string(),
  jobTitle: z.string(),
  employer: z.string(),
  score: z.number(),
  band: queueBand,
  city: z.string(),
  readiness,
  employerSector: z.string(),
  roles: z.array(z.string()),
  experienceYears: z.number(),
  explanation: z.string(),
  skills: z.array(z.string()),
});

export const ActivityEntrySchema = looseObject({
  candidateName: z.string(),
  jobTitle: z.string(),
  channel: notificationChannel,
  status: activityStatus,
  timestamp: z.string(),
});

export const PaginatedActivitySchema = paginated(ActivityEntrySchema);

const campaignPurpose = z.enum(['vacancy', 'completeness']);
const campaignNotificationStatus = z.enum(['sent', 'not_sent']);

export const CampaignSummarySchema = looseObject({
  id: z.number(),
  createdBy: z.string(),
  purpose: campaignPurpose,
  candidateCount: z.number(),
  channel: z.string(),
  sentAt: z.string(),
});

export const PaginatedCampaignSummarySchema = paginated(CampaignSummarySchema);

export const CampaignCandidateRowSchema = looseObject({
  rowId: z.number(),
  nin: z.string(),
  candidateName: z.string(),
  jobId: z.string(),
  jobTitle: z.string(),
  employer: z.string(),
  matchScore: z.number(),
  notificationStatus: campaignNotificationStatus,
  notifiedAt: z.string(),
});

export const CampaignDetailSchema = looseObject({
  header: CampaignSummarySchema,
  rows: z.array(CampaignCandidateRowSchema),
  total: z.number(),
  page: z.number(),
  pageSize: z.number(),
});

export const UserDecisionSchema = looseObject({
  id: z.number(),
  nin: z.string(),
  candidateName: z.string(),
  jobTitle: z.string(),
  verdict: matchVerdict,
  reasonKey: z.string().nullable(),
  decidedAt: z.string(),
});

export const PaginatedUserDecisionSchema = paginated(UserDecisionSchema);

export const ReportsSnapshotSchema = looseObject({
  throughput: looseObject({
    reviewed: z.number(),
    approved: z.number(),
    rejected: z.number(),
    approvalRate: z.number(),
  }),
  timeline: z.array(TimelinePointSchema),
  pending: z.number(),
  approvedToday: z.array(CandidateIdentitySchema.extend({ jobTitle: z.string(), score: z.number() }).passthrough()),
});

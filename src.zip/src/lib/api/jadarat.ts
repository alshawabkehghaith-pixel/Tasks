import { localeDirection } from '@/i18n/config';
import type { ReportPeriod as DomainReportPeriod } from '@/types/domain';
import type { AppPreferences, Locale, ThemeMode } from '@/types/jadarat';

export const DEFAULT_LOCALE: Locale = 'ar';
export const DEFAULT_THEME: ThemeMode = 'dark';

export function resolveLocale(value: string | string[] | undefined): Locale {
  const candidate = Array.isArray(value) ? value[0] : value;
  return candidate === 'en' ? 'en' : DEFAULT_LOCALE;
}

export function resolveTheme(value: string | string[] | undefined): ThemeMode {
  const candidate = Array.isArray(value) ? value[0] : value;
  return candidate === 'light' ? 'light' : DEFAULT_THEME;
}

export function resolvePeriod(value: string | string[] | undefined): DomainReportPeriod {
  const candidate = Array.isArray(value) ? value[0] : value;
  return candidate === '7' || candidate === '90' ? candidate : '30';
}

export function getAppPreferences(searchParams: Record<string, string | string[] | undefined>): AppPreferences {
  const locale = resolveLocale(searchParams.lang);
  const theme = resolveTheme(searchParams.theme);
  return {
    locale,
    theme,
    direction: localeDirection[locale],
  };
}

export function localizeText(text: { ar: string; en: string }, locale: Locale): string {
  return text[locale] ?? text.ar;
}


import type {
  ActivityEntry,
  ActivityQuery,
  BatchTypeBatch,
  CandidateBatchPreviewQuery,
  CandidateProfile,
  CandidateQuery,
  CandidateSummary,
  CampaignCandidateRow,
  CampaignDetail,
  CampaignDetailQuery,
  CampaignQuery,
  CampaignSummary,
  DecisionQuery,
  UserDecision,
  DashboardQuery,
  DashboardSnapshot,
  EmployerProfile,
  EmployerQuery,
  EmployerSummary,
  JobLevelBatch,
  Paginated,
  QueueEntry,
  ReportsQuery,
  ReportsSnapshot,
  SuggestedJob,
  SuggestedJobsQuery,
  VerificationBatchQuery,
  VerificationBatchResult,
  VerificationFacets,
  CandidateFacets,
  EmployerFacets,
} from '@/types/domain';
import { USE_MOCK } from '@/lib/config/flags';
import { request as apiRequest, ApiError } from '@/lib/server/api-client';
import {
  BatchTypeBatchesSchema,
  CampaignDetailSchema,
  CandidateBatchPreviewSchema,
  CandidateFacetsSchema,
  CandidateOutreachSearchSchema,
  CandidateProfileSchema,
  CandidateRegionsSchema,
  DashboardSnapshotSchema,
  EmployerProfileSchema,
  JobLevelBatchesSchema,
  PaginatedActivitySchema,
  PaginatedCampaignSummarySchema,
  PaginatedUserDecisionSchema,
  PaginatedCandidateSummarySchema,
  PaginatedEmployerSummarySchema,
  PaginatedSuggestedJobSchema,
  QueueEntrySchema,
  ReportsSnapshotSchema,
  VerificationBatchResultSchema,
  VerificationFacetsSchema,
} from '@/lib/api/schemas';

const DEFAULT_PAGE_SIZE = 25;
const MAX_PAGE_SIZE = 100;
const FACET_OPTION_CAP = 200;
const USE_HARDCODED_MOCK = USE_MOCK;

function clampPageSize(pageSize?: number, fallback: number = DEFAULT_PAGE_SIZE): number {
  const raw = pageSize ?? fallback;
  if (!Number.isFinite(raw)) return fallback;
  return Math.min(MAX_PAGE_SIZE, Math.max(1, Math.floor(raw)));
}

function capFacetList<T>(values: T[]): T[] {
  return values.slice(0, FACET_OPTION_CAP);
}

const MOCK_CANDIDATES: CandidateSummary[] = [
  {
    nin: '1000000001',
    name: 'Ahmed Al-Qahtani',
    region: 'Riyadh',
    city: 'Riyadh',
    qualification: 'Bachelor',
    occupationalField: 'Software Engineering',
    yearsExperience: 4,
    jobLevel: 'mid',
    status: 'unemployed',
    age: 27,
    gender: 'male',
    octoberBatch: true,
    freshGraduate: false,
    readiness: 'ready',
    score: 88,
    topMatchScore: 92,
    updatedAt: '2026-07-20T09:00:00.000Z',
    matchCount: 2,
  },
  {
    nin: '1000000002',
    name: 'Sara Al-Harbi',
    region: 'Makkah',
    city: 'Jeddah',
    qualification: 'Master',
    occupationalField: 'Data Analysis',
    yearsExperience: 2,
    jobLevel: 'entry',
    status: 'unemployed',
    age: 24,
    gender: 'female',
    octoberBatch: false,
    freshGraduate: true,
    readiness: 'partial',
    score: 73,
    topMatchScore: 81,
    updatedAt: '2026-07-19T11:30:00.000Z',
    matchCount: 2,
  },
  {
    nin: '1000000003',
    name: 'Faisal Al-Dossari',
    region: 'Eastern',
    city: 'Dammam',
    qualification: 'Diploma',
    occupationalField: 'Customer Service',
    yearsExperience: 6,
    jobLevel: 'senior',
    status: 'employed',
    age: 31,
    gender: 'male',
    octoberBatch: true,
    freshGraduate: false,
    readiness: 'incomplete',
    score: 61,
    topMatchScore: 68,
    updatedAt: '2026-07-18T15:20:00.000Z',
    matchCount: 1,
  },
];

const MOCK_CANDIDATE_PROFILES: Record<string, CandidateProfile> = {
  '1000000001': {
    nin: '1000000001',
    name: 'Ahmed Al-Qahtani',
    region: 'Riyadh',
    city: 'Riyadh',
    occupationalField: 'Software Engineering',
    octoberBatch: true,
    freshGraduate: false,
    readiness: 'ready',
    gender: 'male',
    age: 27,
    qualification: 'Bachelor',
    yearsExperience: 4,
    jobLevel: 'mid',
    status: 'unemployed',
    readinessScore: 88,
    topMatchScore: 92,
    updatedAt: '2026-07-20T09:00:00.000Z',
    readinessDrivers: [
      {
        id: 'rd-1',
        field: 'Experience quality',
        impact: 'high',
        points: 20,
        updatedAt: '2026-07-20T09:00:00.000Z',
      },
    ],
    strengths: [
      { id: 'st-1', label: 'React', updatedAt: '2026-07-20T09:00:00.000Z' },
      { id: 'st-2', label: 'Node.js', updatedAt: '2026-07-20T09:00:00.000Z' },
    ],
    matches: [
      {
        id: 'm-1',
        candidateNin: '1000000001',
        jobId: 'JOB-100',
        jobTitle: 'Frontend Developer',
        employer: 'Future Tech LLC',
        usoc: '2512',
        score: 92,
        explanation: 'Strong alignment with required frontend stack.',
        verdict: null,
        createdAt: '2026-07-20T09:00:00.000Z',
      },
      {
        id: 'm-2',
        candidateNin: '1000000001',
        jobId: 'JOB-101',
        jobTitle: 'Full Stack Engineer',
        employer: 'Future Tech LLC',
        usoc: '2513',
        score: 84,
        explanation: 'Good backend and frontend fundamentals.',
        verdict: 'approved',
        createdAt: '2026-07-19T08:00:00.000Z',
      },
    ],
  },
  '1000000002': {
    nin: '1000000002',
    name: 'Sara Al-Harbi',
    region: 'Makkah',
    city: 'Jeddah',
    occupationalField: 'Data Analysis',
    octoberBatch: false,
    freshGraduate: true,
    readiness: 'partial',
    gender: 'female',
    age: 24,
    qualification: 'Master',
    yearsExperience: 2,
    jobLevel: 'entry',
    status: 'unemployed',
    readinessScore: 73,
    topMatchScore: 81,
    updatedAt: '2026-07-19T11:30:00.000Z',
    readinessDrivers: [
      {
        id: 'rd-2',
        field: 'Certification completion',
        impact: 'medium',
        points: 12,
        updatedAt: '2026-07-19T11:30:00.000Z',
      },
    ],
    strengths: [{ id: 'st-3', label: 'SQL', updatedAt: '2026-07-19T11:30:00.000Z' }],
    matches: [
      {
        id: 'm-3',
        candidateNin: '1000000002',
        jobId: 'JOB-200',
        jobTitle: 'Junior Data Analyst',
        employer: 'Insights Co',
        usoc: '2421',
        score: 81,
        explanation: 'Good analytical foundation and reporting skills.',
        verdict: null,
        createdAt: '2026-07-19T11:30:00.000Z',
      },
      {
        id: 'm-4',
        candidateNin: '1000000002',
        jobId: 'JOB-201',
        jobTitle: 'BI Associate',
        employer: 'Insights Co',
        usoc: '2421',
        score: 76,
        explanation: 'Matches dashboarding and KPI tracking requirements.',
        verdict: 'rejected',
        createdAt: '2026-07-17T10:00:00.000Z',
      },
    ],
  },
  '1000000003': {
    nin: '1000000003',
    name: 'Faisal Al-Dossari',
    region: 'Eastern',
    city: 'Dammam',
    occupationalField: 'Customer Service',
    octoberBatch: true,
    freshGraduate: false,
    readiness: 'incomplete',
    gender: 'male',
    age: 31,
    qualification: 'Diploma',
    yearsExperience: 6,
    jobLevel: 'senior',
    status: 'employed',
    readinessScore: 61,
    topMatchScore: 68,
    updatedAt: '2026-07-18T15:20:00.000Z',
    readinessDrivers: [
      {
        id: 'rd-3',
        field: 'Profile completeness',
        impact: 'high',
        points: 8,
        updatedAt: '2026-07-18T15:20:00.000Z',
      },
    ],
    strengths: [{ id: 'st-4', label: 'Team leadership', updatedAt: '2026-07-18T15:20:00.000Z' }],
    matches: [
      {
        id: 'm-5',
        candidateNin: '1000000003',
        jobId: 'JOB-300',
        jobTitle: 'Contact Center Supervisor',
        employer: 'Care Connect',
        usoc: '3342',
        score: 68,
        explanation: 'Relevant operations and service background.',
        verdict: null,
        createdAt: '2026-07-18T15:20:00.000Z',
      },
    ],
  },
};

const MOCK_EMPLOYERS: EmployerSummary[] = [
  {
    id: 'EMP-1',
    name: 'Future Tech LLC',
    sector: 'Technology',
    size: 'Medium',
    region: 'Riyadh',
    city: 'Riyadh',
    jobs: 6,
    activeJobs: 5,
    openPositions: 14,
  },
  {
    id: 'EMP-2',
    name: 'Insights Co',
    sector: 'Analytics',
    size: 'Small',
    region: 'Makkah',
    city: 'Jeddah',
    jobs: 3,
    activeJobs: 2,
    openPositions: 5,
  },
];

const MOCK_EMPLOYER_PROFILES: Record<string, EmployerProfile> = {
  'EMP-1': {
    id: 'EMP-1',
    name: 'Future Tech LLC',
    sector: 'Technology',
    size: 'Medium',
    region: 'Riyadh',
    city: 'Riyadh',
    jobs: 6,
    sizeLabel: 'Medium',
    updatedAt: '2026-07-20T09:00:00.000Z',
    jobsPosted: 6,
    activeJobs: 5,
    openPositions: 14,
    matchedCandidates: 19,
    bySalary: [
      { label: '4k-6k', count: 2 },
      { label: '6k-8k', count: 3 },
      { label: '8k-12k', count: 1 },
    ],
    postedJobs: {
      rows: [
        {
          id: 'JOB-100',
          employerId: 'EMP-1',
          title: 'Frontend Developer',
          status: 'active',
          openings: 4,
          matchedCandidates: 11,
          salaryBand: '8k-12k',
          updatedAt: '2026-07-20T09:00:00.000Z',
          closedAt: null,
        },
      ],
      total: 1,
      page: 1,
      pageSize: DEFAULT_PAGE_SIZE,
    },
  },
  'EMP-2': {
    id: 'EMP-2',
    name: 'Insights Co',
    sector: 'Analytics',
    size: 'Small',
    region: 'Makkah',
    city: 'Jeddah',
    jobs: 3,
    sizeLabel: 'Small',
    updatedAt: '2026-07-19T11:30:00.000Z',
    jobsPosted: 3,
    activeJobs: 2,
    openPositions: 5,
    matchedCandidates: 8,
    bySalary: [
      { label: '4k-6k', count: 2 },
      { label: '6k-8k', count: 1 },
    ],
    postedJobs: {
      rows: [
        {
          id: 'JOB-200',
          employerId: 'EMP-2',
          title: 'Junior Data Analyst',
          status: 'active',
          openings: 3,
          matchedCandidates: 6,
          salaryBand: '6k-8k',
          updatedAt: '2026-07-19T11:30:00.000Z',
          closedAt: null,
        },
      ],
      total: 1,
      page: 1,
      pageSize: DEFAULT_PAGE_SIZE,
    },
  },
};

const MOCK_QUEUE: QueueEntry[] = [
  {
    nin: '1000000001',
    jobId: 'JOB-100',
    candidateName: 'Ahmed Al-Qahtani',
    jobTitle: 'Frontend Developer',
    employer: 'Future Tech LLC',
    score: 92,
    band: 'priority',
    experienceYears: 4,
    city: 'Riyadh',
    readiness: 'ready',
    employerSector: 'Technology',
    roles: ['frontend', 'react'],
    explanation: 'Strong fit for the role requirements.',
    skills: ['React', 'TypeScript'],
  },
];

const MOCK_ACTIVITY: ActivityEntry[] = [
  {
    candidateName: 'Ahmed Al-Qahtani',
    jobTitle: 'Frontend Developer',
    channel: 'email',
    status: 'sent',
    timestamp: '2026-07-20T09:30:00.000Z',
  },
  {
    candidateName: 'Sara Al-Harbi',
    jobTitle: 'Junior Data Analyst',
    channel: 'email',
    status: 'sent',
    timestamp: '2026-07-19T12:00:00.000Z',
  },
];

const MOCK_REPORTS: ReportsSnapshot = {
  throughput: { reviewed: 34, approved: 20, rejected: 14, approvalRate: 58.8 },
  timeline: [
    { date: '2026-07-18', reviews: 8, approvals: 5, notifications: 4 },
    { date: '2026-07-19', reviews: 12, approvals: 7, notifications: 6 },
    { date: '2026-07-20', reviews: 14, approvals: 8, notifications: 7 },
  ],
  pending: 9,
  approvedToday: [{ nin: '1000000001', name: 'Ahmed Al-Qahtani', jobTitle: 'Frontend Developer', score: 92 }],
};

const MOCK_DASHBOARD: DashboardSnapshot = {
  period: '30',
  kpis: {
    candidates: 3,
    candidatesReadyPct: 33.3,
    employers: 2,
    activeJobs: 7,
    openPositions: 19,
    matchesCreated: 5,
    strongMatches: 2,
    avgMatchScore: 80.3,
  },
  readiness: { readyPct: 33.3, ready: 1, partial: 1, incomplete: 1, recentGrads: 1 },
  followUp: [
    { field: 'Resume completeness', count: 1 },
    { field: 'Contact information', count: 1 },
  ],
  funnel: [
    { label: 'Matched', count: 5 },
    { label: 'Reviewed', count: 3, conversionPct: 60 },
    { label: 'Approved', count: 2, conversionPct: 66.7 },
  ],
  talentPipeline: { matched: 5, highMatch: 2, reviewed: 3, approved: 2, notified: 2 },
  supplyDemand: [
    { category: 'Software', demand: 12, supply: 8, coverage: 'moderate' },
    { category: 'Data', demand: 8, supply: 7, coverage: 'good' },
  ],
  scoreBands: [
    { range: '0-49', count: 0 },
    { range: '50-69', count: 1 },
    { range: '70-84', count: 2 },
    { range: '85-100', count: 2 },
  ],
  timeline: MOCK_REPORTS.timeline,
  jobsBySalary: [
    { label: '4k-6k', value: 4 },
    { label: '6k-8k', value: 4 },
    { label: '8k-12k', value: 2 },
  ],
};

const MOCK_CAMPAIGNS: CampaignDetail[] = [
  {
    header: {
      id: 101,
      createdBy: 'Dev User',
      purpose: 'vacancy',
      candidateCount: 2,
      channel: 'email',
      sentAt: '2026-07-20T09:40:00.000Z',
    },
    rows: [
      {
        rowId: 1,
        nin: '1000000001',
        candidateName: 'Ahmed Al-Qahtani',
        jobId: 'JOB-100',
        jobTitle: 'Frontend Developer',
        employer: 'Future Tech LLC',
        matchScore: 92,
        notificationStatus: 'sent',
        notifiedAt: '2026-07-20T09:40:00.000Z',
      },
    ],
    total: 1,
    page: 1,
    pageSize: DEFAULT_PAGE_SIZE,
  },
  {
    header: {
      id: 102,
      createdBy: 'Dev User',
      purpose: 'completeness',
      candidateCount: 1,
      channel: 'email',
      sentAt: '2026-07-19T12:00:00.000Z',
    },
    rows: [
      {
        rowId: 2,
        nin: '1000000002',
        candidateName: 'Sara Al-Harbi',
        jobId: 'JOB-200',
        jobTitle: 'Junior Data Analyst',
        employer: 'Insights Co',
        matchScore: 81,
        notificationStatus: 'sent',
        notifiedAt: '2026-07-19T12:00:00.000Z',
      },
    ],
    total: 1,
    page: 1,
    pageSize: DEFAULT_PAGE_SIZE,
  },
];

function paginate<T>(rows: T[], page?: number, pageSize?: number): Paginated<T> {
  const safePage = Math.max(1, page ?? 1);
  const safePageSize = clampPageSize(pageSize);
  const start = (safePage - 1) * safePageSize;
  return {
    rows: rows.slice(start, start + safePageSize),
    total: rows.length,
    page: safePage,
    pageSize: safePageSize,
  };
}

function containsText(value: string, search: string): boolean {
  return value.toLowerCase().includes(search.toLowerCase());
}

function filterCandidates(query: CandidateQuery): CandidateSummary[] {
  return MOCK_CANDIDATES.filter((c) => {
    if (query.search?.trim()) {
      const q = query.search.trim();
      if (!containsText(c.name, q) && !containsText(c.nin, q) && !containsText(c.occupationalField, q)) return false;
    }
    if (query.region?.length && !query.region.includes(c.region)) return false;
    if (query.city?.length && !query.city.includes(c.city)) return false;
    if (query.gender?.length && !query.gender.includes(c.gender)) return false;
    if (query.age?.length && !query.age.includes(c.age)) return false;
    if (query.qualification?.length && !query.qualification.includes(c.qualification)) return false;
    if (query.occupationalField?.length && !query.occupationalField.includes(c.occupationalField)) return false;
    if (query.yearsExperience?.length && !query.yearsExperience.includes(c.yearsExperience)) return false;
    if (query.status?.length && !query.status.includes(c.status)) return false;
    if (query.octoberBatch?.length && !query.octoberBatch.includes(c.octoberBatch)) return false;
    if (query.freshGraduate?.length && !query.freshGraduate.includes(c.freshGraduate)) return false;
    if (query.readiness?.length && !query.readiness.includes(c.readiness)) return false;
    return true;
  });
}

function filterCandidatesWithCustomFilters(filters: VerificationBatchQuery['customFilters']): CandidateSummary[] {
  if (!filters) return [];
  return MOCK_CANDIDATES.filter((c) => {
    if (filters.regions.length && !filters.regions.includes(c.region)) return false;
    if (filters.cities.length && !filters.cities.includes(c.city)) return false;
    if (filters.genders.length && !filters.genders.includes(c.gender)) return false;
    if (filters.ages.length && !filters.ages.includes(c.age)) return false;
    if (filters.qualifications.length && !filters.qualifications.includes(c.qualification)) return false;
    if (filters.occupationalFields.length && !filters.occupationalFields.includes(c.occupationalField)) return false;
    if (filters.yearsExperience.length && !filters.yearsExperience.includes(c.yearsExperience)) return false;
    if (filters.statuses.length && !filters.statuses.includes(c.status)) return false;
    if (filters.readiness.length && !filters.readiness.includes(c.readiness)) return false;
    return true;
  });
}

function getMockVerificationBase(query: VerificationBatchQuery): CandidateSummary[] {
  if (query.mode === 'candidates') {
    const set = new Set(query.nins ?? []);
    return MOCK_CANDIDATES.filter((c) => set.has(c.nin));
  }
  if (query.mode === 'levels') {
    const levels = new Set(query.levels ?? []);
    return MOCK_CANDIDATES.filter((c) => levels.has(c.jobLevel));
  }
  if (query.mode === 'batchType') {
    if (query.batchType === 'octoberBatch') return MOCK_CANDIDATES.filter((c) => c.octoberBatch);
    if (query.batchType === 'freshGraduate') return MOCK_CANDIDATES.filter((c) => c.freshGraduate);
  }
  if (query.mode === 'custom') {
    return filterCandidatesWithCustomFilters(query.customFilters);
  }
  return MOCK_CANDIDATES;
}

function toVerificationRow(c: CandidateSummary) {
  return {
    nin: c.nin,
    name: c.name,
    region: c.region,
    city: c.city,
    occupationalField: c.occupationalField,
    octoberBatch: c.octoberBatch,
    freshGraduate: c.freshGraduate,
    topMatchScore: c.topMatchScore,
    matchCount: c.matchCount,
  };
}

async function fetchDashboardFromApi(query: DashboardQuery): Promise<DashboardSnapshot> {
  return apiRequest<DashboardSnapshot>(
    `/dashboard?period=${encodeURIComponent(query.period)}`,
    { next: { revalidate: 60 } },
    DashboardSnapshotSchema,
  );
}

export async function fetchDashboard(query: DashboardQuery): Promise<DashboardSnapshot> {
  if (USE_HARDCODED_MOCK) {
    return { ...MOCK_DASHBOARD, period: query.period };
  }
  return fetchDashboardFromApi(query);
}

async function fetchCandidatesFromApi(query: CandidateQuery): Promise<Paginated<CandidateSummary>> {
  const params = new URLSearchParams();

  function setCsv(name: string, values: Array<string | number | boolean> | undefined): void {
    if (!values || values.length === 0) return;
    params.set(name, values.join(','));
  }

  if (query.search?.trim()) params.set('q', query.search);
  setCsv('region', query.region);
  setCsv('city', query.city);
  setCsv('gender', query.gender);
  setCsv('age', query.age);
  setCsv('qualification', query.qualification);
  setCsv('occupationalField', query.occupationalField);
  setCsv('yearsExperience', query.yearsExperience);
  setCsv('status', query.status);
  setCsv('octoberBatch', query.octoberBatch);
  setCsv('freshGraduate', query.freshGraduate);
  setCsv('tier', query.readiness);
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(clampPageSize(query.pageSize)));

  return apiRequest<Paginated<CandidateSummary>>(
    `/candidates?${params.toString()}`,
    { next: { revalidate: 30 } },
    PaginatedCandidateSummarySchema,
  );
}

async function fetchCandidateProfileFromApi(nin: string): Promise<CandidateProfile | null> {
  try {
    return await apiRequest<CandidateProfile>(
      `/candidates/${encodeURIComponent(nin)}`,
      { next: { revalidate: 30 } },
      CandidateProfileSchema,
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) return null;
    throw err;
  }
}

async function fetchCandidateRegionsFromApi(query: Pick<CandidateQuery, 'search' | 'readiness'>): Promise<string[]> {
  const params = new URLSearchParams();
  if (query.search) params.set('q', query.search);
  if (query.readiness && query.readiness.length > 0) params.set('tier', query.readiness.join(','));

  const payload = await apiRequest<{ regions: string[] }>(
    `/candidates/regions?${params.toString()}`,
    { next: { revalidate: 60 } },
    CandidateRegionsSchema,
  );
  return payload.regions;
}

export async function fetchCandidates(query: CandidateQuery): Promise<Paginated<CandidateSummary>> {
  if (USE_HARDCODED_MOCK) {
    return paginate(filterCandidates(query), query.page, query.pageSize);
  }
  return fetchCandidatesFromApi(query);
}

export async function fetchCandidateProfile(nin: string): Promise<CandidateProfile | null> {
  if (USE_HARDCODED_MOCK) {
    return MOCK_CANDIDATE_PROFILES[nin] ?? null;
  }
  return fetchCandidateProfileFromApi(nin);
}

export async function fetchCandidateRegions(
  query: Pick<CandidateQuery, 'search' | 'readiness'>,
): Promise<string[]> {
  if (USE_HARDCODED_MOCK) {
    const filtered = filterCandidates({ search: query.search, readiness: query.readiness });
    return Array.from(new Set(filtered.map((c) => c.region))).sort((a, b) => a.localeCompare(b));
  }
  return fetchCandidateRegionsFromApi(query);
}

async function fetchCandidateFacetsFromApi(): Promise<CandidateFacets> {
  return apiRequest<CandidateFacets>(
    '/candidates/facets',
    { next: { revalidate: 60 } },
    CandidateFacetsSchema,
  );
}

export async function fetchCandidateFacets(): Promise<CandidateFacets> {
  const facets = USE_HARDCODED_MOCK
    ? {
      readiness: ['ready', 'partial', 'incomplete'] as CandidateFacets['readiness'],
      regions: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.region))).sort((a, b) => a.localeCompare(b)),
      cities: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.city))).sort((a, b) => a.localeCompare(b)),
      genders: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.gender))).sort((a, b) => a.localeCompare(b)),
      ages: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.age))).sort((a, b) => a - b),
      qualifications: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.qualification))).sort((a, b) => a.localeCompare(b)),
      occupationalFields: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.occupationalField))).sort((a, b) => a.localeCompare(b)),
      yearsExperience: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.yearsExperience))).sort((a, b) => a - b),
      statuses: Array.from(new Set(MOCK_CANDIDATES.map((c) => c.status))).sort((a, b) => a.localeCompare(b)),
      octoberBatch: [true, false],
      freshGraduate: [true, false],
    }
    : await fetchCandidateFacetsFromApi();

  return {
    ...facets,
    regions: capFacetList(facets.regions),
    cities: capFacetList(facets.cities),
    genders: capFacetList(facets.genders),
    ages: capFacetList(facets.ages),
    qualifications: capFacetList(facets.qualifications),
    occupationalFields: capFacetList(facets.occupationalFields),
    yearsExperience: capFacetList(facets.yearsExperience),
    statuses: capFacetList(facets.statuses),
  };
}

async function fetchCandidateOutreachSearchFromApi(search: string): Promise<CandidateSummary[]> {
  return apiRequest<CandidateSummary[]>(
    `/candidates/outreach-search?q=${encodeURIComponent(search)}`,
    { cache: 'no-store' },
    CandidateOutreachSearchSchema,
  );
}

export async function fetchCandidateOutreachSearch(search: string): Promise<CandidateSummary[]> {
  if (USE_HARDCODED_MOCK) {
    if (!search.trim()) return MOCK_CANDIDATES;
    return MOCK_CANDIDATES.filter((c) => containsText(c.name, search) || containsText(c.nin, search));
  }
  return fetchCandidateOutreachSearchFromApi(search);
}

export async function fetchCandidatesByNins(nins: string[]): Promise<CandidateSummary[]> {
  if (USE_HARDCODED_MOCK) {
    const set = new Set(nins);
    return MOCK_CANDIDATES.filter((c) => set.has(c.nin));
  }
  const params = new URLSearchParams();
  for (const nin of nins) params.append('nin', nin);
  return apiRequest<CandidateSummary[]>(
    `/candidates/by-nins?${params.toString()}`,
    { cache: 'no-store' },
    CandidateOutreachSearchSchema,
  );
}

async function fetchJobLevelBatchesFromApi(): Promise<JobLevelBatch[]> {
  return apiRequest<JobLevelBatch[]>(
    '/candidates/job-levels',
    { next: { revalidate: 60 } },
    JobLevelBatchesSchema,
  );
}

export async function fetchJobLevelBatches(): Promise<JobLevelBatch[]> {
  if (USE_HARDCODED_MOCK) {
    const levels: Array<{ key: JobLevelBatch['key']; label: string }> = [
      { key: 'entry', label: 'Entry' },
      { key: 'mid', label: 'Mid' },
      { key: 'senior', label: 'Senior' },
    ];
    return levels.map((level) => ({
      key: level.key,
      label: level.label,
      count: MOCK_CANDIDATES.filter((c) => c.jobLevel === level.key).length,
    }));
  }
  return fetchJobLevelBatchesFromApi();
}

async function fetchCandidateBatchPreviewFromApi(query: CandidateBatchPreviewQuery): Promise<number> {
  const params = new URLSearchParams();
  if (query.batchType) {
    params.set('batchType', query.batchType);
  } else if (query.filters) {
    const f = query.filters;
    f.regions.forEach((r) => params.append('region', r));
    f.cities.forEach((c) => params.append('city', c));
    f.genders.forEach((g) => params.append('gender', g));
    f.ages.forEach((a) => params.append('age', String(a)));
    f.qualifications.forEach((q) => params.append('qualification', q));
    f.occupationalFields.forEach((o) => params.append('occupationalField', o));
    f.yearsExperience.forEach((y) => params.append('yearsExperience', String(y)));
    f.statuses.forEach((s) => params.append('status', s));
    f.readiness.forEach((r) => params.append('readiness', r));
  } else {
    for (const region of (query as { regions?: string[] }).regions ?? []) params.append('region', region);
    for (const level of (query as { levels?: string[] }).levels ?? []) params.append('level', level);
  }

  const payload = await apiRequest<{ count: number }>(
    `/candidates/batch-preview?${params.toString()}`,
    { cache: 'no-store' },
    CandidateBatchPreviewSchema,
  );
  return payload.count;
}

export async function fetchCandidateBatchPreview(query: CandidateBatchPreviewQuery): Promise<number> {
  if (USE_HARDCODED_MOCK) {
    if (query.batchType === 'octoberBatch') return MOCK_CANDIDATES.filter((c) => c.octoberBatch).length;
    if (query.batchType === 'freshGraduate') return MOCK_CANDIDATES.filter((c) => c.freshGraduate).length;
    if (query.filters) return filterCandidatesWithCustomFilters(query.filters).length;
    return 0;
  }
  return fetchCandidateBatchPreviewFromApi(query);
}

async function fetchBatchTypesFromApi(): Promise<BatchTypeBatch[]> {
  return apiRequest<BatchTypeBatch[]>(
    '/candidates/batch-types',
    { next: { revalidate: 60 } },
    BatchTypeBatchesSchema,
  );
}

export async function fetchBatchTypes(): Promise<BatchTypeBatch[]> {
  if (USE_HARDCODED_MOCK) {
    return [
      {
        key: 'octoberBatch',
        label: 'October Batch',
        count: MOCK_CANDIDATES.filter((c) => c.octoberBatch).length,
      },
      {
        key: 'freshGraduate',
        label: 'Fresh Graduates',
        count: MOCK_CANDIDATES.filter((c) => c.freshGraduate).length,
      },
    ];
  }
  return fetchBatchTypesFromApi();
}

function verificationBatchParams(query: VerificationBatchQuery): URLSearchParams {
  const params = new URLSearchParams();
  params.set('mode', query.mode);
  for (const nin of query.nins ?? []) params.append('nin', nin);
  for (const level of query.levels ?? []) params.append('level', level);
  for (const region of query.regions ?? []) params.append('region', region);
  if (query.batchType) params.set('batchType', query.batchType);
  if (query.mode === 'custom' && query.customFilters) {
    const f = query.customFilters;
    f.regions.forEach((r) => params.append('region', r));
    f.cities.forEach((c) => params.append('city', c));
    f.genders.forEach((g) => params.append('gender', g));
    f.ages.forEach((a) => params.append('age', String(a)));
    f.qualifications.forEach((q) => params.append('qualification', q));
    f.occupationalFields.forEach((o) => params.append('occupationalField', o));
    f.yearsExperience.forEach((y) => params.append('yearsExperience', String(y)));
    f.statuses.forEach((s) => params.append('status', s));
    f.readiness.forEach((r) => params.append('readiness', r));
  }
  return params;
}

async function fetchVerificationBatchFromApi(query: VerificationBatchQuery): Promise<VerificationBatchResult> {
  const params = verificationBatchParams(query);
  if (query.search?.trim()) params.set('q', query.search);
  if (query.region) params.set('filterRegion', query.region);
  if (query.level) params.set('filterLevel', query.level);
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(query.pageSize ?? 4));

  return apiRequest<VerificationBatchResult>(
    `/candidates/verification-batch?${params.toString()}`,
    { cache: 'no-store' },
    VerificationBatchResultSchema,
  );
}

export async function fetchVerificationBatch(query: VerificationBatchQuery): Promise<VerificationBatchResult> {
  if (USE_HARDCODED_MOCK) {
    const baseRows = getMockVerificationBase(query);
    let filtered = baseRows;
    if (query.search?.trim()) {
      const q = query.search.trim();
      filtered = filtered.filter((c) => containsText(c.name, q) || containsText(c.nin, q));
    }
    if (query.region) filtered = filtered.filter((c) => c.region === query.region);
    if (query.level) filtered = filtered.filter((c) => c.jobLevel === query.level);
    const rows = paginate(filtered.map(toVerificationRow), query.page, query.pageSize ?? 4);
    return {
      batchTotal: baseRows.length,
      rows,
    };
  }
  return fetchVerificationBatchFromApi(query);
}

async function fetchVerificationFacetsFromApi(query: VerificationBatchQuery): Promise<VerificationFacets> {
  const params = verificationBatchParams(query);

  return apiRequest<VerificationFacets>(
    `/candidates/verification-facets?${params.toString()}`,
    { next: { revalidate: 60 } },
    VerificationFacetsSchema,
  );
}

export async function fetchVerificationFacets(query: VerificationBatchQuery): Promise<VerificationFacets> {
  if (USE_HARDCODED_MOCK) {
    const baseRows = getMockVerificationBase(query);
    const regionSet = Array.from(new Set(baseRows.map((c) => c.region))).sort((a, b) => a.localeCompare(b));
    const levels: Array<{ key: JobLevelBatch['key']; label: string }> = [
      { key: 'entry', label: 'Entry' },
      { key: 'mid', label: 'Mid' },
      { key: 'senior', label: 'Senior' },
    ];
    return {
      regions: regionSet,
      levels: levels
        .map((level) => ({
          key: level.key,
          label: level.label,
          count: baseRows.filter((c) => c.jobLevel === level.key).length,
        }))
        .filter((level) => level.count > 0),
    };
  }
  return fetchVerificationFacetsFromApi(query);
}

async function fetchSuggestedJobsFromApi(nin: string, query: SuggestedJobsQuery): Promise<Paginated<SuggestedJob>> {
  const params = new URLSearchParams();
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(query.pageSize ?? 4));

  return apiRequest<Paginated<SuggestedJob>>(
    `/candidates/${encodeURIComponent(nin)}/suggested-jobs?${params.toString()}`,
    { next: { revalidate: 30 } },
    PaginatedSuggestedJobSchema,
  );
}

export async function fetchSuggestedJobs(nin: string, query: SuggestedJobsQuery = {}): Promise<Paginated<SuggestedJob>> {
  if (USE_HARDCODED_MOCK) {
    const profile = MOCK_CANDIDATE_PROFILES[nin];
    if (!profile) return paginate<SuggestedJob>([], query.page, query.pageSize ?? 4);
    const jobs: SuggestedJob[] = profile.matches.map((match) => ({
      id: match.jobId,
      jobTitle: match.jobTitle,
      employer: match.employer,
      location: profile.region,
      matchPct: match.score,
      explanation: match.explanation,
    }));
    return paginate(jobs, query.page, query.pageSize ?? 4);
  }
  return fetchSuggestedJobsFromApi(nin, query);
}

async function fetchEmployersFromApi(query: EmployerQuery): Promise<Paginated<EmployerSummary>> {
  const params = new URLSearchParams();

  if (query.search?.trim()) params.set('q', query.search);
  if (query.sector && query.sector.length > 0) params.set('sector', query.sector.join(','));
  if (query.size && query.size.length > 0) params.set('size', query.size.join(','));
  if (query.region && query.region.length > 0) params.set('region', query.region.join(','));
  if (query.hasJobs !== undefined) params.set('has_jobs', String(query.hasJobs));
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(clampPageSize(query.pageSize)));

  return apiRequest<Paginated<EmployerSummary>>(
    `/employers?${params.toString()}`,
    { next: { revalidate: 60 } },
    PaginatedEmployerSummarySchema,
  );
}

async function fetchEmployerProfileFromApi(
  id: string,
  query: { jobsPage?: number; jobsPageSize?: number } = {},
): Promise<EmployerProfile | null> {
  const params = new URLSearchParams();
  if (query.jobsPage) params.set('jobsPage', String(query.jobsPage));
  if (query.jobsPageSize) params.set('jobsPageSize', String(query.jobsPageSize));
  const qs = params.toString();
  try {
    return await apiRequest<EmployerProfile>(
      `/employers/${encodeURIComponent(id)}${qs ? `?${qs}` : ''}`,
      { next: { revalidate: 30 } },
      EmployerProfileSchema,
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) return null;
    throw err;
  }
}

export async function fetchEmployers(query: EmployerQuery): Promise<Paginated<EmployerSummary>> {
  if (USE_HARDCODED_MOCK) {
    let filtered = MOCK_EMPLOYERS;
    if (query.search?.trim()) {
      const q = query.search.trim();
      filtered = filtered.filter((e) => containsText(e.name, q) || containsText(e.id, q));
    }
    if (query.sector?.length) filtered = filtered.filter((e) => query.sector?.includes(e.sector));
    if (query.size?.length) filtered = filtered.filter((e) => query.size?.includes(e.size));
    if (query.region?.length) filtered = filtered.filter((e) => query.region?.includes(e.region));
    if (query.hasJobs !== undefined) filtered = filtered.filter((e) => (e.jobs > 0) === query.hasJobs);
    return paginate(filtered, query.page, query.pageSize);
  }
  return fetchEmployersFromApi(query);
}

async function fetchEmployerFacetsFromApi(): Promise<EmployerFacets> {
  // Backend has no /employers/facets — derive filter options from GET /employers.
  const page = await fetchEmployersFromApi({ page: 1, pageSize: 100 });
  return deriveEmployerFacets(page.rows);
}

function deriveEmployerFacets(rows: EmployerSummary[]): EmployerFacets {
  const sectors = new Set<string>();
  const sizes = new Set<string>();
  const regions = new Set<string>();

  for (const row of rows) {
    if (row.sector?.trim()) sectors.add(row.sector.trim());
    if (row.size?.trim()) sizes.add(row.size.trim());
    if (row.region?.trim()) regions.add(row.region.trim());
  }

  const byLabel = (a: string, b: string): number => a.localeCompare(b);
  return {
    sectors: Array.from(sectors).sort(byLabel),
    sizes: Array.from(sizes).sort(byLabel),
    regions: Array.from(regions).sort(byLabel),
  };
}

export async function fetchEmployerFacets(): Promise<EmployerFacets> {
  const facets = USE_HARDCODED_MOCK
    ? deriveEmployerFacets(MOCK_EMPLOYERS)
    : await fetchEmployerFacetsFromApi();

  return {
    sectors: capFacetList(facets.sectors),
    sizes: capFacetList(facets.sizes),
    regions: capFacetList(facets.regions),
  };
}

export async function fetchEmployerProfile(
  id: string,
  query: { jobsPage?: number; jobsPageSize?: number } = {},
): Promise<EmployerProfile | null> {
  if (USE_HARDCODED_MOCK) {
    const profile = MOCK_EMPLOYER_PROFILES[id];
    if (!profile) return null;
    const postedJobs = paginate(profile.postedJobs.rows, query.jobsPage, query.jobsPageSize);
    return {
      ...profile,
      postedJobs,
    };
  }
  return fetchEmployerProfileFromApi(id, query);
}

async function fetchReviewQueueFromApi(): Promise<QueueEntry[]> {
  return apiRequest<QueueEntry[]>(
    '/actions/queue',
    { cache: 'no-store' },
    QueueEntrySchema.array(),
  );
}

async function fetchRecentActivityFromApi(query: ActivityQuery): Promise<Paginated<ActivityEntry>> {
  const params = new URLSearchParams();
  if (query.page) params.set('page', String(query.page));
  if (query.pageSize) params.set('pageSize', String(clampPageSize(query.pageSize)));
  const qs = params.toString();
  return apiRequest<Paginated<ActivityEntry>>(
    `/actions/activity${qs ? `?${qs}` : ''}`,
    { cache: 'no-store' },
    PaginatedActivitySchema,
  );
}

export async function fetchReviewQueue(): Promise<QueueEntry[]> {
  if (USE_HARDCODED_MOCK) {
    return MOCK_QUEUE;
  }
  return fetchReviewQueueFromApi();
}

export async function fetchRecentActivity(query: ActivityQuery = {}): Promise<Paginated<ActivityEntry>> {
  if (USE_HARDCODED_MOCK) {
    return paginate(MOCK_ACTIVITY, query.page, query.pageSize);
  }
  return fetchRecentActivityFromApi(query);
}

async function fetchReportsSnapshotFromApi(query: ReportsQuery): Promise<ReportsSnapshot> {
  return apiRequest<ReportsSnapshot>(
    `/reports?period=${encodeURIComponent(query.period)}`,
    { next: { revalidate: 300 } },
    ReportsSnapshotSchema,
  );
}

export async function fetchReportsSnapshot(query: ReportsQuery): Promise<ReportsSnapshot> {
  if (USE_HARDCODED_MOCK) {
    void query;
    return MOCK_REPORTS;
  }
  return fetchReportsSnapshotFromApi(query);
}

async function fetchCampaignsFromApi(query: CampaignQuery): Promise<Paginated<CampaignSummary>> {
  const params = new URLSearchParams();
  if (query.purpose) params.set('purpose', query.purpose);
  if (query.createdBy) params.set('createdBy', query.createdBy);
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(clampPageSize(query.pageSize)));

  return apiRequest<Paginated<CampaignSummary>>(
    `/campaigns?${params.toString()}`,
    { cache: 'no-store' },
    PaginatedCampaignSummarySchema,
  );
}

export async function fetchCampaigns(query: CampaignQuery = {}): Promise<Paginated<CampaignSummary>> {
  if (USE_HARDCODED_MOCK) {
    let rows = MOCK_CAMPAIGNS.map((c) => c.header);
    if (query.purpose) rows = rows.filter((row) => row.purpose === query.purpose);
    if (query.createdBy) rows = rows.filter((row) => row.createdBy === query.createdBy);
    return paginate(rows, query.page, query.pageSize);
  }
  return fetchCampaignsFromApi(query);
}

async function fetchCampaignDetailFromApi(
  id: number,
  query: CampaignDetailQuery = {},
): Promise<CampaignDetail | null> {
  const params = new URLSearchParams();
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(clampPageSize(query.pageSize)));

  try {
    return await apiRequest<CampaignDetail>(
      `/campaigns/${encodeURIComponent(String(id))}?${params.toString()}`,
      { cache: 'no-store' },
      CampaignDetailSchema,
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) return null;
    throw err;
  }
}

export async function fetchCampaignDetail(
  id: number,
  query: CampaignDetailQuery = {},
): Promise<CampaignDetail | null> {
  if (USE_HARDCODED_MOCK) {
    const detail = MOCK_CAMPAIGNS.find((c) => c.header.id === id);
    if (!detail) return null;
    const pagedRows = paginate(detail.rows, query.page, query.pageSize);
    return {
      header: detail.header,
      rows: pagedRows.rows,
      total: pagedRows.total,
      page: pagedRows.page,
      pageSize: pagedRows.pageSize,
    };
  }
  return fetchCampaignDetailFromApi(id, query);
}

export type { CampaignCandidateRow, CampaignDetail, CampaignSummary };

async function fetchMyDecisionsFromApi(query: DecisionQuery): Promise<Paginated<UserDecision>> {
  const params = new URLSearchParams();
  if (query.createdBy) params.set('createdBy', query.createdBy);
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(clampPageSize(query.pageSize, 50)));
  return apiRequest<Paginated<UserDecision>>(
    `/actions/decisions?${params.toString()}`,
    { cache: 'no-store' },
    PaginatedUserDecisionSchema,
  );
}

export async function fetchMyDecisions(query: DecisionQuery = {}): Promise<Paginated<UserDecision>> {
  if (USE_HARDCODED_MOCK) return paginate([], query.page, query.pageSize);
  return fetchMyDecisionsFromApi(query);
}

import { messages } from '@/i18n/catalog';
import type { Locale } from '@/i18n/config';

export function outreachSidebarProps(locale: Locale) {
  return {
    newCampaignHref: '/outreach/targeting',
    campaignsLogHref: '/outreach/campaigns',
    labels: {
      newCampaign: messages.outreachNavNewCampaign[locale],
      campaignsLog: messages.outreachNavCampaignsLog[locale],
      navLabel: messages.outreachNavLabel[locale],
    },
  } as const;
}

import 'server-only';

import { cookies } from 'next/headers';

import {
  emptyOutreachDraft,
  encodeOutreachDraft,
  OUTREACH_DRAFT_COOKIE,
  parseOutreachDraft,
  type OutreachDraft,
} from '@/lib/outreach/draft';

export async function getOutreachDraft(): Promise<OutreachDraft> {
  const store = await cookies();
  const raw = store.get(OUTREACH_DRAFT_COOKIE)?.value;
  if (!raw) return emptyOutreachDraft();
  try {
    return parseOutreachDraft(JSON.parse(raw)) ?? emptyOutreachDraft();
  } catch {
    return emptyOutreachDraft();
  }
}

export async function setOutreachDraftCookie(draft: OutreachDraft, secure: boolean): Promise<void> {
  const store = await cookies();
  store.set(OUTREACH_DRAFT_COOKIE, encodeOutreachDraft(draft), {
    httpOnly: true,
    sameSite: 'lax',
    secure,
    path: '/',
    maxAge: 60 * 60 * 8,
  });
}

export async function clearOutreachDraftCookie(): Promise<void> {
  const store = await cookies();
  store.delete(OUTREACH_DRAFT_COOKIE);
}

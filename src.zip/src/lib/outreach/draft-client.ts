'use client';

import type { OutreachDraft, OutreachDraftPatch } from '@/lib/outreach/draft';

export async function saveOutreachDraft(patch: OutreachDraftPatch, replace = false): Promise<OutreachDraft> {
  const response = await fetch('/api/outreach/draft', {
    method: replace ? 'PUT' : 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });

  if (!response.ok) {
    let message = 'Failed to save outreach selection';
    try {
      const body = (await response.json()) as { error?: string };
      if (body.error) message = body.error;
    } catch {
    }
    throw new Error(message);
  }

  const body = (await response.json()) as { draft: OutreachDraft };
  return body.draft;
}

export async function clearOutreachDraft(): Promise<void> {
  await fetch('/api/outreach/draft', { method: 'DELETE' });
}

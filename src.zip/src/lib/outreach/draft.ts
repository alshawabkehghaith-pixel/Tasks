import type { BatchType, CustomBatchFilters, JobLevel } from '@/types/domain';

export const OUTREACH_DRAFT_COOKIE = 'jme_outreach_draft';
export const OUTREACH_DRAFT_MAX_BYTES = 3500;
export const OUTREACH_DRAFT_MAX_NINS = 400;

export type OutreachDraftMode = 'candidates' | 'batchType' | 'custom' | 'candidate' | 'levels' | '';

export type OutreachDraft = {
  version: 1;
  mode: OutreachDraftMode;
  nins: string[];
  nin: string;
  batchType: BatchType | '';
  levels: JobLevel[];
  regions: string[];
  customFilters: CustomBatchFilters | null;
  sel: string[];
  /** nin → '*' or '+'-joined job ids */
  jobsel: Record<string, string>;
  matchmap: Record<string, number>;
  updatedAt: string;
};

export type OutreachDraftPatch = Partial<Omit<OutreachDraft, 'version' | 'updatedAt'>>;

export function emptyOutreachDraft(): OutreachDraft {
  return {
    version: 1,
    mode: '',
    nins: [],
    nin: '',
    batchType: '',
    levels: [],
    regions: [],
    customFilters: null,
    sel: [],
    jobsel: {},
    matchmap: {},
    updatedAt: new Date().toISOString(),
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is string => typeof item === 'string' && item.length > 0);
}

function asNumberRecord(value: unknown): Record<string, number> {
  if (!isRecord(value)) return {};
  const out: Record<string, number> = {};
  for (const [key, raw] of Object.entries(value)) {
    if (typeof raw === 'number' && Number.isFinite(raw)) out[key] = raw;
  }
  return out;
}

function asStringRecord(value: unknown): Record<string, string> {
  if (!isRecord(value)) return {};
  const out: Record<string, string> = {};
  for (const [key, raw] of Object.entries(value)) {
    if (typeof raw === 'string' && raw.length > 0) out[key] = raw;
  }
  return out;
}

export function parseOutreachDraft(raw: unknown): OutreachDraft | null {
  if (!isRecord(raw) || raw.version !== 1) return null;

  const modeRaw = typeof raw.mode === 'string' ? raw.mode : '';
  const mode: OutreachDraftMode =
    modeRaw === 'candidates'
    || modeRaw === 'batchType'
    || modeRaw === 'custom'
    || modeRaw === 'candidate'
    || modeRaw === 'levels'
      ? modeRaw
      : '';

  const batchTypeRaw = typeof raw.batchType === 'string' ? raw.batchType : '';
  const batchType: BatchType | '' =
    batchTypeRaw === 'octoberBatch' || batchTypeRaw === 'freshGraduate' ? batchTypeRaw : '';

  let customFilters: CustomBatchFilters | null = null;
  if (isRecord(raw.customFilters)) {
    customFilters = {
      regions: asStringArray(raw.customFilters.regions),
      cities: asStringArray(raw.customFilters.cities),
      genders: asStringArray(raw.customFilters.genders),
      ages: Array.isArray(raw.customFilters.ages)
        ? raw.customFilters.ages.filter((v): v is number => typeof v === 'number' && Number.isFinite(v))
        : [],
      qualifications: asStringArray(raw.customFilters.qualifications),
      occupationalFields: asStringArray(raw.customFilters.occupationalFields),
      yearsExperience: Array.isArray(raw.customFilters.yearsExperience)
        ? raw.customFilters.yearsExperience.filter((v): v is number => typeof v === 'number' && Number.isFinite(v))
        : [],
      statuses: asStringArray(raw.customFilters.statuses),
      readiness: asStringArray(raw.customFilters.readiness),
    };
  }

  return {
    version: 1,
    mode,
    nins: asStringArray(raw.nins).slice(0, OUTREACH_DRAFT_MAX_NINS),
    nin: typeof raw.nin === 'string' ? raw.nin : '',
    batchType,
    levels: asStringArray(raw.levels) as JobLevel[],
    regions: asStringArray(raw.regions),
    customFilters,
    sel: asStringArray(raw.sel).slice(0, OUTREACH_DRAFT_MAX_NINS),
    jobsel: asStringRecord(raw.jobsel),
    matchmap: asNumberRecord(raw.matchmap),
    updatedAt: typeof raw.updatedAt === 'string' ? raw.updatedAt : new Date().toISOString(),
  };
}

export function mergeOutreachDraft(base: OutreachDraft, patch: OutreachDraftPatch): OutreachDraft {
  return {
    ...base,
    ...patch,
    version: 1,
    nins: (patch.nins ?? base.nins).slice(0, OUTREACH_DRAFT_MAX_NINS),
    sel: (patch.sel ?? base.sel).slice(0, OUTREACH_DRAFT_MAX_NINS),
    updatedAt: new Date().toISOString(),
  };
}

export function encodeOutreachDraft(draft: OutreachDraft): string {
  return JSON.stringify(draft);
}

export function draftByteLength(draft: OutreachDraft): number {
  return new TextEncoder().encode(encodeOutreachDraft(draft)).length;
}

export function jobselRecordToString(jobsel: Record<string, string>): string {
  return Object.entries(jobsel)
    .filter(([, value]) => Boolean(value))
    .map(([nin, value]) => `${nin}:${value}`)
    .join('|');
}

export function jobselStringToRecord(jobsel: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const segment of jobsel.split('|').filter(Boolean)) {
    const idx = segment.indexOf(':');
    if (idx === -1) continue;
    const nin = segment.slice(0, idx);
    const value = segment.slice(idx + 1);
    if (nin && value) out[nin] = value;
  }
  return out;
}

export function outreachDraftCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure,
    path: '/',
    maxAge: 60 * 60 * 8,
  };
}

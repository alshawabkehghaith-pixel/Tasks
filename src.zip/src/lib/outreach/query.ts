
export function splitCsv(value: string | undefined | null): string[] {
  return value ? value.split(',').map((part) => part.trim()).filter(Boolean) : [];
}

export function parseJobSelForNin(jobsel: string, nin: string): string[] {
  for (const segment of jobsel.split('|').filter(Boolean)) {
    const colonIdx = segment.indexOf(':');
    if (colonIdx === -1) continue;
    if (segment.slice(0, colonIdx) === nin) {
      const value = segment.slice(colonIdx + 1);
      if (value === '*') return ['*'];
      return value.split('+').filter(Boolean);
    }
  }
  return [];
}

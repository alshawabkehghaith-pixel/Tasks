import { mapWithConcurrency } from '@/lib/async-pool';
import { fetchCandidatesByNins, fetchSuggestedJobs } from '@/lib/api/backend';
import { parseJobSelForNin } from '@/lib/outreach/query';
import { jobselRecordToString } from '@/lib/outreach/draft';
import type { PublishTargetEntry } from '@/types/domain';

const JOB_FETCH_CONCURRENCY = 6;

export async function hydratePublishTargets(
  selNins: string[],
  jobsel: string | Record<string, string>,
): Promise<PublishTargetEntry[]> {
  if (selNins.length === 0) return [];

  const jobselStr = typeof jobsel === 'string' ? jobsel : jobselRecordToString(jobsel);

  try {
    const [candidates, jobPages] = await Promise.all([
      fetchCandidatesByNins(selNins),
      mapWithConcurrency(selNins, JOB_FETCH_CONCURRENCY, (nin) =>
        fetchSuggestedJobs(nin, { page: 1, pageSize: 10 }),
      ),
    ]);

    return selNins.map((nin, index) => {
      const candidate = candidates.find((row) => row.nin === nin);
      const jobIds = parseJobSelForNin(jobselStr, nin);
      const allJobs = jobPages[index]?.rows ?? [];
      const selectedJobs = jobIds.includes('*')
        ? allJobs
        : allJobs.filter((job) => jobIds.includes(job.id));

      return {
        nin,
        name: candidate?.name ?? nin,
        jobIds: jobIds.includes('*') ? ['*'] : jobIds,
        jobTitles: selectedJobs.map((job) => `${job.jobTitle} - ${job.employer}`),
      };
    });
  } catch {
    return selNins.map((nin) => {
      const jobIds = parseJobSelForNin(jobselStr, nin);
      return {
        nin,
        name: nin,
        jobIds: jobIds.includes('*') ? ['*'] : jobIds,
        jobTitles: [],
      };
    });
  }
}

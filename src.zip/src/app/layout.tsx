import type { Metadata, Viewport } from 'next';
import { cookies } from 'next/headers';
import { Toaster } from 'sonner';

import { sstArabic } from '@/app/fonts';
import { MockModeRuntimeNotice } from '@/components/shell/MockModeRuntimeNotice';
import { PersistentTopbar } from '@/components/shell/PersistentTopbar';
import { NavigationProgress } from '@/components/ui/NavigationProgress';
import { LOCALE_COOKIE, THEME_COOKIE } from '@/lib/auth-state';
import { DASHBOARD_HERO_INTRO_COOKIE } from '@/lib/hero-intro-storage';
import { DEFAULT_LOCALE, DEFAULT_THEME, resolveLocale, resolveTheme } from '@/lib/api/jadarat';
import { getAppSession } from '@/lib/server/auth';

import './base.css';

const THEME_BOOTSTRAP_SCRIPT = `(() => {
  var root = document.documentElement;
  root.setAttribute('data-js', 'ready');
  try {
    var m = document.cookie.match(/(?:^|;\\s*)${THEME_COOKIE}=(light|dark)/);
    var stored = m ? m[1] : localStorage.getItem('theme');
    root.setAttribute('data-theme', stored === 'light' ? 'light' : 'dark');
  } catch {
    root.setAttribute('data-theme', 'dark');
  }
  try {
    if (localStorage.getItem('jme.dashboardHeroIntroSeen') === '1') {
      if (!/(?:^|;\\s*)${DASHBOARD_HERO_INTRO_COOKIE}=1(?:;|$)/.test(document.cookie)) {
        var secure = location.protocol === 'https:' ? '; secure' : '';
        document.cookie = '${DASHBOARD_HERO_INTRO_COOKIE}=1; path=/; max-age=34560000; samesite=lax' + secure;
      }
    }
  } catch {}
  try {
    var REF_W = 1440;
    var REF_H = 900;
    var MOBILE_MAX = 900;
    var applyScale = function () {
      var w = window.innerWidth;
      var h = window.innerHeight;
      root.style.zoom = '';
      if (w <= MOBILE_MAX) {
        root.style.setProperty('--ui-scale', '1');
        return;
      }
      var s = Math.min(1, w / REF_W, h / REF_H);
      s = Math.round(s * 1000) / 1000;
      root.style.setProperty('--ui-scale', String(s));
    };
    applyScale();
    window.addEventListener('resize', applyScale, { passive: true });
  } catch {}
})();`;

export const metadata: Metadata = {
  title: {
    default: 'محرك مطابقة الوظائف | Job Matching Engine',
    template: '%s | محرك مطابقة الوظائف',
  },
  description: 'محرك مطابقة الوظائف — منصة مطابقة المرشحين بالوظائف لصندوق تنمية الموارد البشرية.',
  applicationName: 'Job Matching Engine',
  robots: { index: false, follow: false },
  openGraph: {
    type: 'website',
    siteName: 'Job Matching Engine',
    title: 'محرك مطابقة الوظائف | Job Matching Engine',
    description: 'منصة مطابقة المرشحين بالوظائف لصندوق تنمية الموارد البشرية.',
  },
  other: { google: 'notranslate' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#E5E5E5' },
    { media: '(prefers-color-scheme: dark)', color: '#1F2A2B' },
  ],
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>): Promise<JSX.Element> {
  const cookieStore = await cookies();
  const locale = resolveLocale(cookieStore.get(LOCALE_COOKIE)?.value ?? DEFAULT_LOCALE);
  const theme = resolveTheme(cookieStore.get(THEME_COOKIE)?.value ?? DEFAULT_THEME);
  const session = await getAppSession();

  return (
    <html
      lang={locale}
      dir={locale === 'ar' ? 'rtl' : 'ltr'}
      data-theme={theme}
      translate="no"
      className={`notranslate ${sstArabic.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOTSTRAP_SCRIPT }} />
        <meta name="google" content="notranslate" />
      </head>
      <body>
        <NavigationProgress />
        <MockModeRuntimeNotice />
        <PersistentTopbar
          initialLocale={locale}
          initialTheme={theme}
          userName={session?.user.displayName ?? null}
          userRole={session?.user.role ?? null}
        />
        {children}
        <Toaster
          position="bottom-center"
          dir={locale === 'ar' ? 'rtl' : 'ltr'}
          theme={theme as 'light' | 'dark'}
          richColors
          closeButton
          duration={4000}
        />
      </body>
    </html>
  );
}
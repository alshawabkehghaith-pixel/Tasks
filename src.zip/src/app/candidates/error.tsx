'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function CandidatesError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="candidates"
      titleAr="تعذّر تحميل قائمة المرشّحين"
      titleEn="Candidates list could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

import { CandidatesFilterToolbar } from '@/components/candidate/candidates-filter-toolbar/CandidatesFilterToolbar';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { ClickableRow } from '@/components/ui/ClickableRow';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import styles from '@/components/candidate/candidate-match-list/CandidateMatchList.module.css';
import { messages } from '@/i18n/catalog';
import { fetchCandidateFacets, fetchCandidates } from '@/lib/api/backend';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { CandidateSummary, Readiness, Readiness as ReadinessValue } from '@/types/domain';
import type { Locale } from '@/types/jadarat';
import type { AsyncSearchParamsProps } from '@/types/page';

const pageSize = 25;

export const metadata: Metadata = {
  title: 'المرشحون — Candidates',
};

const COLUMNS = [
  { labelKey: 'colName', align: 'start' },
  { labelKey: 'colRegion', align: 'start' },
  { labelKey: 'colCity', align: 'start' },
  { labelKey: 'cand360Qualification', align: 'start' },
  { labelKey: 'colOccupationalField', align: 'start' },
  { labelKey: 'cand360YearsExp', align: 'end' },
  { labelKey: 'colReadiness', align: 'center' },
  { labelKey: 'colReadinessScore', align: 'end' },
] as const satisfies readonly {
  labelKey: keyof typeof messages;
  align: 'start' | 'end' | 'center';
}[];

const COLUMN_COUNT = COLUMNS.length + 1;

const ALIGN_CLASS = { start: '', end: 'ta-end', center: 'ta-center' } as const;

type PagerToken = number | 'gap';

function buildPagerTokens(current: number, total: number, siblingCount = 1): PagerToken[] {
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1);
  }

  const left = Math.max(2, current - siblingCount);
  const right = Math.min(total - 1, current + siblingCount);
  const tokens: PagerToken[] = [1];

  if (left > 2) {
    tokens.push('gap');
  }

  for (let n = left; n <= right; n += 1) {
    tokens.push(n);
  }

  if (right < total - 1) {
    tokens.push('gap');
  }

  tokens.push(total);
  return tokens;
}

const READINESS_META: Record<Readiness, { labelKey: 'candListReadinessReady' | 'candListReadinessPartial' | 'candListReadinessIncomplete'; className: string }> = {
  ready: { labelKey: 'candListReadinessReady', className: styles.readinessInlineReady ?? '' },
  partial: { labelKey: 'candListReadinessPartial', className: styles.readinessInlinePartial ?? '' },
  incomplete: { labelKey: 'candListReadinessIncomplete', className: styles.readinessInlineIncomplete ?? '' },
};

function ReadinessCell({ readiness, locale }: { readiness: Readiness; locale: Locale }): JSX.Element {
  const meta = READINESS_META[readiness];

  return (
    <td className={`${styles.readinessCell} ta-center`}>
      <span className={`${styles.readinessInline} ${meta.className}`}>
        <span className={styles.readinessDot} aria-hidden="true" />
        <span>{messages[meta.labelKey][locale]}</span>
      </span>
    </td>
  );
}

function splitCsv(value: string): string[] {
  return value ? value.split(',').map((part) => part.trim()).filter(Boolean) : [];
}

function splitCsvInts(value: string): number[] {
  return splitCsv(value).map((part) => Number.parseInt(part, 10)).filter((part) => !Number.isNaN(part));
}

function splitCsvBools(value: string): boolean[] {
  return splitCsv(value)
    .filter((part) => part === 'true' || part === 'false')
    .map((part) => part === 'true');
}

export default async function CandidatesPage({ searchParams: searchParamsPromise }: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const requestedPage = Number.parseInt(getQueryValue(searchParams.page) || '1', 10);
  const page = Number.isFinite(requestedPage) && requestedPage > 0 ? requestedPage : 1;
  const search = getQueryValue(searchParams.q);
  const readiness = splitCsv(getQueryValue(searchParams.tier)).filter((value): value is ReadinessValue => value === 'ready' || value === 'partial' || value === 'incomplete');
  const region = splitCsv(getQueryValue(searchParams.region));
  const city = splitCsv(getQueryValue(searchParams.city));
  const gender = splitCsv(getQueryValue(searchParams.gender));
  const age = splitCsvInts(getQueryValue(searchParams.age));
  const qualification = splitCsv(getQueryValue(searchParams.qualification));
  const occupationalField = splitCsv(getQueryValue(searchParams.occupationalField));
  const yearsExperience = splitCsvInts(getQueryValue(searchParams.yearsExperience));
  const status = splitCsv(getQueryValue(searchParams.status));
  const octoberBatch = splitCsvBools(getQueryValue(searchParams.octoberBatch));
  const freshGraduate = splitCsvBools(getQueryValue(searchParams.freshGraduate));

  const [result, facets] = await Promise.all([
    fetchCandidates({
      search,
      region,
      city,
      gender,
      age,
      qualification,
      occupationalField,
      yearsExperience,
      status,
      octoberBatch,
      freshGraduate,
      readiness,
      page,
      pageSize,
    }),
    fetchCandidateFacets(),
  ]);

  const totalPages = Math.max(1, Math.ceil(result.total / pageSize));

  const currentQuery = {
    q: search,
    tier: getQueryValue(searchParams.tier),
    region: getQueryValue(searchParams.region),
    city: getQueryValue(searchParams.city),
    gender: getQueryValue(searchParams.gender),
    age: getQueryValue(searchParams.age),
    qualification: getQueryValue(searchParams.qualification),
    occupationalField: getQueryValue(searchParams.occupationalField),
    yearsExperience: getQueryValue(searchParams.yearsExperience),
    status: getQueryValue(searchParams.status),
    octoberBatch: getQueryValue(searchParams.octoberBatch),
    freshGraduate: getQueryValue(searchParams.freshGraduate),
    page: undefined,
  };
  const pagerBase = '/candidates';

  const filterStateKey = JSON.stringify(currentQuery);

  if (page > totalPages) {
    redirect(buildHref(pagerBase, currentQuery, { page: String(totalPages) }));
  }

  const pagerTokens = buildPagerTokens(page, totalPages);
  const rowHref = (nin: string): string => `/candidates/${encodeURIComponent(nin)}`;

  const filtersActive = Boolean(
    search ||
    readiness.length ||
    region.length ||
    city.length ||
    gender.length ||
    age.length ||
    qualification.length ||
    occupationalField.length ||
    yearsExperience.length ||
    status.length ||
    octoberBatch.length ||
    freshGraduate.length,
  );

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/candidates"
      query={searchParams}
      title={messages.navCandidates[locale]}
    >
      <SurfaceCard className="list-table-card">
        <div className="filter-bar">
          <CandidatesFilterToolbar
            key={filterStateKey}
            locale={locale}
            facets={facets}
            initialFilters={{
              search,
              readiness,
              region,
              city,
              gender,
              age,
              qualification,
              occupationalField,
              yearsExperience,
              status,
              octoberBatch,
              freshGraduate,
            }}
          />
        </div>

        <div className="rescount" aria-live="polite">
          {result.total.toLocaleString(locale)} {messages.resultsCount[locale]}
        </div>

        <div className="list-table-wrap list-table-zoom">
          <div className="list-table-zoom-inner">
            <table className="ltbl">
              <thead>
                <tr>
                  {COLUMNS.map(({ labelKey, align }) => (
                    <th key={labelKey} scope="col" className={ALIGN_CLASS[align]}>
                      {messages[labelKey][locale]}
                    </th>
                  ))}
                  <th aria-hidden="true" />
                </tr>
              </thead>
              <tbody>
                {result.rows.length ? (
                  result.rows.map((row: CandidateSummary) => (
                    <ClickableRow key={row.nin} href={rowHref(row.nin)}>
                      <td className="lname">
                        <Link href={rowHref(row.nin)}>{row.name}</Link>
                      </td>
                      <td>{row.region}</td>
                      <td>{row.city}</td>
                      <td>{row.qualification}</td>
                      <td>{row.occupationalField}</td>
                      <td className="mono ta-end">{row.yearsExperience}</td>
                      <ReadinessCell readiness={row.readiness} locale={locale} />
                      <td className="mono ta-end">{row.score}%</td>
                      <td className="list-view-cell">
                        <span className="list-view-hint">
                          <span>{messages.candListViewCandidate[locale]}</span>
                          {locale === 'ar'
                            ? <ArrowLeft size={13} strokeWidth={2.2} aria-hidden="true" />
                            : <ArrowRight size={13} strokeWidth={2.2} aria-hidden="true" />}
                        </span>
                      </td>
                    </ClickableRow>
                  ))
                ) : (
                  <tr>
                    <td className="empty" colSpan={COLUMN_COUNT}>
                      <div className="list-empty">
                        <span>{messages.noResults[locale]}</span>
                        {filtersActive ? (
                          <Link href="/candidates" className="text-[13px] font-semibold text-[var(--brand)] no-underline hover:underline">
                            {messages.emptyClearFilters[locale]}
                          </Link>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {totalPages > 1 ? (
          <nav className="pager" aria-label={messages.pagerNavLabel[locale]}>
            {page > 1 ? (
              <Link href={buildHref(pagerBase, currentQuery, { page: String(page - 1) })} aria-label={messages.pagerPrevPage[locale]}>
                <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronLeft size={14} strokeWidth={2.2} />
              </span>
            )}
            {pagerTokens.map((token, index) => {
              if (token === 'gap') {
                return (
                  <span key={`gap-${index}`} className="gap" aria-hidden="true">
                    ...
                  </span>
                );
              }

              const n = token;
              return n === page ? (
                <span key={n} className="cur" aria-current="page">
                  {n}
                </span>
              ) : (
                <Link
                  key={n}
                  href={buildHref(pagerBase, currentQuery, { page: String(n) })}
                  aria-label={messages.pagerGoToPage[locale].replace('{n}', String(n))}
                >
                  {n}
                </Link>
              );
            })}
            {page < totalPages ? (
              <Link href={buildHref(pagerBase, currentQuery, { page: String(page + 1) })} aria-label={messages.pagerNextPage[locale]}>
                <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronRight size={14} strokeWidth={2.2} />
              </span>
            )}
          </nav>
        ) : null}
      </SurfaceCard>
    </AppShellTemplate>
  );
}
import Link from 'next/link';

import { EmptyState } from '@/components/ui/EmptyState';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { messages } from '@/i18n/catalog';
import { getServerAppPreferences } from '@/lib/server/preferences';

export default async function CandidateNotFound(): Promise<JSX.Element> {
  const prefs = await getServerAppPreferences({});
  const locale = prefs.locale;

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/candidates"
      query={{}}
      title={messages.titleCandidate[locale]}
    >
      <Link className="back-link" href="/candidates">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M15 6l-6 6 6 6" />
        </svg>
        {messages.backToCandidates[locale]}
      </Link>
      <EmptyState
        title={messages.profileNotFoundTitle[locale]}
        description={messages.candProfileEmptyDesc[locale]}
      />
    </AppShellTemplate>
  );
}

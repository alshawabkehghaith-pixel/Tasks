import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';

import { CandidateProfileView } from '@/components/candidate/candidate-profile-view/CandidateProfileView';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { messages } from '@/i18n/catalog';
import { fetchCandidateProfile } from '@/lib/api/backend';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { AsyncRouteProps } from '@/types/page';

export async function generateMetadata({ params: paramsPromise }: AsyncRouteProps<{ nin: string }>): Promise<Metadata> {
  const params = await paramsPromise;
  const [profile, prefs] = await Promise.all([
    fetchCandidateProfile(params.nin),
    getServerAppPreferences({}),
  ]);

  return { title: profile ? profile.name : messages.profileNotFoundTitle[prefs.locale] };
}

export default async function CandidateDetailPage({ params: paramsPromise, searchParams: searchParamsPromise }: AsyncRouteProps<{ nin: string }>): Promise<JSX.Element> {
  const [params, searchParams] = await Promise.all([paramsPromise, searchParamsPromise]);
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const profile = await fetchCandidateProfile(params.nin);

  if (!profile) notFound();

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname={`/candidates/${encodeURIComponent(params.nin)}`}
      query={searchParams}
      title={messages.titleCandidate[locale]}
    >
      <Link className="back-link" href="/candidates">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M15 6l-6 6 6 6" />
        </svg>
        {messages.backToCandidates[locale]}
      </Link>
      <div className="flex flex-col gap-[18px]">
        <CandidateProfileView profile={profile} locale={locale} />
      </div>
    </AppShellTemplate>
  );
}
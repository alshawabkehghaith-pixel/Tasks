import styles from './loading.module.css';

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function CandidateDetailLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل ملف المرشّح</span>

      <div className={styles.backLink}>
        <Bone h={14} w="100px" r={4} />
      </div>

      <div className={styles.stack}>
        <div className={styles.headerCard}>
          <div className={`${styles.bone} ${styles.avatar}`} />
          <div className={styles.headerInfo}>
            <Bone h={18} w="40%" />
            <Bone h={13} w="60%" r={4} />
            <div className={styles.chipRow}>
              <Bone h={22} w="80px" r={20} />
              <Bone h={22} w="80px" r={20} />
            </div>
          </div>
        </div>

        <div className={styles.duo}>
          <Bone h={280} r={14} />
          <Bone h={280} r={14} />
        </div>

        <Bone h={180} r={14} />
        <Bone h={240} r={14} />
      </div>
    </div>
  );
}

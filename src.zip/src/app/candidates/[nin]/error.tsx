'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function CandidateDetailError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="candidate-detail"
      titleAr="تعذّر تحميل ملف المرشّح"
      titleEn="Candidate profile could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

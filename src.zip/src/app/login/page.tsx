import type { Metadata } from 'next';
import { cookies } from 'next/headers';

import { HtmlAttrsSetter } from '@/components/i18n/HtmlAttrsSetter';
import { LoginForm } from '@/components/auth/login-form/LoginForm';
import { LOGIN_RETURN_TO_COOKIE, sanitizeReturnTo } from '@/lib/auth-state';
import { buildDevLoginHref, buildSsoLoginHref, DEV_AUTH_ENABLED } from '@/lib/auth-routes';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { AsyncSearchParamsProps } from '@/types/page';

export const metadata: Metadata = {
  title: 'تسجيل الدخول — محرك مطابقة الوظائف',
};

export default async function LoginPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);

  const { locale, theme } = prefs;
  const cookieStore = await cookies();

  const next = sanitizeReturnTo(
    typeof searchParams.next === 'string' ? searchParams.next : cookieStore.get(LOGIN_RETURN_TO_COOKIE)?.value,
  );
  const devLoginEnabled = DEV_AUTH_ENABLED;

  return (
    <>
      <HtmlAttrsSetter locale={locale} theme={theme} stripQueryKeys={['lang', 'theme', 'next']} />
      <LoginForm
        initialLocale={locale}
        theme={theme}
        ssoLoginHrefAr={buildSsoLoginHref('ar', next)}
        ssoLoginHrefEn={buildSsoLoginHref('en', next)}
        devLoginEnabled={devLoginEnabled}
        devLoginHrefAr={buildDevLoginHref('ar', next)}
        devLoginHrefEn={buildDevLoginHref('en', next)}
      />
    </>
  );
}
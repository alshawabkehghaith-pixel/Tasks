import { cookies } from 'next/headers';

import { DashboardView } from '@/components/dashboard/dashboard-view/DashboardView';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { messages } from '@/i18n/catalog';
import { fetchDashboard } from '@/lib/api/backend';
import { DASHBOARD_PERIOD_COOKIE } from '@/lib/auth-state';
import { readDashboardPeriodCookie } from '@/lib/dashboard-period';
import {
  DASHBOARD_HERO_INTRO_COOKIE,
  hasSeenDashboardHeroIntroCookie,
} from '@/lib/hero-intro-storage';
import { getServerAppPreferences } from '@/lib/server/preferences';
import { getAppSession } from '@/lib/server/auth';
import type { AsyncSearchParamsProps } from '@/types/page';

export default async function DashboardPage({ searchParams: searchParamsPromise }: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const cookieStore = await cookies();
  const period = readDashboardPeriodCookie(cookieStore.get(DASHBOARD_PERIOD_COOKIE)?.value);

  const [data, session] = await Promise.all([
    fetchDashboard({ period }),
    getAppSession(),
  ]);
  const heroIntroSeen = hasSeenDashboardHeroIntroCookie(
    cookieStore.get(DASHBOARD_HERO_INTRO_COOKIE)?.value,
  );

  return (
    <AppShellTemplate
      locale={prefs.locale}
      theme={prefs.theme}
      pathname="/dashboard"
      query={searchParams}
      title={messages.navDashboard[prefs.locale]}
    >
      <DashboardView
        data={data}
        locale={prefs.locale}
        query={searchParams}
        userName={session?.user.displayName}
        heroIntroSeen={heroIntroSeen}
      />
    </AppShellTemplate>
  );
}

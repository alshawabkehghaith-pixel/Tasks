import { cookies } from 'next/headers';

import {
  DASHBOARD_HERO_INTRO_COOKIE,
  hasSeenDashboardHeroIntroCookie,
} from '@/lib/hero-intro-storage';

import styles from './loading.module.css';

function Bone({ className }: { className?: string }): JSX.Element {
  return <div className={`${styles.bone} ${className ?? ''}`} />;
}

function CardSkeleton({ wide = false }: { wide?: boolean }): JSX.Element {
  return (
    <div className={wide ? styles.wideCardBone : styles.cardBone}>
      <div className={styles.cardHead}>
        <Bone className={styles.cardBadge} />
        <Bone className={styles.cardTitle} />
      </div>
      <Bone className={styles.chartBone} />
    </div>
  );
}

export default async function DashboardLoading(): Promise<JSX.Element> {
  const store = await cookies();
  const seen = hasSeenDashboardHeroIntroCookie(store.get(DASHBOARD_HERO_INTRO_COOKIE)?.value);

  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className={styles.srOnly}>جارٍ تحميل لوحة المعلومات</span>

      <div className={`${styles.heroBone} ${seen ? styles.heroBoneCompact : ''}`}>
        <div className={styles.heroInner}>
          <Bone className={styles.heroTitleBone} />
          <div className={styles.heroMetaRow}>
            <Bone className={styles.heroMetaBone} />
            <Bone className={styles.heroPeriodBone} />
          </div>
          <div className={styles.heroKpiRow}>
            <Bone className={styles.heroKpiBone} />
            <Bone className={styles.heroKpiBone} />
            <Bone className={styles.heroKpiBone} />
          </div>
        </div>
      </div>

      <div className={styles.sections}>
        <div className={styles.duo}>
          <CardSkeleton />
          <CardSkeleton />
        </div>
        <CardSkeleton wide />
        <div className={styles.duo}>
          <CardSkeleton />
          <CardSkeleton />
        </div>
      </div>
    </div>
  );
}

import { cookies } from 'next/headers';

import {
  DASHBOARD_HERO_INTRO_COOKIE,
  hasSeenDashboardHeroIntroCookie,
} from '@/lib/hero-intro-storage';

import styles from './loading.module.css';

export default async function DashboardLoading(): Promise<JSX.Element> {
  const store = await cookies();
  const seen = hasSeenDashboardHeroIntroCookie(store.get(DASHBOARD_HERO_INTRO_COOKIE)?.value);

  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className={styles.srOnly}>جارٍ تحميل لوحة المعلومات</span>
      <div className={`${styles.heroBone} ${seen ? styles.heroBoneCompact : ''}`} />
    </div>
  );
}

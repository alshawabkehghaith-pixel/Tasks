'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function DashboardError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="dashboard"
      titleAr="تعذّر تحميل لوحة المعلومات"
      titleEn="Dashboard could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

'use client';

import { useEffect } from 'react';

import { sstArabic } from '@/app/fonts';

interface GlobalErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function GlobalError({ error, reset }: GlobalErrorProps): JSX.Element {
  useEffect(() => {
    console.error('[global-error] root-level error:', error);
  }, [error]);

  return (
    <html lang="ar" dir="rtl" className={sstArabic.className}>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>خطأ — Job Matching Engine</title>
      </head>
      <body style={{ margin: 0, fontFamily: 'inherit', background: '#F6F7F5', color: '#14231F', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ maxWidth: 460, width: '100%', background: '#ffffff', border: '1px solid #E3E7E2', borderRadius: 18, padding: '36px 28px', display: 'flex', flexDirection: 'column', gap: 14, boxShadow: '0 6px 18px rgba(14,58,52,0.08)' }}>
          <p style={{ margin: 0, fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#5C6B65' }}>
            500 · خطأ غير متوقع
          </p>
          <h1 style={{ margin: 0, fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', lineHeight: 1.3 }}>
            حدث خطأ في التطبيق
          </h1>
          <p style={{ margin: 0, fontSize: 14, color: '#3F4D48', lineHeight: 1.6 }} dir="ltr">
            An unexpected error occurred. Please try again — if the problem persists, contact your system administrator.
          </p>
          <button
            type="button"
            onClick={() => {
              reset();
              window.location.reload();
            }}
            style={{ marginTop: 8, alignSelf: 'flex-start', background: '#348486', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 22px', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}
          >
            حاول مجدداً / Try again
          </button>
        </div>
      </body>
    </html>
  );
}

import { redirect } from 'next/navigation';

export default async function OutreachIndexPage(): Promise<never> {
  redirect('/outreach/targeting');
}

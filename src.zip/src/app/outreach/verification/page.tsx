import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { Stepper } from '@/components/outreach/stepper/Stepper';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { BatchVerificationTable } from '@/components/outreach/verification/batch-verification-table/BatchVerificationTable';
import { SingleCandidateVerification } from '@/components/outreach/verification/single-candidate-verification/SingleCandidateVerification';
import { EmptyState } from '@/components/ui/EmptyState';
import { messages } from '@/i18n/catalog';
import {
  fetchCandidateProfile,
  fetchSuggestedJobs,
  fetchVerificationBatch,
  fetchVerificationFacets,
} from '@/lib/api/backend';
import { getOutreachDraft } from '@/lib/outreach/draft-server';
import { parseJobSelForNin } from '@/lib/outreach/query';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { parsePositivePage } from '@/lib/pagination';
import { getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { JobLevel, VerificationBatchMode, VerificationBatchQuery } from '@/types/domain';
import type { AsyncSearchParamsProps } from '@/types/page';

const BATCH_PAGE_SIZE = 4;
const JOBS_PAGE_SIZE = 4;

const READINESS_LABEL_KEY: Record<'ready' | 'partial' | 'incomplete', 'cand360ReadinessReady' | 'cand360ReadinessPartial' | 'cand360ReadinessIncomplete'> = {
  ready: 'cand360ReadinessReady',
  partial: 'cand360ReadinessPartial',
  incomplete: 'cand360ReadinessIncomplete',
};

function isBatchMode(mode: string): mode is VerificationBatchMode {
  return mode === 'candidates' || mode === 'levels' || mode === 'custom' || mode === 'batchType';
}

export default async function OutreachVerificationPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;
  const draft = await getOutreachDraft();

  const steps = [
    messages.outreachStepTargeting[locale],
    messages.outreachStepVerification[locale],
    messages.outreachStepPreparation[locale],
    messages.outreachStepPublishing[locale],
  ];
  const stepHrefs = [
    '/outreach/targeting',
    '/outreach/verification',
    '/outreach/preparation',
    '/outreach/publishing',
  ];
  const backToTargetingHref = '/outreach/targeting';

  const mode = draft.mode;
  const drill = getQueryValue(searchParams.drill);
  const singleNin = mode === 'candidate' ? draft.nin : drill;

  const batchQuery: VerificationBatchQuery = {
    mode: isBatchMode(mode) ? mode : 'candidates',
    nins: draft.nins,
    levels: draft.levels,
    regions: draft.regions,
    batchType: draft.batchType || undefined,
    customFilters: mode === 'custom' && draft.customFilters ? draft.customFilters : undefined,
  };

  function shell(children: React.ReactNode): JSX.Element {
    return (
      <AppShellTemplate
        locale={locale}
        theme={prefs.theme}
        pathname="/outreach/verification"
        query={searchParams}
        title={messages.navOutreach[locale]}
      >
        <OutreachSidebar {...outreachSidebarProps(locale)}>
          <Stepper
            steps={steps}
            currentStepIndex={1}
            stepHrefs={stepHrefs}
            progressLabel={messages.outreachProgressLabel[locale]}
          />
          {children}
        </OutreachSidebar>
      </AppShellTemplate>
    );
  }

  const isSingle = (mode === 'candidate' && singleNin) || (isBatchMode(mode) && drill);
  if (isSingle && singleNin) {
    const [profile, suggested] = await Promise.all([
      fetchCandidateProfile(singleNin),
      fetchSuggestedJobs(singleNin, {
        page: parsePositivePage(getQueryValue(searchParams.jobsPage)),
        pageSize: JOBS_PAGE_SIZE,
      }),
    ]);

    if (!profile) {
      return shell(
        <EmptyState
          carded={false}
          title={messages.verifEmptyTitle[locale]}
          description={messages.verifEmptyDesc[locale]}
          ctaHref={backToTargetingHref}
          ctaLabel={messages.verifBackToTargeting[locale]}
        />,
      );
    }

    const jobsTotalPages = Math.max(1, Math.ceil(suggested.total / suggested.pageSize));

    let breadcrumb;
    if (drill && isBatchMode(mode)) {
      const facets = await fetchVerificationFacets(batchQuery);
      let batchName: string;
      if (mode === 'levels') {
        batchName = facets.levels.map((level) => level.label).join(' / ');
      } else if (mode === 'custom') {
        const cf = batchQuery.customFilters;
        const regionPart = cf?.regions.slice(0, 2).join('، ') ?? '';
        batchName = regionPart || messages.verifCustomBatch[locale];
      } else if (mode === 'batchType') {
        batchName = batchQuery.batchType === 'octoberBatch'
          ? messages.outreachBatchTypeOctoberLabel[locale]
          : messages.outreachBatchTypeFreshGradLabel[locale];
      } else {
        batchName = messages.verifBatchNameCandidates[locale];
      }
      breadcrumb = {
        kind: 'drill' as const,
        batchName: batchName || messages.verifBatchNameCandidates[locale],
        batchHref: '/outreach/verification',
        candidateName: profile.name,
      };
    } else {
      breadcrumb = { kind: 'direct' as const, backHref: backToTargetingHref };
    }

    const JOB_LEVEL_LABEL = {
      entry: messages.cand360JobLevelEntry[locale],
      mid: messages.cand360JobLevelMid[locale],
      senior: messages.cand360JobLevelSenior[locale],
    } as const;

    const jobselValue = draft.jobsel[singleNin] ?? '';
    const initialSelectedJobs = jobselValue === '*'
      ? ['*']
      : parseJobSelForNin(`${singleNin}:${jobselValue}`, singleNin);

    return shell(
      <SingleCandidateVerification
        candidate={{
          name: profile.name,
          nin: profile.nin,
          region: profile.region,
          city: profile.city,
          gender: profile.gender,
          age: profile.age,
          occupationalField: profile.occupationalField,
          qualification: profile.qualification,
          yearsExperience: profile.yearsExperience,
          jobLevelLabel: JOB_LEVEL_LABEL[profile.jobLevel] ?? profile.jobLevel,
          octoberBatch: profile.octoberBatch,
          freshGraduate: profile.freshGraduate,
          status: profile.status,
          strengths: profile.strengths.map((strength) => strength.label),
          readinessLabel: messages[READINESS_LABEL_KEY[profile.readiness]][locale],
          matchCount: profile.matches.length,
        }}
        jobs={suggested.rows}
        jobsPage={suggested.page}
        jobsTotalPages={jobsTotalPages}
        initialSelectedJobs={initialSelectedJobs}
        initialSel={draft.sel}
        initialMatchMap={draft.matchmap}
        initialJobsel={draft.jobsel}
        breadcrumb={breadcrumb}
        labels={{
          briefTitle: messages.verifBriefTitle[locale],
          ninLabel: messages.colNin[locale],
          locationLabel: messages.colRegion[locale],
          cityLabel: messages.colCity[locale],
          readinessTitle: messages.cand360ReadinessTitle[locale],
          briefMatchesTemplate: messages.verifBriefMatchesTemplate[locale],
          suggestedTitle: messages.verifSuggestedTitle[locale],
          whySuggested: messages.verifWhySuggested[locale],
          more: messages.verifMore[locale],
          less: messages.verifLess[locale],
          backToTargeting: messages.verifBackToTargeting[locale],
          prev: messages.verifPrev[locale],
          next: messages.verifNext[locale],
          pageTemplate: messages.verifPageTemplate[locale],
          genderLabel: messages.cand360Gender[locale],
          ageLabel: messages.cand360Age[locale],
          occupationalFieldLabel: messages.cand360OccupationalField[locale],
          qualificationLabel: messages.cand360Qualification[locale],
          yearsExpLabel: messages.cand360YearsExp[locale],
          jobLevelLabel: messages.cand360JobLevel[locale],
          octoberBatchLabel: messages.cand360OctoberBatch[locale],
          freshGraduateLabel: messages.cand360FreshGraduate[locale],
          statusLabel: messages.cand360Status[locale],
          strengthsLabel: messages.cand360Strengths[locale],
          yesLabel: messages.commonYes[locale],
          noLabel: messages.commonNo[locale],
          breadcrumbLabel: messages.verifBreadcrumbLabel[locale],
        }}
      />,
    );
  }

  if (isBatchMode(mode) && (draft.nins.length > 0 || draft.batchType || draft.customFilters || draft.levels.length > 0)) {
    const page = parsePositivePage(getQueryValue(searchParams.page));
    const query: VerificationBatchQuery = {
      ...batchQuery,
      search: getQueryValue(searchParams.q),
      region: getQueryValue(searchParams.region),
      level: (getQueryValue(searchParams.level) as JobLevel | '') || '',
      page,
      pageSize: BATCH_PAGE_SIZE,
    };

    const batch = await fetchVerificationBatch(query);
    const totalPages = Math.max(1, Math.ceil(batch.rows.total / batch.rows.pageSize));

    return shell(
      <BatchVerificationTable
        batchTotal={batch.batchTotal}
        rows={batch.rows.rows}
        page={batch.rows.page}
        totalPages={totalPages}
        filters={{
          search: getQueryValue(searchParams.q),
          region: getQueryValue(searchParams.region),
          level: getQueryValue(searchParams.level),
        }}
        initialSelected={draft.sel}
        initialJobsel={draft.jobsel}
        initialMatchMap={draft.matchmap}
        backToTargetingHref={backToTargetingHref}
        labels={{
          batchTotalTemplate: messages.verifBatchTotalTemplate[locale],
          searchPlaceholder: messages.verifSearchPlaceholder[locale],
          regionAll: messages.verifRegionAll[locale],
          levelAll: messages.verifLevelAll[locale],
          levelLabel: messages.verifLevelLabel[locale],
          regionLabel: messages.colRegion[locale],
          apply: messages.verifApply[locale],
          colSeeker: messages.verifColSeeker[locale],
          colRegion: messages.colRegion[locale],
          colCity: messages.colCity[locale],
          colOccupationalField: messages.colOccupationalField[locale],
          colOctoberBatch: messages.colOctoberBatch[locale],
          colFreshGraduate: messages.colFreshGraduate[locale],
          colTopMatch: messages.verifColTopMatch[locale],
          colJobMatches: messages.verifColJobMatches[locale],
          selectAria: messages.verifSelectAria[locale],
          readyForPrep: messages.verifReadyForPrep[locale],
          totalJobMatchesTemplate: messages.verifTotalJobMatchesTemplate[locale],
          backToTargeting: messages.verifBackToTargeting[locale],
          pageTemplate: messages.verifPageTemplate[locale],
          prev: messages.verifPrev[locale],
          next: messages.verifNext[locale],
          noResults: messages.verifNoResults[locale],
          verifyHere: messages.verifVerifyHere[locale],
          yes: messages.commonYes[locale],
          no: messages.commonNo[locale],
        }}
      />,
    );
  }

  return shell(
    <EmptyState
      carded={false}
      title={messages.verifEmptyTitle[locale]}
      description={messages.verifEmptyDesc[locale]}
      ctaHref={backToTargetingHref}
      ctaLabel={messages.verifBackToTargeting[locale]}
    />,
  );
}

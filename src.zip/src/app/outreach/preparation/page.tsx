import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { Stepper } from '@/components/outreach/stepper/Stepper';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { PreparationWorkspace, type PreparationWorkspaceLabels } from '@/components/outreach/preparation/preparation-workspace/PreparationWorkspace';
import { EmptyState } from '@/components/ui/EmptyState';
import { messages } from '@/i18n/catalog';
import { fetchCandidateProfile } from '@/lib/api/backend';
import { buildCampaignSessionKey } from '@/lib/campaign-utils';
import { getOutreachDraft } from '@/lib/outreach/draft-server';
import { hydratePublishTargets } from '@/lib/outreach/hydrate-targets';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { PreparationRepresentative } from '@/types/domain';
import type { AsyncSearchParamsProps } from '@/types/page';

function levelLabel(key: string, locale: 'ar' | 'en'): string {
  if (key === 'entry') return messages.cand360JobLevelEntry[locale];
  if (key === 'mid') return messages.cand360JobLevelMid[locale];
  if (key === 'senior') return messages.cand360JobLevelSenior[locale];
  return key;
}

function deriveBatchName(
  mode: string,
  levels: string[],
  regions: string[],
  locale: 'ar' | 'en',
): string {
  if (mode === 'levels') {
    return levels.map((key) => levelLabel(key, locale)).join(' / ');
  }
  if (mode === 'custom') {
    const parts: string[] = [];
    if (regions.length > 0) parts.push(regions.join('، '));
    if (levels.length > 0) {
      parts.push(levels.map((k) => levelLabel(k, locale)).join('/'));
    }
    return parts.join(' · ') || messages.verifCustomBatch[locale];
  }
  if (mode === 'candidate' || mode === 'candidates') {
    return messages.verifSelectedCandidates[locale];
  }
  if (mode === 'batchType') {
    return messages.verifBatchNameCandidates[locale];
  }
  return '';
}

export default async function OutreachPreparationPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;
  const draft = await getOutreachDraft();

  const steps = [
    messages.outreachStepTargeting[locale],
    messages.outreachStepVerification[locale],
    messages.outreachStepPreparation[locale],
    messages.outreachStepPublishing[locale],
  ];
  const stepHrefs = [
    '/outreach/targeting',
    '/outreach/verification',
    '/outreach/preparation',
    '/outreach/publishing',
  ];

  const selNins = draft.sel;
  const targetCount = selNins.length;
  const batchName = deriveBatchName(draft.mode, draft.levels, draft.regions, locale);
  const sessionKey = buildCampaignSessionKey(selNins.join(','), draft.mode);

  const backToVerificationHref = '/outreach/verification';
  const publishingHref = '/outreach/publishing';

  const initialTargets = await hydratePublishTargets(selNins, draft.jobsel);

  let representative: PreparationRepresentative | null = null;
  if (selNins.length > 0) {
    const firstNin = selNins[0]!;
    try {
      const firstTarget = initialTargets.find((t) => t.nin === firstNin);
      const profile = await fetchCandidateProfile(firstNin);
      if (firstTarget) {
        representative = {
          name: firstTarget.name,
          nin: firstNin,
          selectedJobLines: firstTarget.jobTitles,
          missingFieldsEn: profile?.readinessDrivers.map((driver) => driver.field) ?? [],
        };
      }
    } catch {
    }
  }

  const labels: PreparationWorkspaceLabels = {
    subStepDesign: messages.prepSubStepDesign[locale],
    subStepWriting: messages.prepSubStepWriting[locale],
    subStepReview: messages.prepSubStepReview[locale],
    purposeLabel: messages.prepPurposeLabel[locale],
    purposeVacancyTitle: messages.prepPurposeVacancyTitle[locale],
    purposeVacancyDesc: messages.prepPurposeVacancyDesc[locale],
    purposeCompletenessTitle: messages.prepPurposeCompletenessTitle[locale],
    purposeCompletenessDesc: messages.prepPurposeCompletenessDesc[locale],
    purposeSwitchConfirmTitle: messages.prepPurposeSwitchConfirmTitle[locale],
    purposeSwitchConfirmBody: messages.prepPurposeSwitchConfirmBody[locale],
    purposeSwitchConfirmOk: messages.prepPurposeSwitchConfirmOk[locale],
    purposeSwitchConfirmCancel: messages.prepPurposeSwitchConfirmCancel[locale],
    subjectLabel: messages.prepSubjectLabel[locale],
    bodyLabel: messages.prepBodyLabel[locale],
    subjectEmptyError: messages.prepSubjectEmptyError[locale],
    bodyEmptyError: messages.prepBodyEmptyError[locale],
    reviewCheckTargets: messages.prepReviewCheckTargets[locale],
    reviewBatchLabel: messages.prepReviewBatchLabel[locale],
    reviewChannelLabel: messages.prepReviewChannelLabel[locale],
    reviewPurposeLabel: messages.prepReviewPurposeLabel[locale],
    reviewChannelEmail: messages.prepReviewChannelEmail[locale],
    reviewPurposeVacancy: messages.prepReviewPurposeVacancy[locale],
    reviewPurposeCompleteness: messages.prepReviewPurposeCompleteness[locale],
    reviewViewCandidates: messages.prepViewCandidates[locale],
    reviewHideCandidates: messages.prepHideCandidates[locale],
    reviewRemoveCandidate: messages.prepRemoveCandidate[locale],
    reviewPageTemplate: messages.prepReviewPageTemplate[locale],
    reviewPrev: messages.prepReviewPrev[locale],
    reviewNext: messages.prepReviewNext[locale],
    continueToPublishing: messages.prepContinueToPublishing[locale],
    nextToWriting: messages.prepNextToWriting[locale],
    nextToReview: messages.prepNextToReview[locale],
    prevToDesign: messages.prepPrevToDesign[locale],
    prevToWriting: messages.prepPrevToWriting[locale],
    backToVerification: messages.prepBackToVerification[locale],
    previewTitle: messages.prepPreviewTitle[locale],
    previewCaptionTemplate: messages.prepPreviewCaptionTemplate[locale],
    previewSubjectLabel: messages.prepPreviewSubjectLabel[locale],
    previewCtaVacancy: messages.prepPreviewCtaVacancy[locale],
    previewCtaCompleteness: messages.prepPreviewCtaCompleteness[locale],
    previewLinkText: messages.prepPreviewLinkText[locale],
    previewNoSelection: messages.prepPreviewNoSelection[locale],
  };

  if (targetCount === 0) {
    return (
      <AppShellTemplate
        locale={locale}
        theme={prefs.theme}
        pathname="/outreach/preparation"
        query={searchParams}
        title={messages.navOutreach[locale]}
      >
        <OutreachSidebar {...outreachSidebarProps(locale)}>
          <Stepper
            steps={steps}
            currentStepIndex={2}
            stepHrefs={stepHrefs}
            progressLabel={messages.outreachProgressLabel[locale]}
          />
          <EmptyState
            carded={false}
            title={messages.prepEmptyStateTitle[locale]}
            description={messages.prepEmptyStateDesc[locale]}
            ctaHref={backToVerificationHref}
            ctaLabel={labels.backToVerification}
          />
        </OutreachSidebar>
      </AppShellTemplate>
    );
  }

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/outreach/preparation"
      query={searchParams}
      title={messages.navOutreach[locale]}
    >
      <OutreachSidebar {...outreachSidebarProps(locale)}>
        <Stepper
          steps={steps}
          currentStepIndex={2}
          stepHrefs={stepHrefs}
          progressLabel={messages.outreachProgressLabel[locale]}
        />
        <PreparationWorkspace
          representative={representative}
          initialTargets={initialTargets}
          batchName={batchName}
          sessionKey={sessionKey}
          publishingHref={publishingHref}
          backToVerificationHref={backToVerificationHref}
          labels={labels}
        />
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { Stepper } from '@/components/outreach/stepper/Stepper';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { TargetingWorkspace, type TargetingWorkspaceLabels } from '@/components/outreach/targeting-workspace/TargetingWorkspace';
import { messages } from '@/i18n/catalog';
import { fetchBatchTypes, fetchCandidateBatchPreview, fetchCandidateFacets, fetchCandidatesByNins } from '@/lib/api/backend';
import { getOutreachDraft } from '@/lib/outreach/draft-server';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { AsyncSearchParamsProps } from '@/types/page';

export default async function OutreachTargetingPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;
  const draft = await getOutreachDraft();

  const [facets, batchTypeBatches] = await Promise.all([
    fetchCandidateFacets(),
    fetchBatchTypes(),
  ]);

  let initialSelection: Parameters<typeof TargetingWorkspace>[0]['initialSelection'];

  if ((draft.mode === 'candidate' || draft.mode === 'candidates') && draft.nins.length > 0) {
    const candidates = await fetchCandidatesByNins(draft.nins);
    if (candidates.length > 0) {
      initialSelection = { candidates };
    }
  } else if (draft.mode === 'custom' && draft.customFilters) {
    const filters = draft.customFilters;
    const hasFilter = Object.values(filters).some((arr) => arr.length > 0);
    if (hasFilter) {
      const count = await fetchCandidateBatchPreview({ filters });
      initialSelection = { customBatch: { filters, count } };
    }
  } else if (draft.mode === 'batchType' && draft.batchType) {
    initialSelection = { batchType: draft.batchType };
  }

  const steps = [
    messages.outreachStepTargeting[locale],
    messages.outreachStepVerification[locale],
    messages.outreachStepPreparation[locale],
    messages.outreachStepPublishing[locale],
  ];

  const stepHrefs = [
    '/outreach/targeting',
    '/outreach/verification',
    '/outreach/preparation',
    '/outreach/publishing',
  ];

  const labels: TargetingWorkspaceLabels = {
    summaryTitle: messages.outreachSummaryTitle[locale],
    channelRowLabel: messages.outreachChannelRowLabel[locale],
    channelEmail: messages.outreachChannelEmail[locale],
    frequencyRowLabel: messages.outreachFrequencyRowLabel[locale],
    frequencyValue: messages.outreachFrequencyValue[locale],
    frequencyCaption: messages.outreachFrequencyCaption[locale],
    targetRowLabel: messages.outreachTargetRowLabel[locale],
    targetNoneSelected: messages.outreachTargetNoneSelected[locale],
    targetCandidatesCountTemplate: messages.outreachTargetCandidatesCount[locale],
    targetBatchCaption: messages.outreachTargetBatchCaption[locale],
    campaignTitle: messages.outreachCampaignTitle[locale],
    campaignDesc: messages.outreachCampaignDesc[locale],
    findCandidatesTitle: messages.outreachFindCandidatesTitle[locale],
    searchPlaceholder: messages.outreachSearchPlaceholder[locale],
    jobMatchesCountTemplate: messages.outreachJobMatchesCount[locale],
    removeChip: messages.outreachRemoveChip[locale],
    orJobLevelDivider: messages.outreachOrJobLevelDivider[locale],
    batchTypeOctoberLabel: messages.outreachBatchTypeOctoberLabel[locale],
    batchTypeFreshGradLabel: messages.outreachBatchTypeFreshGradLabel[locale],
    orCustomBatchDivider: messages.outreachOrCustomBatchDivider[locale],
    customBatchClearAll: messages.outreachCustomBatchClearAll[locale],
    previewSelectFilter: messages.outreachPreviewSelectFilter[locale],
    previewNoMatch: messages.outreachPreviewNoMatch[locale],
    previewMatchSuffix: messages.outreachPreviewMatchSuffix[locale],
    disclaimer: messages.outreachDisclaimer[locale],
    nextButton: messages.outreachNextButton[locale],
  };

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/outreach/targeting"
      query={searchParams}
      title={messages.navOutreach[locale]}
    >
      <OutreachSidebar {...outreachSidebarProps(locale)}>
        <Stepper
          steps={steps}
          currentStepIndex={0}
          stepHrefs={stepHrefs}
          progressLabel={messages.outreachProgressLabel[locale]}
        />
        <TargetingWorkspace
          locale={locale}
          facets={facets}
          batchTypeBatches={batchTypeBatches}
          labels={labels}
          initialSelection={initialSelection}
        />
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

import styles from './loading.module.css';

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function OutreachLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل مساحة عمل التواصل بالحملات</span>

      <div className={styles.wrapper}>
        <div className={styles.sidebar}>
          <Bone h={40} r={10} />
          <Bone h={40} r={10} />
        </div>

        <div className={styles.content}>
          <div className={styles.stepper}>
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className={styles.step}>
                <Bone h={30} w="30px" r={999} />
                <Bone h={12} w="60px" r={4} />
              </div>
            ))}
          </div>

          <div className={styles.main}>
            <Bone h={280} r={14} />
            <Bone h={420} r={14} />
          </div>
        </div>
      </div>
    </div>
  );
}

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { Stepper } from '@/components/outreach/stepper/Stepper';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { PublishingStep, type PublishingStepLabels } from '@/components/outreach/publishing/publishing-step/PublishingStep';
import type { ReviewStepLabels } from '@/components/outreach/preparation/review-step/ReviewStep';
import { EmptyState } from '@/components/ui/EmptyState';
import { messages } from '@/i18n/catalog';
import { buildCampaignSessionKey } from '@/lib/campaign-utils';
import { getOutreachDraft } from '@/lib/outreach/draft-server';
import { hydratePublishTargets } from '@/lib/outreach/hydrate-targets';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { AsyncSearchParamsProps } from '@/types/page';

function levelLabel(key: string, locale: 'ar' | 'en'): string {
  if (key === 'entry') return messages.cand360JobLevelEntry[locale];
  if (key === 'mid') return messages.cand360JobLevelMid[locale];
  if (key === 'senior') return messages.cand360JobLevelSenior[locale];
  return key;
}

function deriveBatchName(
  mode: string,
  levels: string[],
  regions: string[],
  locale: 'ar' | 'en',
): string {
  if (mode === 'levels') {
    return levels.map((key) => levelLabel(key, locale)).join(' / ');
  }
  if (mode === 'custom') {
    const parts: string[] = [];
    if (regions.length > 0) parts.push(regions.join('، '));
    if (levels.length > 0) {
      parts.push(levels.map((k) => levelLabel(k, locale)).join('/'));
    }
    return parts.join(' · ') || messages.verifCustomBatch[locale];
  }
  if (mode === 'candidate' || mode === 'candidates') {
    return messages.verifSelectedCandidates[locale];
  }
  if (mode === 'batchType') {
    return messages.verifBatchNameCandidates[locale];
  }
  return '';
}

export default async function OutreachPublishingPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;
  const draft = await getOutreachDraft();

  const steps = [
    messages.outreachStepTargeting[locale],
    messages.outreachStepVerification[locale],
    messages.outreachStepPreparation[locale],
    messages.outreachStepPublishing[locale],
  ];
  const stepHrefs = [
    '/outreach/targeting',
    '/outreach/verification',
    '/outreach/preparation',
    '/outreach/publishing',
  ];

  const selNins = draft.sel;
  const backHref = '/outreach/preparation';
  const startNewHref = '/outreach/targeting';
  const sessionKey = buildCampaignSessionKey(selNins.join(','), draft.mode);
  const batchName = deriveBatchName(draft.mode, draft.levels, draft.regions, locale);

  const labels: PublishingStepLabels = {
    reviewColumnTitle: messages.pubColumnReview[locale],
    publishColumnTitle: messages.pubColumnPublish[locale],
    headline: messages.pubHeadline[locale],
    subtext: messages.pubSubtext[locale],
    channelLabel: messages.pubChannelLabel[locale],
    channelEmail: messages.pubChannelEmail[locale],
    frequencyLabel: messages.outreachFrequencyRowLabel[locale],
    frequencyValue: messages.outreachFrequencyValue[locale],
    back: messages.pubBack[locale],
    publish: messages.pubPublish[locale],
    publishing: messages.pubPublishing[locale],
    confirmTitle: messages.pubConfirmTitle[locale],
    confirmBodyTemplate: messages.pubConfirmBodyTemplate[locale],
    confirmOk: messages.pubConfirmOk[locale],
    confirmCancel: messages.pubConfirmCancel[locale],
    successTitle: messages.pubSuccessTitle[locale],
    successBodyTemplate: messages.pubSuccessBodyTemplate[locale],
    startNew: messages.pubStartNew[locale],
    errorTitle: messages.pubErrorTitle[locale],
    errorBody: messages.pubErrorBody[locale],
    retry: messages.pubRetry[locale],
  };

  const reviewLabels: ReviewStepLabels = {
    candidatesCountLabel: messages.pubTotalCandidatesLabel[locale],
    batchLabel: messages.prepReviewBatchLabel[locale],
    purposeLabel: messages.prepReviewPurposeLabel[locale],
    purposeVacancy: messages.prepReviewPurposeVacancy[locale],
    purposeCompleteness: messages.prepReviewPurposeCompleteness[locale],
    viewCandidates: messages.prepViewCandidates[locale],
    hideCandidates: messages.prepHideCandidates[locale],
    removeCandidate: messages.prepRemoveCandidate[locale],
    pageTemplate: messages.prepReviewPageTemplate[locale],
    prev: messages.prepReviewPrev[locale],
    next: messages.prepReviewNext[locale],
  };

  const sidebarProps = outreachSidebarProps(locale);

  if (selNins.length === 0) {
    return (
      <AppShellTemplate
        locale={locale}
        theme={prefs.theme}
        pathname="/outreach/publishing"
        query={searchParams}
        title={messages.navOutreach[locale]}
      >
        <OutreachSidebar {...sidebarProps}>
          <Stepper
            steps={steps}
            currentStepIndex={3}
            stepHrefs={stepHrefs}
            progressLabel={messages.outreachProgressLabel[locale]}
          />
          <EmptyState
            carded={false}
            title={messages.pubEmptyTitle[locale]}
            description={messages.pubEmptyDesc[locale]}
            ctaHref="/outreach/verification"
            ctaLabel={messages.verifBackToVerification[locale]}
          />
        </OutreachSidebar>
      </AppShellTemplate>
    );
  }

  const targets = await hydratePublishTargets(selNins, draft.jobsel);

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/outreach/publishing"
      query={searchParams}
      title={messages.navOutreach[locale]}
    >
      <OutreachSidebar {...sidebarProps}>
        <Stepper
          steps={steps}
          currentStepIndex={3}
          stepHrefs={stepHrefs}
          progressLabel={messages.outreachProgressLabel[locale]}
        />
        <PublishingStep
          targets={targets}
          batchName={batchName}
          sessionKey={sessionKey}
          backHref={backHref}
          startNewHref={startNewHref}
          labels={labels}
          reviewLabels={reviewLabels}
        />
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

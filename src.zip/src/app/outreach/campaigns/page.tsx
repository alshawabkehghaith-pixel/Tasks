import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { ClickableRow } from '@/components/ui/ClickableRow';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { messages } from '@/i18n/catalog';
import { fetchCampaigns } from '@/lib/api/backend';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { buildPagerTokens, parsePositivePage } from '@/lib/pagination';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { CampaignPurpose } from '@/types/domain';
import type { AsyncSearchParamsProps } from '@/types/page';

import campStyles from './campaigns.module.css';

const PAGE_SIZE = 25;

export const metadata: Metadata = {
  title: 'سجل الحملات — Campaigns log',
};

function purposeLabel(purpose: CampaignPurpose, locale: 'ar' | 'en'): string {
  return purpose === 'vacancy'
    ? messages.campLogPurposeVacancy[locale]
    : messages.campLogPurposeCompleteness[locale];
}

function formatDate(iso: string, locale: 'ar' | 'en'): string {
  try {
    return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-SA' : 'en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export default async function CampaignsLogPage({
  searchParams: searchParamsPromise,
}: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const page = parsePositivePage(getQueryValue(searchParams.page));
  const purposeParam = getQueryValue(searchParams.purpose);
  const purpose = (purposeParam === 'vacancy' || purposeParam === 'completeness')
    ? (purposeParam as CampaignPurpose)
    : undefined;

  const result = await fetchCampaigns({ purpose, page, pageSize: PAGE_SIZE });

  const totalPages = Math.max(1, Math.ceil(result.total / PAGE_SIZE));
  const baseQuery = { purpose: purposeParam || undefined, page: undefined };
  const pagerBase = '/outreach/campaigns';

  if (page > totalPages) {
    redirect(buildHref(pagerBase, baseQuery, { page: String(totalPages) }));
  }

  const pagerTokens = buildPagerTokens(page, totalPages);

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/outreach/campaigns"
      query={searchParams}
      title={messages.campLogTitle[locale]}
    >
      <OutreachSidebar {...outreachSidebarProps(locale)}>
        <SurfaceCard className="list-table-card">
          <div className={`filter-bar ${campStyles.purposeFilter}`} role="group" aria-label={messages.campLogColPurpose[locale]}>
            {([undefined, 'vacancy', 'completeness'] as Array<CampaignPurpose | undefined>).map((p) => {
              const label = p === undefined
                ? messages.campLogFilterAll[locale]
                : purposeLabel(p, locale);
              const isActive = purpose === p;
              const href = buildHref(pagerBase, {}, p ? { purpose: p } : {});
              const toneClass = p === undefined
                ? (isActive ? campStyles.chipAllActive : '')
                : p === 'vacancy'
                  ? (isActive ? campStyles.chipVacancyActive : campStyles.chipVacancy)
                  : (isActive ? campStyles.chipCompletenessActive : campStyles.chipCompleteness);

              return (
                <Link
                  key={p ?? 'all'}
                  href={href}
                  className={[campStyles.chip, toneClass].filter(Boolean).join(' ')}
                  aria-current={isActive ? 'true' : undefined}
                >
                  <span className={campStyles.chipDot} aria-hidden="true" />
                  {label}
                </Link>
              );
            })}
          </div>

          <div className="rescount" aria-live="polite">
            {result.total.toLocaleString(locale)} {messages.resultsCount[locale]}
          </div>

          <div className="overflow-x-auto">
            <table className="ltbl">
              <thead>
                <tr>
                  <th scope="col">{messages.campLogColCreatedBy[locale]}</th>
                  <th scope="col">{messages.campLogColPurpose[locale]}</th>
                  <th scope="col" className="ta-end">{messages.campLogColCandidates[locale]}</th>
                  <th scope="col">{messages.campLogColDate[locale]}</th>
                  <th aria-hidden="true" />
                </tr>
              </thead>
              <tbody>
                {result.rows.length ? (
                  result.rows.map((row) => {
                    const detailHref = `/outreach/campaigns/${row.id}`;
                    return (
                      <ClickableRow key={row.id} href={detailHref}>
                        <td className="lname">
                          <Link href={detailHref}>{row.createdBy}</Link>
                        </td>
                        <td>
                          <span
                            className={`${campStyles.purposeMark} ${
                              row.purpose === 'vacancy'
                                ? campStyles.purposeVacancy
                                : campStyles.purposeCompleteness
                            }`}
                          >
                            <span className={campStyles.purposeDot} aria-hidden="true" />
                            {purposeLabel(row.purpose, locale)}
                          </span>
                        </td>
                        <td className="mono ta-end">{row.candidateCount}</td>
                        <td className="mono">{formatDate(row.sentAt, locale)}</td>
                        <td className="list-view-cell">
                          <span className="list-view-hint">
                            <span>{messages.campLogViewCampaign[locale]}</span>
                            {locale === 'ar'
                              ? <ArrowLeft size={13} strokeWidth={2.2} aria-hidden="true" />
                              : <ArrowRight size={13} strokeWidth={2.2} aria-hidden="true" />}
                          </span>
                        </td>
                      </ClickableRow>
                    );
                  })
                ) : (
                  <tr>
                    <td className="empty" colSpan={5}>
                      <div className={campStyles.emptyTitle}>{messages.campLogEmptyTitle[locale]}</div>
                      <div className={campStyles.emptyDesc}>{messages.campLogEmptyDesc[locale]}</div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {totalPages > 1 ? (
            <nav className="pager" aria-label={messages.pagerNavLabel[locale]}>
              {page > 1 ? (
                <Link href={buildHref(pagerBase, baseQuery, { page: String(page - 1) })} aria-label={messages.pagerPrevPage[locale]}>
                  <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
                </Link>
              ) : (
                <span className="dis" aria-hidden="true">
                  <ChevronLeft size={14} strokeWidth={2.2} />
                </span>
              )}
              {pagerTokens.map((token, index) => {
                if (token === 'gap') {
                  return (
                    <span key={`gap-${index}`} className="gap" aria-hidden="true">
                      ...
                    </span>
                  );
                }
                return token === page ? (
                  <span key={token} className="cur" aria-current="page">{token}</span>
                ) : (
                  <Link
                    key={token}
                    href={buildHref(pagerBase, baseQuery, { page: String(token) })}
                    aria-label={messages.pagerGoToPage[locale].replace('{n}', String(token))}
                  >
                    {token}
                  </Link>
                );
              })}
              {page < totalPages ? (
                <Link href={buildHref(pagerBase, baseQuery, { page: String(page + 1) })} aria-label={messages.pagerNextPage[locale]}>
                  <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
                </Link>
              ) : (
                <span className="dis" aria-hidden="true">
                  <ChevronRight size={14} strokeWidth={2.2} />
                </span>
              )}
            </nav>
          ) : null}
        </SurfaceCard>
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

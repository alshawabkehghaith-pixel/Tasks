import styles from './loading.module.css';

const ROW_COUNT = 10;
const COLUMN_COUNT = 5;

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function CampaignsLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل سجل الحملات</span>

      <div className={styles.wrapper}>
        <div className={styles.sidebar}>
          <Bone h={40} r={10} />
          <Bone h={40} r={10} />
        </div>

        <div className={styles.content}>
          <div className={styles.card}>
            <div className={styles.filterRow}>
              <Bone h={28} w="90px" r={999} />
              <Bone h={28} w="110px" r={999} />
              <Bone h={28} w="140px" r={999} />
            </div>

            <div className={styles.count}>
              <Bone h={14} w="90px" r={4} />
            </div>

            <div className={`${styles.row} ${styles.head}`}>
              {Array.from({ length: COLUMN_COUNT }).map((_, i) => (
                <Bone key={i} h={12} r={4} />
              ))}
            </div>

            <div className={styles.body}>
              {Array.from({ length: ROW_COUNT }).map((_, rowIndex) => (
                <div key={rowIndex} className={styles.row}>
                  {Array.from({ length: COLUMN_COUNT }).map((_, colIndex) => (
                    <Bone key={colIndex} h={13} r={4} />
                  ))}
                </div>
              ))}
            </div>

            <div className={styles.pager}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Bone key={i} h={32} w="32px" r={8} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

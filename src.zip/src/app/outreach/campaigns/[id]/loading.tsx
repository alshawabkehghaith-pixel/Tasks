import styles from './loading.module.css';

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function CampaignDetailLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل تفاصيل الحملة</span>

      <div className={styles.wrapper}>
        <div className={styles.sidebar}>
          <Bone h={40} r={10} />
          <Bone h={40} r={10} />
        </div>

        <div className={styles.content}>
          <div className={styles.backLink}>
            <Bone h={14} w="120px" r={4} />
          </div>

          <div className={styles.card}>
            <div className={styles.summary}>
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i}>
                  <Bone h={11} w="60%" r={4} />
                  <div style={{ marginTop: 8 }}>
                    <Bone h={22} w="70%" r={6} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={styles.card}>
            <div style={{ marginBottom: 10 }}>
              <Bone h={14} w="90px" r={4} />
            </div>
            <div className={`${styles.row} ${styles.head}`}>
              {Array.from({ length: 6 }).map((_, i) => (
                <Bone key={i} h={12} r={4} />
              ))}
            </div>
            <div className={styles.body}>
              {Array.from({ length: 8 }).map((_, rowIndex) => (
                <div key={rowIndex} className={styles.row}>
                  {Array.from({ length: 6 }).map((_, colIndex) => (
                    <Bone key={colIndex} h={13} r={4} />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

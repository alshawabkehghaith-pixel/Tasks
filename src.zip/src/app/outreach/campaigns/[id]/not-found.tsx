import Link from 'next/link';

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { EmptyState } from '@/components/ui/EmptyState';
import { messages } from '@/i18n/catalog';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { getServerAppPreferences } from '@/lib/server/preferences';

export default async function CampaignNotFound(): Promise<JSX.Element> {
  const prefs = await getServerAppPreferences({});
  const locale = prefs.locale;

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/outreach/campaigns"
      query={{}}
      title={messages.campDetailTitle[locale]}
    >
      <OutreachSidebar {...outreachSidebarProps(locale)}>
        <Link className="back-link" href="/outreach/campaigns">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M15 6l-6 6 6 6" />
          </svg>
          {messages.campDetailBreadcrumb[locale]}
        </Link>
        <EmptyState
          title={messages.campDetailNotFound[locale]}
          description={messages.campDetailNotFoundDesc[locale]}
        />
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

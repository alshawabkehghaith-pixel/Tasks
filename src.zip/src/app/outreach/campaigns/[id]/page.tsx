import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { CheckCircle2, ChevronLeft, ChevronRight, XCircle } from 'lucide-react';

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { OutreachSidebar } from '@/components/outreach/OutreachSidebar';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { messages } from '@/i18n/catalog';
import { fetchCampaignDetail } from '@/lib/api/backend';
import { outreachSidebarProps } from '@/lib/outreach/sidebar';
import { buildPagerTokens, parsePositivePage } from '@/lib/pagination';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { CampaignPurpose } from '@/types/domain';
import type { AsyncRouteProps } from '@/types/page';

import styles from './campaign-detail.module.css';
import campStyles from '../campaigns.module.css';

const PAGE_SIZE = 25;

function purposeLabel(purpose: CampaignPurpose, locale: 'ar' | 'en'): string {
  return purpose === 'vacancy'
    ? messages.campLogPurposeVacancy[locale]
    : messages.campLogPurposeCompleteness[locale];
}

function formatDate(iso: string, locale: 'ar' | 'en'): string {
  try {
    return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-SA' : 'en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export async function generateMetadata({
  params: paramsPromise,
  searchParams: searchParamsPromise,
}: AsyncRouteProps<{ id: string }>): Promise<Metadata> {
  const [params, searchParams] = await Promise.all([paramsPromise, searchParamsPromise]);
  const prefs = await getServerAppPreferences({});
  const campaignId = Number(params.id);
  if (!campaignId || Number.isNaN(campaignId)) {
    return { title: messages.campDetailNotFound[prefs.locale] };
  }

  const page = parsePositivePage(getQueryValue(searchParams.page));
  const detail = await fetchCampaignDetail(campaignId, { page, pageSize: PAGE_SIZE });
  return {
    title: detail
      ? `${messages.campDetailTitle[prefs.locale]} · ${detail.header.createdBy}`
      : messages.campDetailNotFound[prefs.locale],
  };
}

export default async function CampaignDetailPage({
  params: paramsPromise,
  searchParams: searchParamsPromise,
}: AsyncRouteProps<{ id: string }>): Promise<JSX.Element> {
  const [params, searchParams] = await Promise.all([paramsPromise, searchParamsPromise]);
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const campaignId = Number(params.id);
  if (!campaignId || Number.isNaN(campaignId)) notFound();

  const page = parsePositivePage(getQueryValue(searchParams.page));
  const detail = await fetchCampaignDetail(campaignId, { page, pageSize: PAGE_SIZE });
  if (!detail) notFound();

  const { header, rows } = detail;
  const totalPages = Math.max(1, Math.ceil(detail.total / PAGE_SIZE));
  const pagerBase = `/outreach/campaigns/${campaignId}`;

  if (page > totalPages) {
    redirect(buildHref(pagerBase, {}, { page: String(totalPages) }));
  }

  const pagerTokens = buildPagerTokens(page, totalPages);

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname={pagerBase}
      query={searchParams}
      title={messages.campDetailTitle[locale]}
    >
      <OutreachSidebar {...outreachSidebarProps(locale)}>
        <Link className="back-link" href="/outreach/campaigns">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M15 6l-6 6 6 6" />
          </svg>
          {messages.campDetailBreadcrumb[locale]}
        </Link>

        <SurfaceCard>
          <div className={styles.summary}>
            <div>
              <div className={styles.summaryLabel}>{messages.campDetailHeaderPurpose[locale]}</div>
              <span
                className={`${campStyles.purposeMark} ${
                  header.purpose === 'vacancy'
                    ? campStyles.purposeVacancy
                    : campStyles.purposeCompleteness
                }`}
              >
                <span className={campStyles.purposeDot} aria-hidden="true" />
                {purposeLabel(header.purpose, locale)}
              </span>
            </div>

            <div>
              <div className={styles.summaryLabel}>{messages.campDetailHeaderCandidates[locale]}</div>
              <div className={styles.summaryCount}>{header.candidateCount.toLocaleString(locale)}</div>
            </div>

            <div>
              <div className={styles.summaryLabel}>{messages.campDetailHeaderDate[locale]}</div>
              <div className={styles.summaryDate}>{formatDate(header.sentAt, locale)}</div>
            </div>

            <div>
              <div className={styles.summaryLabel}>{messages.campDetailHeaderCreatedBy[locale]}</div>
              <div className={styles.summaryValue}>{header.createdBy}</div>
            </div>
          </div>
        </SurfaceCard>

        <SurfaceCard className="list-table-card">
          <div className="rescount" aria-live="polite">
            {detail.total.toLocaleString(locale)} {messages.resultsCount[locale]}
          </div>

          <div className="overflow-x-auto">
            <table className="ltbl ltblStatic">
              <thead>
                <tr>
                  <th scope="col">{messages.campDetailColCandidate[locale]}</th>
                  <th scope="col">{messages.campDetailColJob[locale]}</th>
                  <th scope="col">{messages.campDetailColEmployer[locale]}</th>
                  <th scope="col" className="ta-end">{messages.campDetailColScore[locale]}</th>
                  <th scope="col" className="ta-center">{messages.campDetailColStatus[locale]}</th>
                  <th scope="col">{messages.campDetailColDate[locale]}</th>
                </tr>
              </thead>
              <tbody>
                {rows.length ? (
                  rows.map((row) => {
                    const isSent = row.notificationStatus === 'sent';
                    return (
                      <tr key={row.rowId}>
                        <td className="lname">{row.candidateName}</td>
                        <td>{row.jobTitle}</td>
                        <td>{row.employer}</td>
                        <td className="mono ta-end">{row.matchScore > 0 ? `${row.matchScore.toFixed(1)}%` : '—'}</td>
                        <td className="ta-center">
                          <span className={`pill ${isSent ? 'ready' : 'incomplete'} ${styles.statusPill}`}>
                            {isSent
                              ? <CheckCircle2 size={12} strokeWidth={2.2} aria-hidden="true" />
                              : <XCircle size={12} strokeWidth={2.2} aria-hidden="true" />}
                            {isSent ? messages.campDetailStatusSent[locale] : messages.campDetailStatusNotSent[locale]}
                          </span>
                        </td>
                        <td className="mono">{formatDate(row.notifiedAt, locale)}</td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td className="empty" colSpan={6}>{messages.noResults[locale]}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {totalPages > 1 ? (
            <nav className="pager" aria-label={messages.pagerNavLabel[locale]}>
              {page > 1 ? (
                <Link href={buildHref(pagerBase, {}, { page: String(page - 1) })} aria-label={messages.pagerPrevPage[locale]}>
                  <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
                </Link>
              ) : (
                <span className="dis" aria-hidden="true">
                  <ChevronLeft size={14} strokeWidth={2.2} />
                </span>
              )}
              {pagerTokens.map((token, index) => {
                if (token === 'gap') {
                  return (
                    <span key={`gap-${index}`} className="gap" aria-hidden="true">
                      ...
                    </span>
                  );
                }
                return token === page ? (
                  <span key={token} className="cur" aria-current="page">{token}</span>
                ) : (
                  <Link
                    key={token}
                    href={buildHref(pagerBase, {}, { page: String(token) })}
                    aria-label={messages.pagerGoToPage[locale].replace('{n}', String(token))}
                  >
                    {token}
                  </Link>
                );
              })}
              {page < totalPages ? (
                <Link href={buildHref(pagerBase, {}, { page: String(page + 1) })} aria-label={messages.pagerNextPage[locale]}>
                  <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
                </Link>
              ) : (
                <span className="dis" aria-hidden="true">
                  <ChevronRight size={14} strokeWidth={2.2} />
                </span>
              )}
            </nav>
          ) : null}
        </SurfaceCard>
      </OutreachSidebar>
    </AppShellTemplate>
  );
}

'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function OutreachError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="outreach"
      titleAr="تعذّر تحميل مساحة عمل التواصل بالحملات"
      titleEn="Campaign outreach workspace could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

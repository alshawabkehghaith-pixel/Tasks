import localFont from 'next/font/local';

export const sstArabic = localFont({
  src: [
    { path: './SSTArabic-Roman.otf', weight: '400', style: 'normal' },
    { path: './SSTArabic-Roman.otf', weight: '500', style: 'normal' },
    { path: './SSTArabic-Roman.otf', weight: '600', style: 'normal' },
    { path: './SSTArabic-Roman.otf', weight: '700', style: 'normal' },
  ],
  variable: '--font-sst',
  display: 'swap',
  preload: true,
});

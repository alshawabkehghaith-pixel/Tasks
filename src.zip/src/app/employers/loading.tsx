import styles from './loading.module.css';

const ROW_COUNT = 25;
const COLUMN_COUNT = 8;

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function EmployersLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل قائمة المنشآت</span>

      <div className={styles.card}>
        <div className={styles.toolbar}>
          <div className={styles.toolbarRow}>
            <div className={styles.toolbarSearch}>
              <Bone h={56} r={16} />
            </div>
            <Bone h={56} w="132px" r={16} />
            <Bone h={56} w="132px" r={16} />
          </div>
        </div>

        <div className={styles.count}>
          <Bone h={14} w="90px" r={4} />
        </div>

        <div className={`${styles.row} ${styles.head}`}>
          {Array.from({ length: COLUMN_COUNT }).map((_, i) => (
            <Bone key={i} h={12} r={4} />
          ))}
        </div>

        <div className={styles.body}>
          {Array.from({ length: ROW_COUNT }).map((_, rowIndex) => (
            <div key={rowIndex} className={styles.row}>
              {Array.from({ length: COLUMN_COUNT }).map((_, colIndex) => (
                <Bone key={colIndex} h={13} r={4} />
              ))}
            </div>
          ))}
        </div>

        <div className={styles.pager}>
          {Array.from({ length: 7 }).map((_, i) => (
            <Bone key={i} h={32} w="32px" r={8} />
          ))}
        </div>
      </div>
    </div>
  );
}

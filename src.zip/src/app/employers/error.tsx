'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function EmployersError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="employers"
      titleAr="تعذّر تحميل قائمة المنشآت"
      titleEn="Employers list could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { ClickableRow } from '@/components/ui/ClickableRow';
import { EmployersFilterToolbar } from '@/components/employer/employers-filter-toolbar/EmployersFilterToolbar';
import { SurfaceCard } from '@/components/ui/SurfaceCard';
import { messages } from '@/i18n/catalog';
import { fetchEmployerFacets, fetchEmployers } from '@/lib/api/backend';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { EmployerSummary } from '@/types/domain';
import type { AsyncSearchParamsProps } from '@/types/page';

const pageSize = 25;

export const metadata: Metadata = {
  title: 'المنشآت — Employers',
};

const COLUMNS = [
  { labelKey: 'colName', align: 'start', colClass: '' },
  { labelKey: 'colRegion', align: 'start', colClass: 'col-place' },
  { labelKey: 'colCity', align: 'start', colClass: 'col-place' },
  { labelKey: 'colSector', align: 'start', colClass: 'col-clamp' },
  { labelKey: 'colSize', align: 'start', colClass: 'col-metric' },
  { labelKey: 'dashKpiActiveJobs', align: 'end', colClass: 'col-metric' },
  { labelKey: 'dashKpiOpenPositions', align: 'end', colClass: 'col-metric' },
] as const satisfies readonly {
  labelKey: keyof typeof messages;
  align: 'start' | 'end' | 'center';
  colClass: string;
}[];

const COLUMN_COUNT = COLUMNS.length + 1;

const ALIGN_CLASS = { start: '', end: 'ta-end', center: 'ta-center' } as const;

type PagerToken = number | 'gap';

function buildPagerTokens(current: number, total: number, siblingCount = 1): PagerToken[] {
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1);
  }

  const left = Math.max(2, current - siblingCount);
  const right = Math.min(total - 1, current + siblingCount);
  const tokens: PagerToken[] = [1];

  if (left > 2) {
    tokens.push('gap');
  }

  for (let n = left; n <= right; n += 1) {
    tokens.push(n);
  }

  if (right < total - 1) {
    tokens.push('gap');
  }

  tokens.push(total);
  return tokens;
}

function splitCsv(value: string | undefined | null): string[] {
  return value ? value.split(',').map((part) => part.trim()).filter(Boolean) : [];
}

export default async function EmployersPage({ searchParams: searchParamsPromise }: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const requestedPage = Number.parseInt(getQueryValue(searchParams.page) || '1', 10);
  const page = Number.isFinite(requestedPage) && requestedPage > 0 ? requestedPage : 1;
  const search = getQueryValue(searchParams.q);
  const sector = splitCsv(getQueryValue(searchParams.sector));
  const size = splitCsv(getQueryValue(searchParams.size));
  const region = splitCsv(getQueryValue(searchParams.region));
  const hasJobs = getQueryValue(searchParams.has_jobs) === '1';

  const [result, facets] = await Promise.all([
    fetchEmployers({
      search,
      sector,
      size,
      region,
      hasJobs: hasJobs ? true : undefined,
      page,
      pageSize,
    }),
    fetchEmployerFacets(),
  ]);

  const totalPages = Math.max(1, Math.ceil(result.total / pageSize));
  const currentQuery = {
    q: search,
    sector: getQueryValue(searchParams.sector),
    size: getQueryValue(searchParams.size),
    region: getQueryValue(searchParams.region),
    has_jobs: getQueryValue(searchParams.has_jobs),
    page: undefined,
  };
  const pagerBase = '/employers';
  const filterStateKey = JSON.stringify(currentQuery);

  if (page > totalPages) {
    redirect(buildHref(pagerBase, currentQuery, { page: String(totalPages) }));
  }

  const pagerTokens = buildPagerTokens(page, totalPages);
  const rowHref = (id: string): string => `/employers/${encodeURIComponent(id)}`;
  const filtersActive = Boolean(search || sector.length || size.length || region.length || hasJobs);

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/employers"
      query={searchParams}
      title={messages.navEmployers[locale]}
    >
      <SurfaceCard className="list-table-card">
        <div className="filter-bar">
          <EmployersFilterToolbar
            key={filterStateKey}
            locale={locale}
            facets={facets}
            initialFilters={{
              search: search ?? '',
              sector,
              size,
              region,
              hasJobs,
            }}
          />
        </div>

        <div className="rescount" aria-live="polite">
          {result.total.toLocaleString(locale)} {messages.resultsCount[locale]}
        </div>

        <div className="list-table-wrap list-table-zoom">
          <div className="list-table-zoom-inner">
            <table className="ltbl">
              <thead>
                <tr>
                  {COLUMNS.map(({ labelKey, align, colClass }) => (
                    <th
                      key={labelKey}
                      scope="col"
                      className={[ALIGN_CLASS[align], colClass].filter(Boolean).join(' ') || undefined}
                    >
                      {messages[labelKey][locale]}
                    </th>
                  ))}
                  <th aria-hidden="true" />
                </tr>
              </thead>
              <tbody>
                {result.rows.length ? (
                  result.rows.map((row: EmployerSummary) => (
                    <ClickableRow key={row.id} href={rowHref(row.id)}>
                      <td className="lname">
                        <Link href={rowHref(row.id)}>{row.name}</Link>
                      </td>
                      <td className="col-place">{row.region}</td>
                      <td className="col-place">{row.city}</td>
                      <td className="col-clamp">{row.sector}</td>
                      <td className="col-metric">{row.size}</td>
                      <td className="mono ta-end col-metric">{row.activeJobs}</td>
                      <td className="mono ta-end col-metric">{row.openPositions}</td>
                      <td className="list-view-cell">
                        <span className="list-view-hint">
                          <span>{messages.empListViewEmployer[locale]}</span>
                          {locale === 'ar'
                            ? <ArrowLeft size={13} strokeWidth={2.2} aria-hidden="true" />
                            : <ArrowRight size={13} strokeWidth={2.2} aria-hidden="true" />}
                        </span>
                      </td>
                    </ClickableRow>
                  ))
                ) : (
                  <tr>
                    <td className="empty" colSpan={COLUMN_COUNT}>
                      <div className="list-empty">
                        <span>{messages.noResults[locale]}</span>
                        {filtersActive ? (
                          <Link href="/employers" className="text-[13px] font-semibold text-[var(--brand)] no-underline hover:underline">
                            {messages.emptyClearFilters[locale]}
                          </Link>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {totalPages > 1 ? (
          <nav className="pager" aria-label={messages.pagerNavLabel[locale]}>
            {page > 1 ? (
              <Link href={buildHref(pagerBase, currentQuery, { page: String(page - 1) })} aria-label={messages.pagerPrevPage[locale]}>
                <ChevronLeft size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronLeft size={14} strokeWidth={2.2} />
              </span>
            )}
            {pagerTokens.map((token, index) => {
              if (token === 'gap') {
                return (
                  <span key={`gap-${index}`} className="gap" aria-hidden="true">
                    ...
                  </span>
                );
              }

              const n = token;
              return n === page ? (
                <span key={n} className="cur" aria-current="page">
                  {n}
                </span>
              ) : (
                <Link
                  key={n}
                  href={buildHref(pagerBase, currentQuery, { page: String(n) })}
                  aria-label={messages.pagerGoToPage[locale].replace('{n}', String(n))}
                >
                  {n}
                </Link>
              );
            })}
            {page < totalPages ? (
              <Link href={buildHref(pagerBase, currentQuery, { page: String(page + 1) })} aria-label={messages.pagerNextPage[locale]}>
                <ChevronRight size={14} strokeWidth={2.2} aria-hidden="true" />
              </Link>
            ) : (
              <span className="dis" aria-hidden="true">
                <ChevronRight size={14} strokeWidth={2.2} />
              </span>
            )}
          </nav>
        ) : null}
      </SurfaceCard>
    </AppShellTemplate>
  );
}

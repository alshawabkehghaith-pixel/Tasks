import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';

import { EmployerProfileView } from '@/components/employer/employer-profile-view/EmployerProfileView';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { messages } from '@/i18n/catalog';
import { fetchEmployerProfile } from '@/lib/api/backend';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { AsyncRouteProps } from '@/types/page';

const JOBS_PAGE_SIZE = 10;

export async function generateMetadata({
  params: paramsPromise,
  searchParams: searchParamsPromise,
}: AsyncRouteProps<{ id: string }>): Promise<Metadata> {
  const [params, searchParams] = await Promise.all([paramsPromise, searchParamsPromise]);
  const requestedJobsPage = Number.parseInt(getQueryValue(searchParams.jobsPage) || '1', 10);
  const jobsPage = Number.isFinite(requestedJobsPage) && requestedJobsPage > 0 ? requestedJobsPage : 1;

  const [profile, prefs] = await Promise.all([
    fetchEmployerProfile(params.id, { jobsPage, jobsPageSize: JOBS_PAGE_SIZE }),
    getServerAppPreferences({}),
  ]);

  return { title: profile ? profile.name : messages.employerNotFoundTitle[prefs.locale] };
}

export default async function EmployerDetailPage({ params: paramsPromise, searchParams: searchParamsPromise }: AsyncRouteProps<{ id: string }>): Promise<JSX.Element> {
  const [params, searchParams] = await Promise.all([paramsPromise, searchParamsPromise]);
  const prefs = await getServerAppPreferences(searchParams);
  const locale = prefs.locale;

  const requestedJobsPage = Number.parseInt(getQueryValue(searchParams.jobsPage) || '1', 10);
  const jobsPage = Number.isFinite(requestedJobsPage) && requestedJobsPage > 0 ? requestedJobsPage : 1;

  const profile = await fetchEmployerProfile(params.id, { jobsPage, jobsPageSize: JOBS_PAGE_SIZE });

  if (!profile) notFound();

  const totalPages = Math.max(1, Math.ceil(profile.postedJobs.total / JOBS_PAGE_SIZE));
  const basePath = `/employers/${encodeURIComponent(params.id)}`;

  if (jobsPage > totalPages) {
    redirect(buildHref(basePath, {}, { jobsPage: String(totalPages) }));
  }

  const jobsPager = {
    page: jobsPage,
    totalPages,
    prevHref: jobsPage > 1 ? buildHref(basePath, {}, { jobsPage: String(jobsPage - 1) }) : null,
    nextHref: jobsPage < totalPages ? buildHref(basePath, {}, { jobsPage: String(jobsPage + 1) }) : null,
  };

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname={basePath}
      query={searchParams}
      title={messages.titleEmployer[locale]}
    >
      <Link className="back-link" href="/employers">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M15 6l-6 6 6 6" />
        </svg>
        {messages.backToEmployers[locale]}
      </Link>
      <div className="flex flex-col gap-[18px]">
        <EmployerProfileView profile={profile} locale={locale} jobsPager={jobsPager} />
      </div>
    </AppShellTemplate>
  );
}

'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function EmployerDetailError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="employer-detail"
      titleAr="تعذّر تحميل ملف المنشأة"
      titleEn="Employer profile could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

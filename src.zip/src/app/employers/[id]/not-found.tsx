import Link from 'next/link';

import { EmptyState } from '@/components/ui/EmptyState';
import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { messages } from '@/i18n/catalog';
import { getServerAppPreferences } from '@/lib/server/preferences';

export default async function EmployerNotFound(): Promise<JSX.Element> {
  const prefs = await getServerAppPreferences({});
  const locale = prefs.locale;

  return (
    <AppShellTemplate
      locale={locale}
      theme={prefs.theme}
      pathname="/employers"
      query={{}}
      title={messages.titleEmployer[locale]}
    >
      <Link className="back-link" href="/employers">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M15 6l-6 6 6 6" />
        </svg>
        {messages.backToEmployers[locale]}
      </Link>
      <EmptyState
        title={messages.employerNotFoundTitle[locale]}
        description={messages.empProfileEmptyDesc[locale]}
      />
    </AppShellTemplate>
  );
}

'use client';

import { RouteErrorCard } from '@/components/ui/route-error-card/RouteErrorCard';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function MyWorkspaceError({ error, reset }: ErrorProps): JSX.Element {
  return (
    <RouteErrorCard
      scope="my-workspace"
      titleAr="تعذّر تحميل مساحتي"
      titleEn="My Workspace could not be loaded"
      error={error}
      reset={reset}
    />
  );
}

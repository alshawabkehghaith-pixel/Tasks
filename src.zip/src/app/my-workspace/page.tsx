import type { Metadata } from 'next';
import { redirect } from 'next/navigation';

import { AppShellTemplate } from '@/components/shell/app-shell-template/AppShellTemplate';
import { MyWorkspacePage } from '@/components/my-workspace/my-workspace-page/MyWorkspacePage';
import { messages } from '@/i18n/catalog';
import { fetchCampaigns, fetchMyDecisions } from '@/lib/api/backend';
import { parsePositivePage } from '@/lib/pagination';
import { buildHref, getQueryValue } from '@/lib/routing';
import { getAppSession } from '@/lib/server/auth';
import { getServerAppPreferences } from '@/lib/server/preferences';
import type { ActivityItem } from '@/types/domain';
import type { AsyncSearchParamsProps } from '@/types/page';

const ACT_PAGE_SIZE = 5;

export const metadata: Metadata = {
  title: 'مساحتي — My Workspace',
};

export default async function MyWorkspaceRoutePage({ searchParams: searchParamsPromise }: AsyncSearchParamsProps): Promise<JSX.Element> {
  const searchParams = await searchParamsPromise;
  const [prefs, session] = await Promise.all([
    getServerAppPreferences(searchParams),
    getAppSession(),
  ]);

  const page = parsePositivePage(getQueryValue(searchParams.actPage));
  let pageItems: ActivityItem[] = [];
  let totalPages = 1;
  let total = 0;
  let loadError = false;

  if (session?.user.displayName) {
    try {
      const createdBy = session.user.displayName;
      const [campaigns, decisions] = await Promise.all([
        fetchCampaigns({ createdBy, page: 1, pageSize: 50 }),
        fetchMyDecisions({ createdBy, page: 1, pageSize: 50 }),
      ]);

      const merged: ActivityItem[] = [
        ...campaigns.rows.map((r) => ({ kind: 'campaign' as const, ...r })),
        ...decisions.rows.map((r) => ({ kind: 'decision' as const, ...r })),
      ].sort((a, b) => {
        const tsA = a.kind === 'campaign' ? a.sentAt : a.decidedAt;
        const tsB = b.kind === 'campaign' ? b.sentAt : b.decidedAt;
        return tsB.localeCompare(tsA);
      });

      total = merged.length;
      totalPages = Math.max(1, Math.ceil(total / ACT_PAGE_SIZE));

      if (page > totalPages) {
        redirect(buildHref('/my-workspace', {}, { actPage: String(totalPages) }));
      }

      const offset = (page - 1) * ACT_PAGE_SIZE;
      pageItems = merged.slice(offset, offset + ACT_PAGE_SIZE);
    } catch {
      loadError = true;
    }
  }

  return (
    <AppShellTemplate
      locale={prefs.locale}
      theme={prefs.theme}
      pathname="/my-workspace"
      query={searchParams}
      title={messages.navMyWorkspace[prefs.locale]}
    >
      <MyWorkspacePage
        locale={prefs.locale}
        loadError={loadError}
        activities={{ items: pageItems, page, totalPages, total }}
      />
    </AppShellTemplate>
  );
}

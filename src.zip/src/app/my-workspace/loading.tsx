import styles from './loading.module.css';

function Bone({ h, w = '100%', r = 6 }: { h: number; w?: string; r?: number }): JSX.Element {
  return <div className={styles.bone} style={{ height: h, width: w, borderRadius: r }} />;
}

export default function MyWorkspaceLoading(): JSX.Element {
  return (
    <div className={styles.shell} aria-busy="true" aria-live="polite">
      <span className="sr-only">جارٍ تحميل مساحتي</span>

      <div className={styles.layout}>
        <div className={styles.card}>
          <div className={styles.banner} />
          <div className={styles.body}>
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className={styles.row}>
                <Bone h={40} w="40px" r={12} />
                <div>
                  <Bone h={14} w="55%" />
                  <div style={{ marginTop: 8 }}>
                    <Bone h={12} w="80%" r={4} />
                  </div>
                </div>
                <Bone h={36} r={10} />
              </div>
            ))}
          </div>
        </div>

        <div className={styles.card}>
          <div className={styles.banner} />
          <div className={styles.body}>
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className={styles.row}>
                <Bone h={36} w="36px" r={999} />
                <div>
                  <Bone h={14} w="45%" />
                  <div style={{ marginTop: 8 }}>
                    <Bone h={12} w="70%" r={4} />
                  </div>
                </div>
                <Bone h={14} w="70px" r={4} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

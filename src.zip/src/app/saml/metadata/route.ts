import { NextRequest } from "next/server";
import { proxySamlGet } from "@/lib/server/samlProxy";

export const dynamic = "force-dynamic";
export const GET = (request: NextRequest) => proxySamlGet(request, "/saml/metadata");

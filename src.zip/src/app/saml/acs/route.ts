import { NextRequest } from "next/server";
import { proxySamlPost } from "@/lib/server/samlProxy";

export const POST = (request: NextRequest) => proxySamlPost(request, "/saml/acs");

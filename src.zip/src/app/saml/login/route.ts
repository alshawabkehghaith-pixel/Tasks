import { NextRequest } from "next/server";
import { proxySamlGet } from "@/lib/server/samlProxy";

export const GET = (request: NextRequest) => proxySamlGet(request, "/saml/login");

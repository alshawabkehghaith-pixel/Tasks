import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

import { getAppSession } from '@/lib/server/auth';
import { request as apiRequest } from '@/lib/server/api-client';
import type { PublishCampaignResult } from '@/types/domain';

const TargetSchema = z.object({
  nin: z.string().min(1).max(20),
  name: z.string().default(''),
  jobIds: z.array(z.string().min(1)).min(1),
  jobTitles: z.array(z.string()).default([]),
});

const PublishPayloadSchema = z.object({
  targets: z.array(TargetSchema).min(1),
  message: z.object({
    purpose: z.enum(['vacancy', 'completeness']),
    subject: z.string(),
    body: z.string(),
  }),
  channel: z.literal('email'),
  batchContext: z.object({
    mode: z.string(),
    levels: z.array(z.string()).optional(),
    regions: z.array(z.string()).optional(),
  }),
});

const PublishResultSchema = z.object({
  campaignId: z.string(),
  scheduledAt: z.string(),
});

export async function POST(
  request: NextRequest,
): Promise<NextResponse<PublishCampaignResult | { error: string }>> {
  try {
    const session = await getAppSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = PublishPayloadSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    }

    const createdBy = session.user.displayName ?? 'System';

    const result = await apiRequest<PublishCampaignResult>(
      '/campaigns',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...parsed.data, createdBy }),
      },
      PublishResultSchema,
    );

    return NextResponse.json(result);
  } catch (err) {
    console.error('[POST /api/campaigns/publish]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

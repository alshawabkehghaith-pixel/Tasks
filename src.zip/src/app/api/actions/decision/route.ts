import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

import { getAppSession } from '@/lib/server/auth';
import { request as apiRequest } from '@/lib/server/api-client';

const DecisionPayloadSchema = z.object({
  nin: z.string().min(1).max(20),
  jobId: z.string().min(1).max(50),
  verdict: z.enum(['approved', 'rejected']),
  reasonKey: z.string().max(200).optional(),
}).refine(
  (data) => data.verdict !== 'rejected' || !!data.reasonKey,
  { message: 'reasonKey is required for rejected decisions', path: ['reasonKey'] },
);

const DecisionResultSchema = z.object({
  ok: z.boolean(),
  decision: z.object({
    verdict: z.string(),
    reasonKey: z.string().nullable().optional(),
    timestamp: z.string(),
  }),
});

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const session = await getAppSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = DecisionPayloadSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid decision payload' }, { status: 400 });
    }

    const result = await apiRequest(
      '/actions/decision',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...parsed.data, createdBy: session.user.displayName ?? 'System' }),
      },
      DecisionResultSchema,
    );

    return NextResponse.json(result);
  } catch (err) {
    console.error('[POST /api/actions/decision]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

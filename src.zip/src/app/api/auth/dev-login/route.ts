import { NextRequest, NextResponse } from "next/server";
import { LOGIN_RETURN_TO_COOKIE, sanitizeReturnTo } from '@/lib/auth-state';
import {
  ROLE_COOKIE,
  SESSION_COOKIE,
  USER_EMAIL_COOKIE,
  USER_NAME_COOKIE,
  USER_USERNAME_COOKIE,
} from "@/lib/server/auth";

const MOCK_API_URL = process.env.MOCK_API_URL ?? "http://127.0.0.1:8001";
const MOCK_BACKEND = process.env.MOCK_BACKEND === "true";

type DevLoginPayload = {
  accessToken: string;
  expiresIn: number;
  user: {
    role: "admin" | "user";
    displayName: string;
    username: string;
    email: string;
  };
};

function normalizeDevPayload(raw: unknown): DevLoginPayload | null {
  if (!raw || typeof raw !== "object") return null;

  const input = raw as Record<string, unknown>;
  const userInput = (input.user && typeof input.user === "object") ? (input.user as Record<string, unknown>) : {};

  const accessToken =
    typeof input.accessToken === "string" ? input.accessToken
    : typeof input.access_token === "string" ? input.access_token
    : typeof input.token === "string" ? input.token
    : "";

  const expiresCandidate =
    typeof input.expiresIn === "number" ? input.expiresIn
    : typeof input.expires_in === "number" ? input.expires_in
    : typeof input.expiresIn === "string" ? Number.parseInt(input.expiresIn, 10)
    : typeof input.expires_in === "string" ? Number.parseInt(input.expires_in, 10)
    : Number.NaN;

  const normalizedExpires = Number.isFinite(expiresCandidate) && expiresCandidate > 0
    ? Math.max(300, Math.floor(expiresCandidate))
    : 60 * 60 * 8;

  if (!accessToken) return null;

  const role = userInput.role === "admin" ? "admin" : "user";
  const email = typeof userInput.email === "string" ? userInput.email : "";
  const displayName = typeof userInput.displayName === "string" && userInput.displayName
    ? userInput.displayName
    : "Developer";
  const username = typeof userInput.username === "string" && userInput.username
    ? userInput.username
    : (email || "dev.user");

  return {
    accessToken,
    expiresIn: normalizedExpires,
    user: {
      role,
      displayName,
      username,
      email,
    },
  };
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  const returnTo = sanitizeReturnTo(
    request.nextUrl.searchParams.get('next') ?? request.cookies.get(LOGIN_RETURN_TO_COOKIE)?.value,
    '/dashboard',
  );

  const mockPayload: DevLoginPayload = {
    accessToken: "dev-mock-token-" + Date.now(),
    expiresIn: 60 * 60 * 8,
    user: {
      role: "admin" as const,
      displayName: "Developer",
      username: "dev.user",
      email: "dev.user@jme.local",
    },
  };

  let payload = mockPayload;

  if (!MOCK_BACKEND) {
    try {
      const upstream = await fetch(`${MOCK_API_URL}/auth/dev-login`, {
        method: "POST",
        cache: "no-store",
      });
      if (upstream.ok) {
        payload = normalizeDevPayload(await upstream.json()) ?? mockPayload;
      }

    } catch {

    }
  }

  const response = NextResponse.redirect(new URL(returnTo, request.url), 303);
  const options = {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: request.nextUrl.protocol === "https:",
    path: "/",
    maxAge: payload.expiresIn,
  };
  response.cookies.set(SESSION_COOKIE, payload.accessToken, options);
  response.cookies.set(ROLE_COOKIE, payload.user.role, options);
  response.cookies.set(USER_NAME_COOKIE, payload.user.displayName, options);
  response.cookies.set(USER_USERNAME_COOKIE, payload.user.username, options);
  response.cookies.set(USER_EMAIL_COOKIE, payload.user.email, options);
  response.cookies.set(LOGIN_RETURN_TO_COOKIE, '', { ...options, maxAge: 0 });
  return response;
}
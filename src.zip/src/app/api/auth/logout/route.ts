import { NextRequest, NextResponse } from "next/server";
import { LOGIN_RETURN_TO_COOKIE } from '@/lib/auth-state';
import { ROLE_COOKIE, SESSION_COOKIE, USER_EMAIL_COOKIE, USER_NAME_COOKIE, USER_USERNAME_COOKIE } from "@/lib/server/auth";
import { logServerEvent } from "@/lib/server/logging";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const location = '/login';
  console.log("[frontend:auth-logout] redirecting browser after logout", {
    requestUrl: request.url,
    location,
  });
  const response = new NextResponse(null, { status: 303, headers: { Location: location } });
  response.cookies.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  response.cookies.set(ROLE_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  response.cookies.set(USER_NAME_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  response.cookies.set(USER_USERNAME_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  response.cookies.set(USER_EMAIL_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  response.cookies.set(LOGIN_RETURN_TO_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
  await logServerEvent("INFO", "auth.logout.completed", { location, request_url: request.url });
  return response;
}

export const GET = POST;

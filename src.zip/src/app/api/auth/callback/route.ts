import { NextRequest, NextResponse } from "next/server";
import { LOGIN_RETURN_TO_COOKIE, sanitizeReturnTo } from '@/lib/auth-state';
import { getServerEnv } from '@/lib/config/env';
import { ROLE_COOKIE, SESSION_COOKIE, USER_EMAIL_COOKIE, USER_NAME_COOKIE, USER_USERNAME_COOKIE } from "@/lib/server/auth";
import { logServerEvent } from "@/lib/server/logging";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("code");
  if (!code) {
    await logServerEvent("WARNING", "auth.callback.rejected", { reason: "missing_code" });
    return new NextResponse(null, { status: 303, headers: { Location: '/login' } });
  }
  const apiBase = getServerEnv().API_BASE_URL.replace(/\/$/, '');
  const upstream = await fetch(`${apiBase}/auth/exchange`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code }),
    cache: "no-store",
  });
  if (!upstream.ok) {
    await logServerEvent("WARNING", "auth.exchange.failed", { status_code: upstream.status });
    return new NextResponse(null, { status: 303, headers: { Location: '/login' } });
  }
  const payload = await upstream.json() as {
    accessToken: string;
    expiresIn: number;
    returnTo: string;
    user: { role: "admin" | "user"; displayName: string; username: string; email: string };
  };
  const location = sanitizeReturnTo(payload.returnTo, '/dashboard');
  const response = new NextResponse(null, { status: 303, headers: { Location: location } });
  const options = {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: request.nextUrl.protocol === "https:",
    path: "/",
    maxAge: payload.expiresIn,
  };
  response.cookies.set(SESSION_COOKIE, payload.accessToken, options);
  response.cookies.set(ROLE_COOKIE, payload.user.role, options);
  response.cookies.set(USER_NAME_COOKIE, payload.user.displayName, options);
  response.cookies.set(USER_USERNAME_COOKIE, payload.user.username, options);
  response.cookies.set(USER_EMAIL_COOKIE, payload.user.email, options);
  response.cookies.set(LOGIN_RETURN_TO_COOKIE, '', { ...options, maxAge: 0 });
  await logServerEvent("INFO", "auth.login.completed", {
    role: payload.user.role,
    return_to: payload.returnTo,
    location,
    request_url: request.url,
  });
  return response;
}

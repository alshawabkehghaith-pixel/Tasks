import { NextRequest, NextResponse } from "next/server";

import { LOGIN_RETURN_TO_COOKIE, LOCALE_COOKIE, sanitizeReturnTo } from '@/lib/auth-state';

export async function GET(request: NextRequest) {
  const locale = request.cookies.get(LOCALE_COOKIE)?.value === 'en' ? 'en' : 'ar';
  const returnTo = sanitizeReturnTo(request.cookies.get(LOGIN_RETURN_TO_COOKIE)?.value, '/dashboard');

  const location = `/saml/login?locale=${locale}&returnTo=${encodeURIComponent(returnTo)}`;
  return new NextResponse(null, { status: 303, headers: { Location: location } });
}
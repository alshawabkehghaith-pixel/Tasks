import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest): Promise<NextResponse> {
  const body = (await request.json()) as { locale?: unknown; theme?: unknown };

  const locale = body.locale === 'en' ? 'en' : body.locale === 'ar' ? 'ar' : null;
  const theme  = body.theme === 'dark' ? 'dark' : body.theme === 'light' ? 'light' : null;

  return NextResponse.json({
    ok: true,
    locale,
    theme,
  });
}

import { NextRequest, NextResponse } from 'next/server';

import { messages } from '@/i18n/catalog';
import { fetchCandidateProfile, fetchSuggestedJobs } from '@/lib/api/backend';
import { DEFAULT_LOCALE, resolveLocale } from '@/lib/api/jadarat';
import { LOCALE_COOKIE } from '@/lib/auth-state';
import type { Locale } from '@/types/jadarat';

const READINESS_LABEL_KEY = {
  ready: 'cand360ReadinessReady',
  partial: 'cand360ReadinessPartial',
  incomplete: 'cand360ReadinessIncomplete',
} as const;

const JOB_LEVEL_LABEL_KEY = {
  entry: 'cand360JobLevelEntry',
  mid: 'cand360JobLevelMid',
  senior: 'cand360JobLevelSenior',
} as const;

function resolveRequestLocale(request: NextRequest): Locale {
  const fromQuery = request.nextUrl.searchParams.get('lang');
  if (fromQuery === 'ar' || fromQuery === 'en') return fromQuery;
  return resolveLocale(request.cookies.get(LOCALE_COOKIE)?.value ?? DEFAULT_LOCALE);
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  const nin = request.nextUrl.searchParams.get('nin')?.trim() ?? '';
  if (!nin) {
    return NextResponse.json({ error: 'Missing nin' }, { status: 400 });
  }

  const locale = resolveRequestLocale(request);
  const [profile, suggested] = await Promise.all([
    fetchCandidateProfile(nin),
    fetchSuggestedJobs(nin, { page: 1, pageSize: 100 }),
  ]);

  if (!profile) {
    return NextResponse.json({ error: 'Candidate not found' }, { status: 404 });
  }

  const readinessKey = READINESS_LABEL_KEY[profile.readiness];
  const levelKey = JOB_LEVEL_LABEL_KEY[profile.jobLevel];

  return NextResponse.json({
    candidate: {
      name: profile.name,
      nin: profile.nin,
      region: profile.region,
      city: profile.city,
      gender: profile.gender,
      age: profile.age,
      occupationalField: profile.occupationalField,
      qualification: profile.qualification,
      yearsExperience: profile.yearsExperience,
      jobLevelLabel: messages[levelKey][locale] ?? profile.jobLevel,
      octoberBatch: profile.octoberBatch,
      freshGraduate: profile.freshGraduate,
      status: profile.status,
      strengths: profile.strengths.map((strength) => strength.label),
      readinessLabel: messages[readinessKey][locale],
      matchCount: profile.matches.length,
    },
    jobs: suggested.rows,
  });
}

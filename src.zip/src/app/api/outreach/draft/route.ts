import { NextRequest, NextResponse } from 'next/server';

import {
  draftByteLength,
  emptyOutreachDraft,
  encodeOutreachDraft,
  mergeOutreachDraft,
  OUTREACH_DRAFT_COOKIE,
  OUTREACH_DRAFT_MAX_BYTES,
  outreachDraftCookieOptions,
  parseOutreachDraft,
  type OutreachDraftPatch,
} from '@/lib/outreach/draft';

function readDraftFromRequest(request: NextRequest) {
  const raw = request.cookies.get(OUTREACH_DRAFT_COOKIE)?.value;
  if (!raw) return emptyOutreachDraft();
  try {
    return parseOutreachDraft(JSON.parse(raw)) ?? emptyOutreachDraft();
  } catch {
    return emptyOutreachDraft();
  }
}

function cookieResponse(draft: ReturnType<typeof emptyOutreachDraft>, request: NextRequest) {
  if (draftByteLength(draft) > OUTREACH_DRAFT_MAX_BYTES) {
    return NextResponse.json(
      { error: 'Outreach selection is too large to store. Narrow the batch and try again.' },
      { status: 413 },
    );
  }

  const response = NextResponse.json({ ok: true, draft });
  response.cookies.set(
    OUTREACH_DRAFT_COOKIE,
    encodeOutreachDraft(draft),
    outreachDraftCookieOptions(request.nextUrl.protocol === 'https:'),
  );
  return response;
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  return NextResponse.json({ draft: readDraftFromRequest(request) });
}

export async function PUT(request: NextRequest): Promise<NextResponse> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const patch = (body && typeof body === 'object' ? body : {}) as OutreachDraftPatch;
  const next = mergeOutreachDraft(emptyOutreachDraft(), patch);
  return cookieResponse(next, request);
}

export async function PATCH(request: NextRequest): Promise<NextResponse> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const patch = (body && typeof body === 'object' ? body : {}) as OutreachDraftPatch;
  const next = mergeOutreachDraft(readDraftFromRequest(request), patch);
  return cookieResponse(next, request);
}

export async function DELETE(request: NextRequest): Promise<NextResponse> {
  const response = NextResponse.json({ ok: true });
  response.cookies.set(OUTREACH_DRAFT_COOKIE, '', {
    ...outreachDraftCookieOptions(request.nextUrl.protocol === 'https:'),
    maxAge: 0,
  });
  return response;
}

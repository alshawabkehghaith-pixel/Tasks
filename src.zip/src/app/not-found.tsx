import Link from 'next/link';

export default function NotFound(): JSX.Element {
  return (
    <main
      style={{
        minHeight: '100vh',
        background: 'var(--paper)',
        padding: '4rem 1.5rem',
        color: 'var(--text)',
      }}
    >
      <div
        style={{
          maxWidth: '32rem',
          margin: '0 auto',
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem',
          borderRadius: '1.5rem',
          border: '1px solid rgba(255,255,255,0.7)',
          background: 'rgba(255,255,255,0.8)',
          padding: '2rem',
          boxShadow: 'var(--shadow)',
        }}
      >
        <p
          style={{
            fontSize: '0.75rem',
            fontWeight: 600,
            textTransform: 'uppercase',
            letterSpacing: '0.2em',
            color: 'var(--text-faint)',
          }}
        >
          404
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 600, letterSpacing: '-0.025em' }} dir="rtl">
            الصفحة غير موجودة
          </h1>
          <p style={{ fontSize: '1.1rem', fontWeight: 500, color: 'var(--text-soft)' }} dir="ltr">
            Page not found
          </p>
        </div>

        <p style={{ fontSize: '0.875rem', color: 'var(--text-soft)', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
          <span dir="rtl">المسار المطلوب غير موجود في هذا التطبيق.</span>
          <span dir="ltr">The requested route does not exist in this application.</span>
        </p>

        <Link
          href="/dashboard"
          style={{
            alignSelf: 'flex-start',
            borderRadius: '0.75rem',
            background: 'var(--brand)',
            padding: '0.5rem 1rem',
            fontSize: '0.875rem',
            fontWeight: 600,
            color: '#fff',
            textDecoration: 'none',
          }}
        >
          لوحة المعلومات / Go to dashboard
        </Link>
      </div>
    </main>
  );
}

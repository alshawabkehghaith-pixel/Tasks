

import type { Locale } from '@/i18n/config';

export type { Locale };

export type ThemeMode = 'light' | 'dark';

export type ReportPeriod = '7' | '30' | '90' | 'all';

export type Direction = 'rtl' | 'ltr';

export interface LocalizedText {
  ar: string;
  en: string;
}

export interface DemoMeta {
  today: string;
  counts: {
    candidates: number;
    employers: number;
    queue: number;
  };
}

export type TranslationMap = Record<string, LocalizedText>;

export interface HtmlByLocale {
  ar: string;
  en: string;
}

export interface BrowseCandidateRow {
  nin: string;
  name: string;
  region: string;
  title: string;
  tier: string;
  score: number;
  html: HtmlByLocale;
}

export interface BrowseEmployerRow {
  id: string;
  name: string;
  name_en: string;
  sector: string;
  size: string;
  jobs: number;
  html: HtmlByLocale;
}

export interface QueueItem {
  nin: string;
  job_id: string;
  score: number;
  band: 'priority' | 'secondary';
  html: HtmlByLocale;
}

export interface ActivityRow {
  name: string;
  job_title: string;
  channel: string;
  created_ts: string;
}

export interface ThroughputRow {
  reviewed: number;
  approved: number;
  rejected: number;
  approval_rate: number;
}

export interface TimelinePoint {
  date: string;
  reviews: number;
  approvals: number;
}

export interface ApprovedTodayRow {
  name: string;
  nin: string;
  contact: string;
  job_title: string;
  employer: string;
  score: number;
  explanation: string;
  channel: string;
  reviewed_by: string;
  created_ts: string;
}

export interface ReportsData {
  throughput: Record<ReportPeriod, ThroughputRow>;
  timeline: Record<ReportPeriod, TimelinePoint[]>;
  pending: number;
  myAssigned: string[];
  approved_today: ApprovedTodayRow[];
}

export interface MatchMetaRow {
  nin: string;
  job_id: string;
  name: string;
  job_title: string;
  employer: string;
  explanation: string;
  score: number;
  channel: string;
}

export interface VerdictCopy {
  qcard: string;
  mv: string;
}

export interface VerdictBundle {
  approve: VerdictCopy;
  reject: VerdictCopy;
}

export interface DemoSourceData {
  meta: DemoMeta;
  i18n: TranslationMap;
  shell: Record<Locale, string>;
  login: Record<Locale, string>;
  dashboard: Record<ReportPeriod, HtmlByLocale>;
  browse: {
    cand: BrowseCandidateRow[];
    emp: BrowseEmployerRow[];
    options: Record<string, unknown>;
  };
  browsePages: {
    cand: Record<Locale, string>;
    emp: Record<Locale, string>;
  };
  candidates: Record<string, HtmlByLocale>;
  employers: Record<string, HtmlByLocale>;
  queue: QueueItem[];
  activity: ActivityRow[];
  reports: ReportsData;
  matchMeta: Record<string, MatchMetaRow>;
  done: Record<Locale, VerdictBundle>;
  reasons: string[];
  user: {
    display_name: string;
  };
}

export interface NavigationItem {
  href: string;
  label: LocalizedText;
  icon: 'dashboard' | 'candidate' | 'employer' | 'queue' | 'workspace';
}

export interface NavigationGroup {
  label: LocalizedText;
  items: NavigationItem[];
}

export interface ShellViewModel {
  brand: LocalizedText;
  subtitle: LocalizedText;
  userName: string;
  userRole: LocalizedText;
  navGroups: NavigationGroup[];
  searchPlaceholder: LocalizedText;
}

export interface AppPreferences {
  locale: Locale;
  theme: ThemeMode;
  direction: Direction;
}
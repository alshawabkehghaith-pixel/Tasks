export type RouteSearchParams = Record<string, string | string[] | undefined>;

export interface AsyncSearchParamsProps {
  searchParams: Promise<RouteSearchParams>;
}

export interface AsyncRouteProps<TParams> extends AsyncSearchParamsProps {
  params: Promise<TParams>;
}

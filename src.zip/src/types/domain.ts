

export type Readiness = 'ready' | 'partial' | 'incomplete';

export type QueueBand = 'priority' | 'secondary';

export type NotificationChannel = 'email';

export type ActivityStatus = 'sent' | 'not_sent';

export type ImpactLevel = 'high' | 'medium' | 'low';

export type MatchVerdict = 'approved' | 'rejected';

export type JobStatus = 'active' | 'inactive';

export interface DistributionBar {
  label: string;
  count: number;
}

export interface Paginated<T> {
  rows: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ActivityQuery {
  page?: number;
  pageSize?: number;
}

export interface CandidateQuery {
  search?: string;
  region?: string[];
  city?: string[];
  gender?: string[];
  age?: number[];
  qualification?: string[];
  occupationalField?: string[];
  yearsExperience?: number[];
  status?: string[];
  octoberBatch?: boolean[];
  freshGraduate?: boolean[];
  readiness?: Readiness[];
  page?: number;
  pageSize?: number;
}

export type JobLevel = 'entry' | 'mid' | 'senior';

export type BatchType = 'octoberBatch' | 'freshGraduate';

export interface CustomBatchFilters {
  regions: string[];
  cities: string[];
  genders: string[];
  ages: number[];
  qualifications: string[];
  occupationalFields: string[];
  yearsExperience: number[];
  statuses: string[];
  readiness: string[];
}

export interface CandidateSummary {
  nin: string;
  name: string;
  region: string;
  city: string;
  qualification: string;
  occupationalField: string;
  yearsExperience: number;
  jobLevel: JobLevel;
  status: string;
  age: number;
  gender: string;
  octoberBatch: boolean;
  freshGraduate: boolean;
  readiness: Readiness;
  score: number;
  topMatchScore: number;
  updatedAt: string;
  matchCount: number;
}

export interface CandidateFacets {
  readiness: Readiness[];
  regions: string[];
  cities: string[];
  genders: string[];
  ages: number[];
  qualifications: string[];
  occupationalFields: string[];
  yearsExperience: number[];
  statuses: string[];
  octoberBatch: boolean[];
  freshGraduate: boolean[];
}

export interface JobLevelBatch {
  key: JobLevel;
  label: string;
  count: number;
}

export interface BatchTypeBatch {
  key: BatchType;
  label: string;
  count: number;
}

export interface CandidateBatchPreviewQuery {
  
  batchType?: BatchType;
  
  filters?: CustomBatchFilters;
}

export type VerificationBatchMode = 'candidates' | 'levels' | 'custom' | 'batchType';

export interface VerificationBatchQuery {
  mode: VerificationBatchMode;
  
  nins?: string[];
  
  levels?: JobLevel[];
  
  regions?: string[];
  
  batchType?: BatchType;
  
  customFilters?: CustomBatchFilters;
  
  search?: string;
  region?: string;
  level?: JobLevel | '';
  page?: number;
  pageSize?: number;
}

export interface VerificationCandidateRow {
  nin: string;
  name: string;
  
  region: string;
  city: string;
  occupationalField: string;
  octoberBatch: boolean;
  freshGraduate: boolean;
  
  topMatchScore: number;
  matchCount: number;
}

export interface VerificationBatchResult {
  
  batchTotal: number;
  rows: Paginated<VerificationCandidateRow>;
}

export interface VerificationFacets {
  regions: string[];
  levels: JobLevelBatch[];
}

export interface SuggestedJobsQuery {
  page?: number;
  pageSize?: number;
}

export interface SuggestedJob {
  id: string;
  jobTitle: string;
  employer: string;
  
  location: string;
  matchPct: number;
  explanation: string;
}

export interface PublishTargetEntry {
  nin: string;
  name: string;
  
  jobIds: string[];
  
  jobTitles: string[];
}

export interface PublishCampaignPayload {
  targets: PublishTargetEntry[];
  message: {
    purpose: CampaignPurpose;
    subject: string;
    body: string;
  };
  channel: 'email';
  batchContext: {
    mode: string;
    levels?: string[];
    regions?: string[];
  };
}

export interface PublishCampaignResult {
  campaignId: string;
  scheduledAt: string;
}

export type CampaignPurpose = 'vacancy' | 'completeness';
export type CampaignTemplate = 'interactive' | 'professional' | 'basic';

export interface CampaignLanguageDraft {
  subject: string;
  body: string;
}

export interface CampaignDraft {
  purpose: CampaignPurpose | null;
  template: CampaignTemplate | null;
  en: CampaignLanguageDraft;
  ar: CampaignLanguageDraft;
  
  seededForPurpose: CampaignPurpose | null;
}

export interface CampaignQuery {
  purpose?: CampaignPurpose;
  createdBy?: string;
  page?: number;
  pageSize?: number;
}

export interface CampaignSummary {
  id: number;
  createdBy: string;
  purpose: CampaignPurpose;
  candidateCount: number;
  channel: string;
  sentAt: string;
}

export interface UserDecision {
  id: number;
  nin: string;
  candidateName: string;
  jobTitle: string;
  verdict: 'approved' | 'rejected';
  reasonKey: string | null;
  decidedAt: string;
}

export interface DecisionQuery {
  createdBy?: string;
  page?: number;
  pageSize?: number;
}

export type ActivityItem =
  | ({ kind: 'campaign' } & CampaignSummary)
  | ({ kind: 'decision' } & UserDecision);

export interface CampaignCandidateRow {
  rowId: number;
  nin: string;
  candidateName: string;
  jobId: string;
  jobTitle: string;
  employer: string;
  matchScore: number;
  notificationStatus: 'sent' | 'not_sent';
  notifiedAt: string;
}

export interface CampaignDetailQuery {
  page?: number;
  pageSize?: number;
}

export interface CampaignDetail {
  header: CampaignSummary;
  rows: CampaignCandidateRow[];
  total: number;
  page: number;
  pageSize: number;
}

export interface PreparationRepresentative {
  name: string;
  nin: string;
  
  selectedJobLines: string[];
  missingFieldsEn: string[];
}

export interface ReadinessDriver {
  id: string;
  field: string;
  impact: ImpactLevel;
  points: number;
  updatedAt: string;
}

export interface CandidateMatch {
  id: string;
  candidateNin: string;
  jobId: string;
  jobTitle: string;
  employer: string;
  
  usoc: string;
  score: number;
  explanation: string;
  verdict: MatchVerdict | null;
  createdAt: string;
}

export interface CandidateStrength {
  id: string;
  label: string;
  updatedAt: string;
}

export interface CandidateProfile {
  nin: string;
  name: string;
  region: string;
  city: string;
  occupationalField: string;
  octoberBatch: boolean;
  freshGraduate: boolean;
  readiness: Readiness;
  gender: string;
  age: number;
  qualification: string;
  yearsExperience: number;
  jobLevel: JobLevel;
  status: string;
  readinessScore: number;
  
  topMatchScore: number;
  updatedAt: string;
  readinessDrivers: ReadinessDriver[];
  strengths: CandidateStrength[];
  matches: CandidateMatch[];
}

export interface EmployerFacets {
  sectors: string[];
  sizes: string[];
  regions: string[];
}

export interface EmployerQuery {
  search?: string;
  sector?: string[];
  size?: string[];
  region?: string[];
  hasJobs?: boolean;
  page?: number;
  pageSize?: number;
}

export interface EmployerSummary {
  id: string;
  name: string;
  sector: string;
  size: string;
  region: string;
  city: string;
  jobs: number;
  activeJobs: number;
  openPositions: number;
}

export interface EmployerJob {
  id: string;
  employerId: string;
  title: string;
  status: JobStatus;
  openings: number;
  matchedCandidates: number;
  salaryBand: string;
  updatedAt: string;
  closedAt: string | null;
}

export interface EmployerProfile {
  id: string;
  name: string;
  sector: string;
  size: string;
  region: string;
  city: string;
  jobs: number;
  
  sizeLabel: string;
  updatedAt: string;
  jobsPosted: number;
  activeJobs: number;
  openPositions: number;
  matchedCandidates: number;
  bySalary: DistributionBar[];
  postedJobs: Paginated<EmployerJob>;
}

export interface QueueEntry {
  nin: string;
  jobId: string;
  candidateName: string;
  jobTitle: string;
  employer: string;
  score: number;
  band: QueueBand;
  experienceYears: number;
  city: string;
  readiness: Readiness;
  employerSector: string;
  roles: string[];
  explanation: string;
  skills: string[];
}

export interface ActivityEntry {
  candidateName: string;
  jobTitle: string;
  channel: NotificationChannel;
  status: ActivityStatus;
  timestamp: string;
}

export type ReportPeriod = '7' | '30' | '90';

export interface ReportsQuery {
  period: ReportPeriod;
}

export interface ThroughputMetrics {
  reviewed: number;
  approved: number;
  rejected: number;
  approvalRate: number;
}

export interface TimelinePoint {
  date: string;
  reviews: number;
  approvals: number;
  notifications: number;
}

export interface ApprovedRow {
  nin: string;
  name: string;
  jobTitle: string;
  score: number;
}

export interface ReportsSnapshot {
  throughput: ThroughputMetrics;
  timeline: TimelinePoint[];
  pending: number;
  approvedToday: ApprovedRow[];
}

export interface DashboardKPIs {
  candidates: number;
  
  candidatesReadyPct?: number;
  employers: number;
  activeJobs: number;
  openPositions: number;
  matchesCreated: number;
  strongMatches: number;
  avgMatchScore: number;
}

export interface ReadinessBreakdown {
  readyPct: number;
  ready: number;
  partial: number;
  incomplete: number;
  recentGrads: number;
}

export interface FollowUpItem {
  field: string;
  count: number;
}

export interface FunnelStep {
  label: string;
  count: number;
  
  conversionPct?: number;
}

export interface TalentPipelineMetrics {
  matched: number;
  highMatch: number;
  reviewed: number;
  approved: number;
  notified: number;
}

export type CoverageLevel = 'good' | 'moderate' | 'gap' | 'surplus';

export interface SupplyDemandRow {
  category: string;
  demand: number;
  supply: number;
  coverage: CoverageLevel;
}

export interface ScoreBand {
  range: string;
  count: number;
}

export interface JobDistributionRow {
  label: string;
  value: number;
}

export interface DashboardQuery {
  period: ReportPeriod;
}

export interface DashboardSnapshot {
  period: ReportPeriod;
  kpis: DashboardKPIs;
  readiness: ReadinessBreakdown;
  followUp: FollowUpItem[];
  funnel: FunnelStep[];
  talentPipeline: TalentPipelineMetrics;
  supplyDemand: SupplyDemandRow[];
  scoreBands: ScoreBand[];
  timeline: TimelinePoint[];
  jobsBySalary: JobDistributionRow[];
}

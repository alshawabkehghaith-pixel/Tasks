import ar from '@/locales/ar.json';
import en from '@/locales/en.json';

import type { Locale } from '@/i18n/config';

export type BilingualText = Record<Locale, string>;
export type MessageCatalog = {
  [K in keyof typeof en]: BilingualText;
};

function buildCatalog(): MessageCatalog {
  const catalog = {} as MessageCatalog;

  for (const key of Object.keys(en) as Array<keyof typeof en>) {
    catalog[key] = {
      ar: ar[key],
      en: en[key],
    };
  }

  return catalog;
}

export const messages = buildCatalog();
